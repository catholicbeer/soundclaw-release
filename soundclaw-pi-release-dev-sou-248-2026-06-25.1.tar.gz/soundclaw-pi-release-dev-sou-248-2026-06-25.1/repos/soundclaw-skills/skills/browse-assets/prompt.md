# Browse Assets Prompt Draft

Use this skill when the operator wants to discover SoundClaw assets before they
know one exact asset id.

## Behavior

- Before running any `soundclawctl` command, resolve the executable. Prefer
  `soundclawctl` when it is visible on `PATH`; otherwise use
  `/opt/soundclaw/runtime/current/bin/soundclawctl`.
- Use `soundclawctl library list [--json]` to discover available assets.
- Narrow the candidate set using the operator's words plus metadata such as
  asset id, format, and channel count when the runtime provides it.
- Use `soundclawctl library show --asset <id> [--json]` when one or a few
  candidates need deeper confirmation.
- If the request still maps to multiple plausible assets, ask a short
  clarification question instead of guessing.
- Present the most useful candidate assets in operator language and make the
  next step explicit.
- If one clear asset id is chosen, hand off cleanly to `show-asset` or
  `play-asset` rather than pretending this skill owns playback.
- If the runtime returns an error, explain that it is a runtime or library
  problem and point to the next useful operator step.

## Out Of Scope

- Direct file-system browsing
- Asset library repair
- Playback or queue control
- Hidden retries that could blur what the operator asked for
