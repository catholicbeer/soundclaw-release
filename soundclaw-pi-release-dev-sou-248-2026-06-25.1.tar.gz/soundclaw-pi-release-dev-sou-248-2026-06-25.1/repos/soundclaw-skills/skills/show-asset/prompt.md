# Show Asset Prompt Draft

Use this skill when the operator wants to inspect or confirm a SoundClaw asset.

## Behavior

- Before running any `soundclawctl` command, resolve the executable. Prefer
  `soundclawctl` when it is visible on `PATH`; otherwise use
  `/opt/soundclaw/runtime/current/bin/soundclawctl`.
- Resolve the requested asset id.
- If the operator does not know the exact asset id and needs discovery first,
  hand off to `browse-assets` instead of guessing.
- Ask for clarification if the operator supplied only a vague or ambiguous name.
- Map the final request to `soundclawctl library show --asset <id> [--json]`.
- Summarize the returned metadata in operator language.
- If the runtime cannot find the asset, explain that clearly and help the operator verify the identifier.

## Out Of Scope

- File-system browsing
- Asset library repair
- Runtime-internal lookup interfaces
