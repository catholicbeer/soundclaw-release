# Request Layer Prompt Draft

Use this skill when the operator asks SoundClaw to start, run, request, or stop
one on-demand `Layer`.

## Behavior

- Before running any `soundclawctl` command, resolve the executable. Prefer
  `soundclawctl` when it is visible on `PATH`; otherwise use
  `/opt/soundclaw/runtime/current/bin/soundclawctl`.
- Resolve one scene id, one layer id, one asset id, and one logical output.
- If the operator did not specify an output, consult
  `soundclawctl config defaults [--json]` for a runtime-owned default before
  asking a clarification question.
- Use `soundclawctl library list [--json]` or
  `soundclawctl library show --asset <id> [--json]` only when asset discovery
  or confirmation is needed.
- Use `soundclawctl outputs list [--json]` or
  `soundclawctl outputs show --output <id> [--json]` only when output
  discovery or explanation is needed.
- For a start request, call
  `soundclawctl familiar run-layer --scene <id> --layer <id> --asset <id> --output <id> [--fade-in-ms <ms>] [--json]`.
- For a stop request, call
  `soundclawctl familiar stop-layer --scene <id> --layer <id> --output <id> [--fade-out-ms <ms>] [--json]`.
- Explain accepted, running, interrupted, blocked, and failed outcomes from
  runtime-owned fields only. Preserve the runtime's reason code, manual policy
  mode, output, asset, and detail text when present.
- If the runtime reports a policy block, recovery-required block, duplicate-safe
  already-running or already-stopped result, shape mismatch, missing asset,
  missing output, interruption, or command failure, surface that result clearly
  and name the next operator-safe step.
- If the command is missing, explain that the installed runtime line does not
  expose the promoted Phase 2 one-Layer surface instead of emulating Familiar
  state locally.

## Out Of Scope

- Multi-Layer `Scene` composition
- Scheduling, queues, loops, or background execution
- Skill-owned Familiar state, cooldown tracking, or Timeline replay
- Runtime-internal IPC, private HTTP routes, or operator-console DOM scraping
- Raw channel routing, host mixer controls, service repair, or config editing
- Hidden retries that could duplicate a mutating Layer request
