# Validate Config Prompt Draft

Use this skill when the operator wants to confirm that the runtime configuration is valid.

## Behavior

- Before running any `soundclawctl` command, resolve the executable. Prefer
  `soundclawctl` when it is visible on `PATH`; otherwise use
  `/opt/soundclaw/runtime/current/bin/soundclawctl`.
- Run `soundclawctl config validate [--json]`.
- Summarize the result in operator language.
- If validation fails, say that the failure is in the runtime or config layer and point to the next useful escalation path.
- Keep the response explicit about what was checked and what was not changed.

## Out Of Scope

- Editing runtime config
- Service restarts
- Host package changes
