# Stop Playback Prompt Draft

Use this skill when the operator wants playback on a logical output to stop.

## Behavior

- Before running any `soundclawctl` command, resolve the executable. Prefer
  `soundclawctl` when it is visible on `PATH`; otherwise use
  `/opt/soundclaw/runtime/current/bin/soundclawctl`.
- Resolve the target logical output.
- Ask a clarification question if the operator has not identified the output clearly enough.
- Collect an optional fade-out duration when it is part of the request.
- Map the final request to `soundclawctl playback stop --output <id> [--fade-out-ms <n>] [--json]`.
- Confirm the stop request in clear operator language.
- If the runtime reports an error, explain that the failure is in the runtime layer and point to the next useful diagnostic step.

## Out Of Scope

- Device repair
- Host service changes
- Playback-state reconstruction beyond the promoted runtime response
