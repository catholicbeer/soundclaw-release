#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# shellcheck source=repos/soundclaw-pi-kit/lib/pi-kit.sh
source "${SCRIPT_DIR}/repos/soundclaw-pi-kit/lib/pi-kit.sh"

BUNDLE_PATH=""
BUNDLE_URL=""
PUBLIC_BUNDLE_URL=""
OPENCLAW_WORKSPACE=""
EXPECTED_PRODUCT_VERSION=""
VERIFY_ASSET_ID=""
VERIFY_OUTPUT_ID=""
EXPECTED_PHYSICAL_HOST=""
VERIFICATION_EVIDENCE=""
RUNTIME_CTL=""
POLL_ATTEMPTS=""
LOGICAL_TARGET="honcho@SoundClaw"
declare -a FORWARD_ARGS=()
declare -a TEMP_DIRS=()

cleanup_temp_dirs() {
  local status=$?
  local dir

  for dir in "${TEMP_DIRS[@]}"; do
    [[ -n "$dir" ]] || continue
    [[ -e "$dir" ]] || continue
    rm -rf "$dir" || status=$?
  done
  return "$status"
}

trap cleanup_temp_dirs EXIT

usage() {
  cat <<'EOF'
Usage: install-release.sh (--bundle-url URL | --bundle PATH --public-bundle-url URL) [verification options] [setup options]

Install the backend from one exact public catholicbeer/soundclaw-release GitHub
asset. The bundle is backend-only: runtime, config, library inputs, and bundled
pi-kit. It must not contain or install OpenClaw skills or ClawHub state.

Production verification options:
  --openclaw-workspace PATH       Active OpenClaw workspace containing the ClawHub install
  --expected-product-version VER Expected @catholicbeer/soundclaw version
  --verify-asset ID               Approved real library asset to play
  --verify-output ID              Logical output used for playback and stop
  --verification-evidence PATH   Machine-readable post-install evidence output
  --expected-physical-host NAME  Optional physical hostname assertion
  --logical-target VALUE         Logical production target; defaults to honcho@SoundClaw
  --runtime-ctl PATH              Override soundclawctl for an isolated verification environment
  --poll-attempts N               Override playback observation attempts

Bundle selection:
  --bundle-url URL                Download the exact canonical public GitHub asset
  --bundle PATH                   Use an already-downloaded copy of that asset
  --public-bundle-url URL         Required with --bundle; exact canonical public asset URL

You must still supply one library handoff mode expected by setup.sh. Other
arguments are forwarded to setup.sh. Legacy --skills-* and --skill arguments
are rejected by setup.sh.
EOF
}

github_release_base_url() {
  printf '%s\n' "${SOUNDCLAW_RELEASE_GITHUB_BASE_URL:-https://github.com/catholicbeer/soundclaw-release/releases/download}"
}

canonical_bundle_url() {
  local release_id="$1"

  printf '%s/release-bundle-%s/soundclaw-pi-release-%s.tar.gz\n' \
    "$(github_release_base_url)" "$release_id" "$release_id"
}

download_bundle() {
  local download_dir
  local bundle_name
  local download_target

  command_exists curl || die "curl is required for --bundle-url"

  download_dir="$(mktemp -d)"
  TEMP_DIRS+=("$download_dir")

  bundle_name="$(basename "${BUNDLE_URL%%\?*}")"
  [[ -n "$bundle_name" ]] || bundle_name="soundclaw-pi-release.tar.gz"
  download_target="${download_dir}/${bundle_name}"

  info "downloading release bundle from ${BUNDLE_URL}" >&2
  run_cmd curl --fail --location --silent --show-error --output "$download_target" "$BUNDLE_URL"

  printf '%s\n' "$download_target"
}

detect_bundle_root() {
  local extracted_root="$1"
  local -a top_level_entries=()

  if [[ -f "${extracted_root}/manifest.env" ]]; then
    printf '%s\n' "$extracted_root"
    return 0
  fi

  mapfile -t top_level_entries < <(find "$extracted_root" -mindepth 1 -maxdepth 1 -type d | sort)

  if [[ ${#top_level_entries[@]} -eq 1 ]] && [[ -f "${top_level_entries[0]}/manifest.env" ]]; then
    printf '%s\n' "${top_level_entries[0]}"
    return 0
  fi

  die "could not locate bundle root after extraction; expected manifest.env at the archive root or in a single top-level directory"
}

validate_archive_entries() {
  local archive_path="$1"
  local entry

  while IFS= read -r entry; do
    [[ -n "$entry" ]] || continue
    case "$entry" in
      /*|../*|*/../*|*/..)
        die "release bundle contains an unsafe archive path: ${entry}"
        ;;
    esac
  done < <(tar -tzf "$archive_path")
}

extract_bundle() {
  local archive_path="$1"
  local extract_dir
  local bundle_root

  [[ -f "$archive_path" ]] || die "release bundle archive does not exist: $archive_path"
  validate_archive_entries "$archive_path"

  extract_dir="$(mktemp -d)"
  TEMP_DIRS+=("$extract_dir")

  info "extracting release bundle ${archive_path}" >&2
  run_cmd tar -xzf "$archive_path" -C "$extract_dir"

  if find "$extract_dir" -type l -print -quit | grep -q .; then
    die "release bundle must not contain symbolic links"
  fi

  bundle_root="$(detect_bundle_root "$extract_dir")"
  printf '%s\n' "$bundle_root"
}

file_sha256() {
  local file_path="$1"

  if command_exists sha256sum; then
    sha256sum "$file_path" | awk '{print $1}'
    return 0
  fi

  if command_exists shasum; then
    shasum -a 256 "$file_path" | awk '{print $1}'
    return 0
  fi

  die "sha256 hashing requires sha256sum or shasum"
}

verify_checksums() {
  local bundle_root="$1"

  if command_exists sha256sum; then
    (cd "$bundle_root" && sha256sum --check checksums.txt)
    return 0
  fi

  if command_exists shasum; then
    (cd "$bundle_root" && shasum -a 256 --check checksums.txt)
    return 0
  fi

  die "sha256 checksum verification requires sha256sum or shasum"
}

reject_skills_payload() {
  local bundle_root="$1"
  local forbidden_path=""

  forbidden_path="$(
    find "$bundle_root" -mindepth 1 \
      \( -type d \( -name soundclaw-skills -o -name skills -o -name .clawhub \) \
      -o -type f \( -name origin.json -o -name lock.json \
        -o -name provisional-sync-skills.sh \
        -o -name '*-proof-capture.sh' \
        -o -name operator-console-proof.sh \
        -o -name runtime-discovery-check.sh \) \) \
      -print -quit
  )"
  [[ -z "$forbidden_path" ]] || die \
    "production backend bundle contains forbidden skills, ClawHub, or provisional/WDR content: ${forbidden_path}"

  if grep -Eq '^[[:space:]]*SOUNDCLAW_(SKILLS_REF|DEFAULT_SKILLS|SKILLS_[A-Z0-9_]*)=' \
    "${bundle_root}/manifest.env"; then
    die "production backend manifest contains forbidden skills metadata"
  fi
}

validate_bundle_layout() {
  local bundle_root="$1"
  local required_pi_kit_path
  local -a required_pi_kit_paths=(
    "config/profiles/shared.env"
    "config/profiles/exclusive.env"
    "lib/pi-kit.sh"
    "scripts/bootstrap.sh"
    "scripts/check-release-update.sh"
    "scripts/deploy-asset-library.sh"
    "scripts/deploy-runtime.sh"
    "scripts/deployment-status.sh"
    "scripts/fingerprint-paths.sh"
    "scripts/ingest-library.sh"
    "scripts/library-operation.sh"
    "scripts/install.sh"
    "scripts/setup.sh"
    "scripts/smoke-test.sh"
    "scripts/update-install.sh"
    "scripts/verify-production-install.sh"
    "systemd/soundclaw-runtime.service.in"
  )

  [[ -f "${bundle_root}/manifest.env" ]] || die "release bundle is missing manifest.env: ${bundle_root}"
  [[ -f "${bundle_root}/checksums.txt" ]] || die "release bundle is missing checksums.txt: ${bundle_root}"
  [[ -d "${bundle_root}/runtime" ]] || die "release bundle is missing runtime/: ${bundle_root}"
  [[ -f "${bundle_root}/config/runtime.toml" ]] || die "release bundle is missing config/runtime.toml: ${bundle_root}"
  for required_pi_kit_path in "${required_pi_kit_paths[@]}"; do
    [[ -e "${bundle_root}/repos/soundclaw-pi-kit/${required_pi_kit_path}" ]] || die \
      "release bundle is missing pi-kit install payload path ${required_pi_kit_path}: ${bundle_root}"
  done

  reject_skills_payload "$bundle_root"

  if find "$bundle_root" -path '*/.git' -print -quit | grep -q .; then
    die "release bundle must not include Git metadata: ${bundle_root}"
  fi

  verify_complete_checksum_inventory "$bundle_root"
  verify_checksums "$bundle_root"
}

validate_manifest() {
  [[ "${SOUNDCLAW_RELEASE_ID:-}" =~ ^[A-Za-z0-9._-]+$ ]] || die \
    "bundle manifest has a missing or invalid SOUNDCLAW_RELEASE_ID"
  [[ "${SOUNDCLAW_RUNTIME_REF:-}" =~ ^[0-9a-fA-F]{40}$ ]] || die \
    "bundle manifest SOUNDCLAW_RUNTIME_REF must be an exact commit SHA"
  [[ -n "${SOUNDCLAW_RUNTIME_CONFIG_REF:-}" ]] || die "bundle manifest is missing SOUNDCLAW_RUNTIME_CONFIG_REF"
  [[ "${SOUNDCLAW_PI_KIT_REF:-}" =~ ^[0-9a-fA-F]{40}$ ]] || die \
    "bundle manifest SOUNDCLAW_PI_KIT_REF must be an exact commit SHA"
}

validate_public_source() {
  local expected_url

  if is_live_root && [[ -n "${SOUNDCLAW_RELEASE_GITHUB_BASE_URL:-}" ]]; then
    die "SOUNDCLAW_RELEASE_GITHUB_BASE_URL is test-only and forbidden for live production installation"
  fi
  expected_url="$(canonical_bundle_url "$SOUNDCLAW_RELEASE_ID")"
  [[ "$PUBLIC_BUNDLE_URL" == "$expected_url" ]] || die \
    "production backend source must be the exact public GitHub release asset: ${expected_url}"
}

run_verifier_snapshot() {
  local verifier="$1"
  local snapshot="$2"

  "$verifier" snapshot \
    --workspace "$OPENCLAW_WORKSPACE" \
    --expected-version "$EXPECTED_PRODUCT_VERSION" \
    --output "$snapshot"
}

run_verifier_post_install() {
  local verifier="$1"
  local snapshot="$2"
  local bundle_sha256="$3"
  local -a args=(
    verify
    --workspace "$OPENCLAW_WORKSPACE"
    --before "$snapshot"
    --expected-version "$EXPECTED_PRODUCT_VERSION"
    --release-id "$SOUNDCLAW_RELEASE_ID"
    --bundle-url "$PUBLIC_BUNDLE_URL"
    --bundle-asset "$(basename "$PUBLIC_BUNDLE_URL")"
    --bundle-sha256 "$bundle_sha256"
    --logical-target "$LOGICAL_TARGET"
    --asset "$VERIFY_ASSET_ID"
    --output-id "$VERIFY_OUTPUT_ID"
    --evidence-output "$VERIFICATION_EVIDENCE"
  )

  [[ -z "$EXPECTED_PHYSICAL_HOST" ]] || args+=(--expected-physical-host "$EXPECTED_PHYSICAL_HOST")
  [[ -z "$RUNTIME_CTL" ]] || args+=(--runtime-ctl "$RUNTIME_CTL")
  [[ -z "$POLL_ATTEMPTS" ]] || args+=(--poll-attempts "$POLL_ATTEMPTS")

  "$verifier" "${args[@]}"
}

main() {
  local archive_path=""
  local bundle_root=""
  local bundle_asset=""
  local manifest_sha256=""
  local checksums_sha256=""
  local bundle_sha256=""
  local source_tuple=""
  local verifier=""
  local provenance_snapshot=""
  local verification_requested=0
  local -a setup_args=()

  while [[ $# -gt 0 ]]; do
    case "$1" in
      --bundle) BUNDLE_PATH="${2:?--bundle requires a value}"; shift 2 ;;
      --bundle-url) BUNDLE_URL="${2:?--bundle-url requires a value}"; shift 2 ;;
      --public-bundle-url) PUBLIC_BUNDLE_URL="${2:?--public-bundle-url requires a value}"; shift 2 ;;
      --openclaw-workspace) OPENCLAW_WORKSPACE="${2:?--openclaw-workspace requires a value}"; shift 2 ;;
      --expected-product-version) EXPECTED_PRODUCT_VERSION="${2:?--expected-product-version requires a value}"; shift 2 ;;
      --verify-asset) VERIFY_ASSET_ID="${2:?--verify-asset requires a value}"; shift 2 ;;
      --verify-output) VERIFY_OUTPUT_ID="${2:?--verify-output requires a value}"; shift 2 ;;
      --verification-evidence) VERIFICATION_EVIDENCE="${2:?--verification-evidence requires a value}"; shift 2 ;;
      --expected-physical-host) EXPECTED_PHYSICAL_HOST="${2:?--expected-physical-host requires a value}"; shift 2 ;;
      --logical-target) LOGICAL_TARGET="${2:?--logical-target requires a value}"; shift 2 ;;
      --runtime-ctl) RUNTIME_CTL="${2:?--runtime-ctl requires a value}"; shift 2 ;;
      --poll-attempts) POLL_ATTEMPTS="${2:?--poll-attempts requires a value}"; shift 2 ;;
      --help|-h) usage; exit 0 ;;
      *) FORWARD_ARGS+=("$1"); shift ;;
    esac
  done

  [[ -z "$BUNDLE_PATH" || -z "$BUNDLE_URL" ]] || die "choose either --bundle or --bundle-url"
  [[ -n "$BUNDLE_PATH" || -n "$BUNDLE_URL" ]] || die "either --bundle or --bundle-url is required"

  if [[ -n "$BUNDLE_URL" ]]; then
    [[ -z "$PUBLIC_BUNDLE_URL" || "$PUBLIC_BUNDLE_URL" == "$BUNDLE_URL" ]] || die \
      "--public-bundle-url must match --bundle-url when both are supplied"
    PUBLIC_BUNDLE_URL="$BUNDLE_URL"
    archive_path="$(download_bundle)"
  else
    [[ -n "$PUBLIC_BUNDLE_URL" ]] || die "--public-bundle-url is required with --bundle"
    archive_path="$BUNDLE_PATH"
  fi

  bundle_root="$(extract_bundle "$archive_path")"
  validate_bundle_layout "$bundle_root"

  # shellcheck disable=SC1090
  source "${bundle_root}/manifest.env"
  validate_manifest
  validate_public_source

  verifier="${bundle_root}/repos/soundclaw-pi-kit/scripts/verify-production-install.sh"
  bundle_asset="$(basename "$PUBLIC_BUNDLE_URL")"
  manifest_sha256="$(file_sha256 "${bundle_root}/manifest.env")"
  checksums_sha256="$(file_sha256 "${bundle_root}/checksums.txt")"
  bundle_sha256="$(file_sha256 "$archive_path")"
  source_tuple="runtime=${SOUNDCLAW_RUNTIME_REF} runtime_config=${SOUNDCLAW_RUNTIME_CONFIG_REF} pi_kit=${SOUNDCLAW_PI_KIT_REF}"
  [[ -z "${SOUNDCLAW_LIBRARY_RELEASE_REF:-}" ]] || source_tuple+=" library=${SOUNDCLAW_LIBRARY_RELEASE_REF}"

  if [[ -n "$OPENCLAW_WORKSPACE$EXPECTED_PRODUCT_VERSION$VERIFY_ASSET_ID$VERIFY_OUTPUT_ID$VERIFICATION_EVIDENCE" ]]; then
    verification_requested=1
    [[ -n "$OPENCLAW_WORKSPACE" ]] || die "--openclaw-workspace is required for production verification"
    [[ -n "$EXPECTED_PRODUCT_VERSION" ]] || die "--expected-product-version is required for production verification"
    [[ -n "$VERIFY_ASSET_ID" ]] || die "--verify-asset is required for production verification"
    [[ -n "$VERIFY_OUTPUT_ID" ]] || die "--verify-output is required for production verification"
    [[ -n "$VERIFICATION_EVIDENCE" ]] || die "--verification-evidence is required for production verification"
  fi

  if is_live_root; then
    [[ "$verification_requested" == "1" ]] || die \
      "live production install requires ClawHub provenance, real asset/output, and evidence options"
    [[ -n "$EXPECTED_PHYSICAL_HOST" ]] || die \
      "live production install requires --expected-physical-host"
    [[ -z "$RUNTIME_CTL" ]] || die \
      "--runtime-ctl is test-only and forbidden for live production installation"
  fi

  if [[ "$verification_requested" == "1" ]]; then
    provenance_snapshot="$(mktemp)"
    TEMP_DIRS+=("$provenance_snapshot")
    run_verifier_snapshot "$verifier" "$provenance_snapshot"
  fi

  setup_args=(
    --runtime-source "${bundle_root}/runtime"
    --runtime-release-ref "runtime-${SOUNDCLAW_RUNTIME_REF:0:7}"
    --runtime-config "${bundle_root}/config/runtime.toml"
    --runtime-config-ref "$SOUNDCLAW_RUNTIME_CONFIG_REF"
    --public-release-id "$SOUNDCLAW_RELEASE_ID"
    --public-bundle-source "$PUBLIC_BUNDLE_URL"
    --public-bundle-asset "$bundle_asset"
    --public-manifest-sha256 "$manifest_sha256"
    --public-checksums-sha256 "$checksums_sha256"
    --public-source-tuple "$source_tuple"
  )
  [[ -z "${SOUNDCLAW_LIBRARY_RELEASE_REF:-}" ]] || setup_args+=(--library-release-ref "$SOUNDCLAW_LIBRARY_RELEASE_REF")
  [[ -z "${SOUNDCLAW_PI_KIT_REF:-}" ]] || setup_args+=(--pi-kit-ref "$SOUNDCLAW_PI_KIT_REF")

  info "running backend-only setup flow from release bundle ${SOUNDCLAW_RELEASE_ID}"
  "${bundle_root}/repos/soundclaw-pi-kit/scripts/setup.sh" "${setup_args[@]}" "${FORWARD_ARGS[@]}"

  if [[ "$verification_requested" == "1" ]]; then
    run_verifier_post_install "$verifier" "$provenance_snapshot" "$bundle_sha256"
  fi
}

main "$@"
