#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# shellcheck source=../lib/pi-kit.sh
source "${SCRIPT_DIR}/../lib/pi-kit.sh"

SOURCE_DIR=""
RELEASE_REF=""
OPERATION_ID=""
EXPECTED_REVISION=""
CANDIDATE_REVISION=""
RECOVERY_RESULT="not_required"
ASSET_LIBRARY_REF=""

usage() {
  cat <<'EOF'
Usage: deploy-asset-library.sh --source /path/to/library-snapshot [--release-ref value] [--operation-id UUID --expected-revision SHA256 --candidate-revision SHA256] [--dry-run]

Copy a prepared asset-library snapshot into the host's library directory. The
source must contain index.json and an assets/ directory.
EOF
}

validate_library_source() {
  [[ -n "$SOURCE_DIR" ]] || die "--source is required"
  [[ -d "$SOURCE_DIR" ]] || die "library source directory does not exist: $SOURCE_DIR"
  [[ -f "${SOURCE_DIR%/}/index.json" ]] || die "library source must include index.json: $SOURCE_DIR"
  [[ -d "${SOURCE_DIR%/}/assets" ]] || die "library source must include assets/: $SOURCE_DIR"
  [[ ! -L "${SOURCE_DIR%/}/index.json" ]] || die "library index must not be a symlink: $SOURCE_DIR"
  [[ ! -L "${SOURCE_DIR%/}/assets" ]] || die "library assets directory must not be a symlink: $SOURCE_DIR"
  command_exists python3 || die "python3 is required to validate the library snapshot"
  python3 - "$SOURCE_DIR" <<'PY'
import json
import pathlib
import re
import sys

root = pathlib.Path(sys.argv[1]).resolve()
data = json.loads((root / "index.json").read_text(encoding="utf-8"))
if not isinstance(data, dict) or not isinstance(data.get("assets"), list):
    raise SystemExit("library index must contain an assets array")
revision = data.get("library_revision")
if revision is not None and not re.fullmatch(r"[0-9a-f]{64}", revision):
    raise SystemExit("library_revision must be 64 lowercase hexadecimal characters")
seen_ids = set()
seen_paths = set()
for offset, asset in enumerate(data["assets"]):
    if not isinstance(asset, dict):
        raise SystemExit(f"assets[{offset}] must be an object")
    asset_id = asset.get("id")
    relative = asset.get("relative_path")
    asset_format = asset.get("format")
    if not isinstance(asset_id, str) or not asset_id:
        raise SystemExit(f"assets[{offset}].id must be a non-empty string")
    if asset_id in seen_ids:
        raise SystemExit(f"duplicate asset id: {asset_id}")
    seen_ids.add(asset_id)
    if asset_format not in {"flac", "wav", "mp3"}:
        raise SystemExit(f"asset {asset_id} uses unsupported format: {asset_format}")
    if not isinstance(relative, str) or not relative:
        raise SystemExit(f"asset {asset_id} relative_path must be a non-empty string")
    parsed = pathlib.PurePosixPath(relative)
    if parsed.is_absolute() or "." in parsed.parts or ".." in parsed.parts:
        raise SystemExit(f"asset {asset_id} uses unsafe relative_path: {relative}")
    if relative in seen_paths:
        raise SystemExit(f"duplicate relative_path: {relative}")
    seen_paths.add(relative)
    if parsed.suffix.lower() != f".{asset_format}":
        raise SystemExit(f"asset {asset_id} format does not match relative_path")
    media = root / "assets" / pathlib.Path(*parsed.parts)
    if not media.is_file():
        raise SystemExit(f"asset {asset_id} media is missing: {relative}")
    if media.is_symlink():
        raise SystemExit(f"asset {asset_id} media must not be a symlink: {relative}")
    try:
        media.resolve(strict=True).relative_to((root / "assets").resolve(strict=True))
    except (FileNotFoundError, RuntimeError, ValueError):
        raise SystemExit(f"asset {asset_id} media escapes the snapshot: {relative}")
PY
}

library_revision_from_index() {
  local index_path="$1"
  if [[ ! -f "$index_path" ]]; then
    printf 'none\n'
    return 0
  fi
  python3 - "$index_path" <<'PY'
import json
import sys

try:
    data = json.load(open(sys.argv[1], encoding="utf-8"))
except (OSError, ValueError):
    print("unknown")
else:
    print(data.get("library_revision") or "unversioned")
PY
}

write_library_state() {
  local state_file
  local deployed_at
  local library_index
  local library_assets
  local previous_revision="$1"
  local current_revision="$2"
  local state_candidate

  state_file="$(root_path "$(library_deploy_state_path)")"
  state_candidate="${state_file}.candidate.$$"
  [[ "$DRY_RUN" != "1" ]] || state_candidate="$state_file"
  deployed_at="$(timestamp_utc)"
  library_index="$(library_index_path)"
  library_assets="$(library_assets_dir)"

  if ! write_text_file "$state_candidate" <<EOF
LIBRARY_SOURCE=${SOURCE_DIR@Q}
LIBRARY_RELEASE_REF=${RELEASE_REF@Q}
LIBRARY_DEPLOYED_AT=${deployed_at@Q}
LIBRARY_TARGET=${SC_LIBRARY_DIR@Q}
LIBRARY_INDEX_PATH=${library_index@Q}
LIBRARY_ASSETS_DIR=${library_assets@Q}
LIBRARY_PREVIOUS_REVISION=${previous_revision@Q}
LIBRARY_REVISION=${current_revision@Q}
LIBRARY_OPERATION_ID=${OPERATION_ID@Q}
LIBRARY_EXPECTED_REVISION=${EXPECTED_REVISION@Q}
LIBRARY_CANDIDATE_REVISION=${CANDIDATE_REVISION@Q}
LIBRARY_OPERATION_ASSET_LIBRARY_REF=${ASSET_LIBRARY_REF@Q}
LIBRARY_RECOVERY_RESULT=${RECOVERY_RESULT@Q}
LIBRARY_PROMOTION_RESULT='OK'
EOF
  then
    rm -f "$state_candidate"
    return 1
  fi
  [[ "$DRY_RUN" != "1" ]] || return 0
  if ! mv -T "$state_candidate" "$state_file"; then
    rm -f "$state_candidate"
    return 1
  fi
  normalize_library_state_file_permissions
}

main() {
  local target_dir
  local candidate_dir
  local previous_dir
  local previous_revision
  local candidate_revision
  local had_previous=0
  local operation_evidence_count=0
  while [[ $# -gt 0 ]]; do
    case "$1" in
      --source)
        [[ $# -ge 2 ]] || die "--source requires a value"
        SOURCE_DIR="$2"
        shift 2
        ;;
      --release-ref)
        [[ $# -ge 2 ]] || die "--release-ref requires a value"
        RELEASE_REF="$2"
        shift 2
        ;;
      --operation-id)
        [[ $# -ge 2 ]] || die "--operation-id requires a value"
        OPERATION_ID="$2"
        shift 2
        ;;
      --expected-revision)
        [[ $# -ge 2 ]] || die "--expected-revision requires a value"
        EXPECTED_REVISION="$2"
        shift 2
        ;;
      --candidate-revision)
        [[ $# -ge 2 ]] || die "--candidate-revision requires a value"
        CANDIDATE_REVISION="$2"
        shift 2
        ;;
      --asset-library-ref)
        [[ $# -ge 2 ]] || die "--asset-library-ref requires a value"
        ASSET_LIBRARY_REF="$2"
        shift 2
        ;;
      --dry-run)
        DRY_RUN=1
        shift
        ;;
      --help|-h)
        usage
        exit 0
        ;;
      *)
        die "unknown argument: $1"
        ;;
    esac
  done

  [[ -z "$OPERATION_ID" ]] || operation_evidence_count=$((operation_evidence_count + 1))
  [[ -z "$EXPECTED_REVISION" ]] || operation_evidence_count=$((operation_evidence_count + 1))
  [[ -z "$CANDIDATE_REVISION" ]] || operation_evidence_count=$((operation_evidence_count + 1))
  [[ "$operation_evidence_count" == "0" || "$operation_evidence_count" == "3" ]] || die \
    "operation id, expected revision, and candidate revision must be supplied together"

  validate_library_source

  if [[ -z "$RELEASE_REF" ]]; then
    RELEASE_REF="$(basename "$SOURCE_DIR")"
  fi

  ensure_library_dir_access

  target_dir="$(root_path "${SC_LIBRARY_DIR}")"
  candidate_dir="${target_dir}.candidate.$$"
  previous_dir="${target_dir}.previous"
  candidate_revision="$(library_revision_from_index "${SOURCE_DIR%/}/index.json")"
  previous_revision="$(library_revision_from_index "${target_dir%/}/index.json")"
  [[ -n "$CANDIDATE_REVISION" ]] || CANDIDATE_REVISION="$candidate_revision"
  [[ "$CANDIDATE_REVISION" == "$candidate_revision" ]] || die \
    "candidate revision evidence does not match the validated snapshot"
  info "staging validated asset-library snapshot from ${SOURCE_DIR}"
  run_cmd rm -rf "$candidate_dir" "$previous_dir"
  run_cmd mkdir -p "$candidate_dir"
  run_cmd cp -a "${SOURCE_DIR}/." "${candidate_dir}/"
  if [[ "$DRY_RUN" == "1" ]]; then
    run_cmd mv "$target_dir" "$previous_dir"
    run_cmd mv "$candidate_dir" "$target_dir"
    run_cmd rm -rf "$previous_dir"
  else
    if [[ -e "$target_dir" ]]; then
      mv "$target_dir" "$previous_dir"
      had_previous=1
    fi
    if ! mv "$candidate_dir" "$target_dir"; then
      if [[ "$had_previous" == "1" && -e "$previous_dir" ]] && \
        ! mv "$previous_dir" "$target_dir"; then
        die "failed_recovery_required: atomic promotion failed and the previous snapshot could not be restored from ${previous_dir}"
      fi
      die "asset library atomic promotion failed; previous snapshot restored"
    fi
    if ! {
      normalize_library_permissions
      write_library_state "$previous_revision" "$candidate_revision"
    }; then
      rm -rf "$target_dir"
      if [[ "$had_previous" == "1" && -e "$previous_dir" ]]; then
        if ! mv "$previous_dir" "$target_dir"; then
          die "failed_recovery_required: promotion finalization failed and the previous snapshot could not be restored from ${previous_dir}"
        fi
      fi
      die "asset library promotion finalization failed; previous snapshot restored"
    fi
    rm -rf "$previous_dir"
  fi
  if [[ "$DRY_RUN" == "1" ]]; then
    normalize_library_permissions
    write_library_state "$previous_revision" "$candidate_revision"
  fi

  info "asset library deploy complete"
}

main "$@"
