#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# shellcheck source=../lib/pi-kit.sh
source "${SCRIPT_DIR}/../lib/pi-kit.sh"

ASSET_LIBRARY_ROOT=""
SOURCE_DIR=""
INTAKE_ROOT=""
SOURCE_RELATIVE=""
FACET_PLAN_JSON=""
FACET_APPLY_JSON=""
RELEASE_REF=""
ASSET_LIBRARY_REF=""

usage() {
  cat <<'EOF'
Usage:
  library-operation.sh --asset-library-root PATH --intake-root PATH --source-relative DESCENDANT [--release-ref REF] [--asset-library-ref REF]
  library-operation.sh --asset-library-root PATH --facet-plan-json JSON
  library-operation.sh --asset-library-root PATH --facet-apply-json JSON [--release-ref REF] [--asset-library-ref REF]

Resolve one safe allowlisted intake descendant or delegate one reviewed,
revision-bound facet plan/apply to soundclaw-asset-library. Apply validates a
published candidate before Pi-kit atomically promotes it.
EOF
}

asset_script() {
  printf '%s\n' "${ASSET_LIBRARY_ROOT%/}/scripts/$1"
}

validate_asset_library_root() {
  [[ -n "$ASSET_LIBRARY_ROOT" ]] || die "--asset-library-root is required"
  [[ -d "$ASSET_LIBRARY_ROOT" ]] || die \
    "asset-library root directory does not exist: $ASSET_LIBRARY_ROOT"
  [[ -f "$(asset_script facets.py)" ]] || die \
    "asset-library root is missing scripts/facets.py: $ASSET_LIBRARY_ROOT"
  [[ -f "$(asset_script publish-library.py)" ]] || die \
    "asset-library root is missing scripts/publish-library.py: $ASSET_LIBRARY_ROOT"
  [[ -f "$(asset_script validate-library.py)" ]] || die \
    "asset-library root is missing scripts/validate-library.py: $ASSET_LIBRARY_ROOT"
  command_exists python3 || die "python3 is required for library operations"
}

restore_authoring_state() {
  local backup_root="$1"

  [[ -d "$backup_root" ]] || return 0
  rm -rf "${ASSET_LIBRARY_ROOT%/}/catalog"
  cp -a "${backup_root}/catalog" "${ASSET_LIBRARY_ROOT%/}/catalog"
  rm -f "${ASSET_LIBRARY_ROOT%/}/index.json"
  [[ ! -f "${backup_root}/index.json" ]] || \
    cp -a "${backup_root}/index.json" "${ASSET_LIBRARY_ROOT%/}/index.json"
  rm -rf "${ASSET_LIBRARY_ROOT%/}/.soundclaw"
  [[ ! -d "${backup_root}/.soundclaw" ]] || \
    cp -a "${backup_root}/.soundclaw" "${ASSET_LIBRARY_ROOT%/}/.soundclaw"
}

run_facet_plan() {
  local work_dir="$1"
  local changes_file="${work_dir}/changes.json"

  printf '%s\n' "$FACET_PLAN_JSON" >"$changes_file"
  env LC_ALL=C.UTF-8 LANG=C.UTF-8 python3 \
    "$(asset_script facets.py)" \
    --root "$ASSET_LIBRARY_ROOT" \
    plan \
    --changes "$changes_file"
}

run_facet_apply() {
  local work_dir="$1"
  local backup_root="${work_dir}/authoring-backup"
  local changes_file="${work_dir}/changes.json"
  local apply_output="${work_dir}/facet-apply.json"
  local publish_dir="${work_dir}/published-library"
  local deploy_output="${work_dir}/deploy.out"
  local deploy_error="${work_dir}/deploy.err"
  local authoring_mutated=0
  local promotion_complete=0
  local operation_id
  local expected_revision
  local candidate_revision
  local -a operation_evidence=()

  mkdir -p "$backup_root"
  cp -a "${ASSET_LIBRARY_ROOT%/}/catalog" "${backup_root}/catalog"
  [[ ! -f "${ASSET_LIBRARY_ROOT%/}/index.json" ]] || \
    cp -a "${ASSET_LIBRARY_ROOT%/}/index.json" "${backup_root}/index.json"
  [[ ! -d "${ASSET_LIBRARY_ROOT%/}/.soundclaw" ]] || \
    cp -a "${ASSET_LIBRARY_ROOT%/}/.soundclaw" "${backup_root}/.soundclaw"
  printf '%s\n' "$FACET_APPLY_JSON" >"$changes_file"

  facet_apply_cleanup() {
    local status=$?
    trap - RETURN
    if [[ "$status" -ne 0 && "$authoring_mutated" == "1" && "$promotion_complete" != "1" ]]; then
      restore_authoring_state "$backup_root"
      printf '%s\n' \
        '{"outcome":"failed","recovery":"authoring_restored","live_library":"unchanged"}'
    fi
    return "$status"
  }
  trap facet_apply_cleanup RETURN

  if ! env LC_ALL=C.UTF-8 LANG=C.UTF-8 python3 \
    "$(asset_script facets.py)" \
    --root "$ASSET_LIBRARY_ROOT" \
    apply \
    --changes "$changes_file" \
    >"$apply_output"; then
    cat "$apply_output"
    return 1
  fi
  authoring_mutated=1

  readarray -t operation_evidence < <(
    python3 - "$changes_file" "$apply_output" <<'PY'
import json
import sys

request = json.load(open(sys.argv[1], encoding="utf-8"))
result = json.load(open(sys.argv[2], encoding="utf-8"))
print(request["operation_id"])
print(request["expected_revision"])
print(result["candidate_revision"])
PY
  )
  operation_id="${operation_evidence[0]}"
  expected_revision="${operation_evidence[1]}"
  candidate_revision="${operation_evidence[2]}"

  env LC_ALL=C.UTF-8 LANG=C.UTF-8 python3 \
    "$(asset_script publish-library.py)" \
    --root "$ASSET_LIBRARY_ROOT" \
    --target "$publish_dir" \
    >"${work_dir}/publish.out"
  env LC_ALL=C.UTF-8 LANG=C.UTF-8 python3 \
    "$(asset_script validate-library.py)" \
    --root "$publish_dir" \
    >"${work_dir}/validate.out"

  if [[ -z "$RELEASE_REF" ]]; then
    RELEASE_REF="facet-$(python3 -c 'import json,sys; print(json.load(open(sys.argv[1]))["operation_id"])' "$apply_output")"
  fi
  local -a deploy_args=(
    --source "$publish_dir"
    --release-ref "$RELEASE_REF"
    --operation-id "$operation_id"
    --expected-revision "$expected_revision"
    --candidate-revision "$candidate_revision"
  )
  [[ -z "$ASSET_LIBRARY_REF" ]] || \
    deploy_args+=(--asset-library-ref "$ASSET_LIBRARY_REF")
  if ! "${SCRIPT_DIR}/deploy-asset-library.sh" \
    "${deploy_args[@]}" >"$deploy_output" 2>"$deploy_error"; then
    cat "$deploy_error" >&2
    if grep -q 'failed_recovery_required' "$deploy_error"; then
      restore_authoring_state "$backup_root"
      authoring_mutated=0
      printf '%s\n' \
        '{"outcome":"failed_recovery_required","recovery":"manual_required","live_library":"unknown"}'
    fi
    return 1
  fi
  promotion_complete=1

  python3 - "$apply_output" "$(root_path "$(library_deploy_state_path)")" <<'PY'
import json
import shlex
import sys

result = json.load(open(sys.argv[1], encoding="utf-8"))
state = {}
for line in open(sys.argv[2], encoding="utf-8"):
    key, separator, value = line.rstrip("\n").partition("=")
    if separator:
        try:
            state[key] = shlex.split(value)[0]
        except (IndexError, ValueError):
            state[key] = value
result["outcome"] = "completed"
result["previous_live_revision"] = state.get("LIBRARY_PREVIOUS_REVISION", "unknown")
result["promoted_revision"] = state.get("LIBRARY_REVISION", "unknown")
result["recovery"] = "not_required"
print(json.dumps(result, ensure_ascii=False, sort_keys=True))
PY
}

main() {
  local mode_count=0
  local work_dir

  while [[ $# -gt 0 ]]; do
    case "$1" in
      --asset-library-root)
        [[ $# -ge 2 ]] || die "--asset-library-root requires a value"
        ASSET_LIBRARY_ROOT="$2"
        shift 2
        ;;
      --source)
        [[ $# -ge 2 ]] || die "--source requires a value"
        SOURCE_DIR="$2"
        shift 2
        ;;
      --intake-root)
        [[ $# -ge 2 ]] || die "--intake-root requires a value"
        INTAKE_ROOT="$2"
        shift 2
        ;;
      --source-relative)
        [[ $# -ge 2 ]] || die "--source-relative requires a value"
        SOURCE_RELATIVE="$2"
        shift 2
        ;;
      --facet-plan-json)
        [[ $# -ge 2 ]] || die "--facet-plan-json requires a value"
        FACET_PLAN_JSON="$2"
        shift 2
        ;;
      --facet-apply-json)
        [[ $# -ge 2 ]] || die "--facet-apply-json requires a value"
        FACET_APPLY_JSON="$2"
        shift 2
        ;;
      --release-ref)
        [[ $# -ge 2 ]] || die "--release-ref requires a value"
        RELEASE_REF="$2"
        shift 2
        ;;
      --asset-library-ref)
        [[ $# -ge 2 ]] || die "--asset-library-ref requires a value"
        ASSET_LIBRARY_REF="$2"
        shift 2
        ;;
      --help|-h)
        usage
        exit 0
        ;;
      *)
        die "unknown argument: $1"
        ;;
    esac
  done

  [[ -z "$SOURCE_DIR" && -z "$SOURCE_RELATIVE" ]] || mode_count=$((mode_count + 1))
  [[ -z "$FACET_PLAN_JSON" ]] || mode_count=$((mode_count + 1))
  [[ -z "$FACET_APPLY_JSON" ]] || mode_count=$((mode_count + 1))
  [[ "$mode_count" == "1" ]] || die "choose exactly one import, facet plan, or facet apply operation"

  validate_asset_library_root
  ensure_asset_library_authoring_access "$ASSET_LIBRARY_ROOT"
  work_dir="$(mktemp -d)"
  trap '[[ -z "${work_dir:-}" ]] || rm -rf "$work_dir"' EXIT

  if [[ -n "$FACET_PLAN_JSON" ]]; then
    run_facet_plan "$work_dir"
  elif [[ -n "$FACET_APPLY_JSON" ]]; then
    run_facet_apply "$work_dir"
  else
    local -a ingest_args=(
      --asset-library-root "$ASSET_LIBRARY_ROOT"
    )
    if [[ -n "$SOURCE_RELATIVE" ]]; then
      [[ -n "$INTAKE_ROOT" ]] || die "--intake-root is required with --source-relative"
      ingest_args+=(--intake-root "$INTAKE_ROOT" --source-relative "$SOURCE_RELATIVE")
    else
      ingest_args+=(--source "$SOURCE_DIR")
    fi
    [[ -z "$RELEASE_REF" ]] || ingest_args+=(--release-ref "$RELEASE_REF")
    [[ -z "$ASSET_LIBRARY_REF" ]] || \
      ingest_args+=(--asset-library-ref "$ASSET_LIBRARY_REF")
    exec "${SCRIPT_DIR}/ingest-library.sh" "${ingest_args[@]}"
  fi
}

main "$@"
