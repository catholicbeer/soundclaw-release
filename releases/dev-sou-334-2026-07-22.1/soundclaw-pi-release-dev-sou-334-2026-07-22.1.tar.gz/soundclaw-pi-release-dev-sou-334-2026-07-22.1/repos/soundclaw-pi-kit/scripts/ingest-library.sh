#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# shellcheck source=../lib/pi-kit.sh
source "${SCRIPT_DIR}/../lib/pi-kit.sh"

ASSET_LIBRARY_ROOT=""
SOURCE_DIR=""
INTAKE_ROOT_OVERRIDE=""
SOURCE_RELATIVE=""
RELEASE_REF=""
ASSET_LIBRARY_REF_OVERRIDE=""

usage() {
  cat <<'EOF'
Usage: ingest-library.sh --asset-library-root /path/to/soundclaw-asset-library [--source /var/lib/soundclaw/library-intake/name | --intake-root /var/lib/soundclaw/library-intake --source-relative descendant] [--release-ref value] [--asset-library-ref value]

Import local intake media through soundclaw-asset-library using source-preserving
copy mode, publish a runtime-facing snapshot, validate it, and deploy it to the
host library path.

The source defaults to /var/lib/soundclaw/library-intake and must stay under the
configured library-intake directory.
EOF
}

asset_library_script_path() {
  printf '%s\n' "${ASSET_LIBRARY_ROOT%/}/scripts/$1"
}

resolve_repo_ref() {
  local repo_path="$1"
  local ref_override="$2"
  local repo_label="$3"
  local detected_ref=""

  if [[ -n "$ref_override" ]]; then
    printf '%s\n' "$ref_override"
    return 0
  fi

  if command_exists git; then
    detected_ref="$(git -C "$repo_path" rev-parse HEAD 2>/dev/null || true)"

    if [[ -n "$detected_ref" ]]; then
      printf '%s\n' "$detected_ref"
      return 0
    fi
  fi

  if [[ -d "${repo_path%/}/.git" ]]; then
    warn "could not resolve a Git ref for ${repo_label} at ${repo_path}; recording 'unknown' in ingest evidence"
  fi

  printf 'unknown\n'
}

validate_inputs() {
  local intake_root
  local source_real
  local intake_real

  [[ -n "$ASSET_LIBRARY_ROOT" ]] || die "--asset-library-root is required"
  [[ -d "$ASSET_LIBRARY_ROOT" ]] || die "asset-library root directory does not exist: $ASSET_LIBRARY_ROOT"
  [[ -f "$(asset_library_script_path import-assets.py)" ]] || die \
    "asset-library root is missing scripts/import-assets.py: $ASSET_LIBRARY_ROOT"
  [[ -f "$(asset_library_script_path publish-library.py)" ]] || die \
    "asset-library root is missing scripts/publish-library.py: $ASSET_LIBRARY_ROOT"
  [[ -f "$(asset_library_script_path validate-library.py)" ]] || die \
    "asset-library root is missing scripts/validate-library.py: $ASSET_LIBRARY_ROOT"
  command_exists python3 || die "python3 is required for asset-library ingest"

  if [[ -n "$SOURCE_DIR" && -n "$SOURCE_RELATIVE" ]]; then
    die "choose either --source or --source-relative, not both"
  fi

  if [[ -n "$INTAKE_ROOT_OVERRIDE" ]]; then
    [[ "$INTAKE_ROOT_OVERRIDE" == /* ]] || die "--intake-root must be absolute"
    intake_root="$INTAKE_ROOT_OVERRIDE"
  else
    intake_root="$(root_path "$SC_LIBRARY_INTAKE_DIR")"
  fi

  if [[ -n "$SOURCE_RELATIVE" ]]; then
    SOURCE_DIR="$(
      python3 - "$intake_root" "$SOURCE_RELATIVE" <<'PY'
import pathlib
import re
import sys

root = pathlib.Path(sys.argv[1])
selector = sys.argv[2]
relative = pathlib.PurePosixPath(selector)
if (
    not selector
    or relative.is_absolute()
    or selector.startswith(("\\\\", "//"))
    or "\\" in selector
    or re.match(r"^[A-Za-z]:", selector)
    or "." in relative.parts
    or ".." in relative.parts
    or any(ord(character) < 32 or ord(character) == 127 for character in selector)
):
    raise SystemExit("source-relative must be a non-empty relative descendant")
try:
    root_real = root.resolve(strict=True)
    source_real = (root_real / pathlib.Path(*relative.parts)).resolve(strict=True)
    source_real.relative_to(root_real)
except (FileNotFoundError, RuntimeError, ValueError):
    raise SystemExit("source-relative is unavailable or escapes the allowlisted intake root")
if source_real == root_real or not source_real.is_dir():
    raise SystemExit("source-relative must resolve to a directory strictly beneath the intake root")
for child in source_real.rglob("*"):
    if child.is_symlink():
        try:
            child.resolve(strict=True).relative_to(root_real)
        except (FileNotFoundError, RuntimeError, ValueError):
            raise SystemExit(f"source-relative contains a symlink escape: {child.relative_to(source_real)}")
print(source_real)
PY
    )" || die "unsafe library intake selection: ${SOURCE_RELATIVE}"
  elif [[ -z "$SOURCE_DIR" ]]; then
    SOURCE_DIR="$(root_path "$SC_LIBRARY_INTAKE_DIR")"
  fi

  [[ -d "$SOURCE_DIR" ]] || die "library ingest source directory does not exist: $SOURCE_DIR"

  source_real="$(realpath -m "$SOURCE_DIR")"
  intake_real="$(realpath -m "$intake_root")"

  case "${source_real}/" in
    "${intake_real}/"*) ;;
    *)
      die "library ingest source must be under ${intake_root}: ${SOURCE_DIR}"
      ;;
  esac
}

append_ingest_state() {
  local state_file="$1"
  local published_source="$2"
  local imported_at="$3"
  local asset_library_ref

  asset_library_ref="$(
    resolve_repo_ref \
      "$ASSET_LIBRARY_ROOT" \
      "$ASSET_LIBRARY_REF_OVERRIDE" \
      "soundclaw-asset-library"
  )"

  write_text_file "$state_file.tmp" <<EOF
LIBRARY_INGEST_SOURCE=${SOURCE_DIR@Q}
LIBRARY_INGEST_MODE='copy'
LIBRARY_INGEST_ASSET_LIBRARY_ROOT=${ASSET_LIBRARY_ROOT@Q}
LIBRARY_INGEST_ASSET_LIBRARY_REF=${asset_library_ref@Q}
LIBRARY_INGEST_PUBLISHED_SOURCE=${published_source@Q}
LIBRARY_INGEST_COMPLETED_AT=${imported_at@Q}
LIBRARY_INGEST_RESULT='OK'
EOF
  run_cmd cat "$state_file.tmp" >> "$state_file"
  run_cmd rm -f "$state_file.tmp"
}

main() {
  local work_dir
  local publish_dir
  local import_output
  local completed_at
  local state_file

  while [[ $# -gt 0 ]]; do
    case "$1" in
      --asset-library-root)
        [[ $# -ge 2 ]] || die "--asset-library-root requires a value"
        ASSET_LIBRARY_ROOT="$2"
        shift 2
        ;;
      --source)
        [[ $# -ge 2 ]] || die "--source requires a value"
        SOURCE_DIR="$2"
        shift 2
        ;;
      --intake-root)
        [[ $# -ge 2 ]] || die "--intake-root requires a value"
        INTAKE_ROOT_OVERRIDE="$2"
        shift 2
        ;;
      --source-relative)
        [[ $# -ge 2 ]] || die "--source-relative requires a value"
        SOURCE_RELATIVE="$2"
        shift 2
        ;;
      --release-ref)
        [[ $# -ge 2 ]] || die "--release-ref requires a value"
        RELEASE_REF="$2"
        shift 2
        ;;
      --asset-library-ref)
        [[ $# -ge 2 ]] || die "--asset-library-ref requires a value"
        ASSET_LIBRARY_REF_OVERRIDE="$2"
        shift 2
        ;;
      --help|-h)
        usage
        exit 0
        ;;
      *)
        die "unknown argument: $1"
        ;;
    esac
  done

  validate_inputs
  ensure_asset_library_authoring_access "$ASSET_LIBRARY_ROOT"

  if [[ -z "$RELEASE_REF" ]]; then
    RELEASE_REF="ingest-$(basename "$SOURCE_DIR")"
  fi

  work_dir="$(mktemp -d)"
  TEMP_DIRS=("$work_dir")
  publish_dir="${work_dir}/published-library"
  import_output="${work_dir}/import.out"

  cleanup() {
    rm -rf "${TEMP_DIRS[@]}"
  }
  trap cleanup EXIT

  info "source-preserving import from ${SOURCE_DIR} through ${ASSET_LIBRARY_ROOT}"
  env LC_ALL=C.UTF-8 LANG=C.UTF-8 python3 \
    "$(asset_library_script_path import-assets.py)" \
    --root "$ASSET_LIBRARY_ROOT" \
    --source "$SOURCE_DIR" \
    --copy \
    | tee "$import_output"

  grep -q '^result: OK$' "$import_output" || die "asset-library import failed"
  grep -q '^import_mode: copy$' "$import_output" || die "asset-library import did not report copy mode"
  grep -q '^source_files_removed: 0$' "$import_output" || die \
    "asset-library import did not preserve source files"

  info "publishing runtime-facing library state into ${publish_dir}"
  env LC_ALL=C.UTF-8 LANG=C.UTF-8 python3 \
    "$(asset_library_script_path publish-library.py)" \
    --root "$ASSET_LIBRARY_ROOT" \
    --target "$publish_dir"

  info "validating published library state in ${publish_dir}"
  env LC_ALL=C.UTF-8 LANG=C.UTF-8 python3 \
    "$(asset_library_script_path validate-library.py)" \
    --root "$publish_dir"

  "${SCRIPT_DIR}/deploy-asset-library.sh" \
    --source "$publish_dir" \
    --release-ref "$RELEASE_REF"

  completed_at="$(timestamp_utc)"
  state_file="$(root_path "$(library_deploy_state_path)")"
  append_ingest_state "$state_file" "$publish_dir" "$completed_at"

  printf 'library_ingest_source: %s\n' "$SOURCE_DIR"
  printf 'library_release_ref: %s\n' "$RELEASE_REF"
  printf 'library_target: %s\n' "$SC_LIBRARY_DIR"
  printf 'source_preserving: yes\n'
  printf 'result: OK\n'
}

main "$@"
