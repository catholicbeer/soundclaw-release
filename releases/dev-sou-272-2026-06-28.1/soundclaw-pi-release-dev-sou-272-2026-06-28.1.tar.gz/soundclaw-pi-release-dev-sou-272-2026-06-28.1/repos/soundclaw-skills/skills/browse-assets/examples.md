# Browse Assets Examples

## Example Requests

- "Browse choir or bells assets."
- "What rain beds do we have?"
- "Help me find the right bells loop before I play it."

## Expected Skill Behavior

- Use `soundclawctl library list [--json]` first.
- Use `soundclawctl library show --asset <id> [--json]` when a candidate needs
  deeper inspection.
- Narrow ambiguity without reading library internals directly.
- End with a clear next step or a chosen asset id.
