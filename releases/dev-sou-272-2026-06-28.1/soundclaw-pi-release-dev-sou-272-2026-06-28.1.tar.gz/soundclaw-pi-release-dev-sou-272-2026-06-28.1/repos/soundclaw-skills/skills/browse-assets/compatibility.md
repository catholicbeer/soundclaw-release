# Compatibility

Operator job: Browse and disambiguate SoundClaw assets before an exact asset id is known.

Runtime dependency:

- Status: Pending current runtime release-line declaration for these promoted command shapes.
- Contract reference: `soundclaw/docs/runtime-spec.md`
- Command(s): `soundclawctl library list [--json]`; `soundclawctl library show --asset <id> [--json]`
- Scope note: This skill owns browse-first discovery and disambiguation. Use `show-asset` when the operator already knows the exact asset id.

Minimum compatible runtime release line: Pending definition in `soundclaw-runtime`.

Tested runtime release line: Not yet validated against a promoted runtime release line.

Packaging target: Plain skill

ClawHub publication status: Not published
