# Request Scene

Purpose: map explicit operator and normalized context intent to one bounded
Phase 3 Scene through the promoted runtime-owned CLI contract.

The skill may discover assets and logical outputs, submit one versioned Scene,
inspect or explain the authoritative runtime result, and stop the active
automatic Scene. It does not execute audio, own Scene state, calculate runtime
policy, schedule work, or call the private operator HTTP surface.

## Guardrails

- Clarify unsafe or ambiguous asset, output, timing, validity, context, and
  replacement intent before mutation.
- Use one request UUID per intended mutation and never silently retry a Scene
  apply with a new UUID.
- Treat runtime JSON and stable reason codes as authoritative for accepted,
  replaced, blocked, stale, degraded, partially failed, recovered, replayed,
  expired, and stopped outcomes.
- Defer honestly when the installed runtime lacks promoted `scene` commands.

## Context Inputs

Phase 3a permits only normalized `local_time` and `weather` facts. Every fact
carries `required`, `source`, exact UTC `observed_at` and `expires_at`, `trust`,
`status`, and a contract-shaped value or `null`. Host time has at most 60
seconds of freshness. Weather uses an explicit provider expiry of at most six
hours. Required stale/unavailable context blocks submission; optional weather
uses an explicit degraded fallback and decision factor. Duplicate/conflicting
kinds require resolution or clarification, never silent merging.
