# Compatibility

Requires the pending Phase 3 runtime line exposing promoted `soundclawctl scene
apply/show/explain/stop` commands and schema version `1` from
`soundclaw/docs/scene-contract.md`.

If those commands are unavailable, the skill must defer. It must not fall back
to private HTTP, runtime sockets, one-Layer Familiar commands, or direct audio
execution to approximate a Scene.
