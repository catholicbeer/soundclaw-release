# Compatibility

Operator job: Report installed SoundClaw deployment identity and guide public
GitHub update checks through the pi-kit-owned path.

Runtime and pi-kit dependency:

- Status: Pending current runtime and pi-kit release-line declaration for this
  promoted command shape.
- Contract reference: `soundclaw/docs/system-architecture.md`
- Command(s): `soundclawctl deployment status [--json]`
- Command(s): `soundclaw-pi-kit/scripts/check-release-update.sh [--json]`
- Command(s): `soundclaw-pi-kit/scripts/check-release-update.sh --channel rc [--json]`
- Command(s): `soundclaw-pi-kit/scripts/check-release-update.sh --release-id <release-id> [--json]`
- Command(s): `soundclaw-pi-kit/scripts/update-install.sh --release-id <release-id> --yes [setup options]`

Minimum compatible runtime release line: Pending definition in
`soundclaw-runtime`.

Minimum compatible pi-kit release line: Pending definition in
`soundclaw-pi-kit`.

Tested runtime release line: Not yet validated against a promoted runtime
release line.

Tested pi-kit release line: Not yet validated against a promoted pi-kit release
line.

Packaging target: Plain skill

ClawHub publication status: Not published

## Boundary Notes

This skill depends on the runtime-promoted deployment identity surface for
installed version reporting. It must not parse pi-kit setup state files.

Update checks and update installs remain pi-kit-owned. The skill may call or
guide the operator to the pi-kit commands, but it must not implement release
lookup, bundle download, checksum verification, setup execution, rollback, or
service management itself.

The default update check is the production stable/final channel. Dev, RC, WDR,
or RTW candidate checks must be explicit through the pi-kit RC selector or one
exact release id, and update installation should target the recorded release id
rather than a moving RC selection.

Public backend install and update instructions should use the public release
surface at `https://github.com/<owner>/soundclaw-release/releases`, where each
bundle carries `install.sh` and bundled pi-kit scripts under
`repos/soundclaw-pi-kit/scripts/`. This is sufficient for install kickoff via
the bundled `setup.sh` path; update-check and update-install scripts may still
require a compatible pi-kit checkout when they are not present in a selected
bundle.
