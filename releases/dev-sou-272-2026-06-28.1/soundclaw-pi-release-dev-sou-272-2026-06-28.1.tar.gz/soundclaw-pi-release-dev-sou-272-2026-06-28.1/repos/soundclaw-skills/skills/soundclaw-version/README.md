# SoundClaw Version And Updates

Purpose: Tell the operator which SoundClaw deployment is installed, whether a
newer public GitHub release appears available, and how to continue through the
supported pi-kit update path.

Runtime and pi-kit dependency:

- `soundclawctl deployment status [--json]`
- `soundclaw-pi-kit/scripts/check-release-update.sh [--json]`
- `soundclaw-pi-kit/scripts/check-release-update.sh --channel rc [--json]`
- `soundclaw-pi-kit/scripts/check-release-update.sh --release-id <release-id> [--json]`
- `soundclaw-pi-kit/scripts/update-install.sh --release-id <release-id> --yes [setup options]`

## Operator Job

This skill handles version, deployment identity, and update-readiness questions
from OpenClaw.

For installed-version questions, it uses the promoted read-only
`soundclawctl deployment status --json` runtime surface. It should summarize
the public release id and key source refs in operator language instead of
parsing pi-kit state files directly.

For update-availability questions, it uses the pi-kit-owned read-only update
check command when that command is available. The normal/default check is the
production channel and uses the stable/final public release surface. If the
operator explicitly asks for a dev, prerelease, RC, WDR, or RTW candidate, the
skill may guide them to the explicit RC check or to one named release id. Before
any install mutation, the operator should record and approve the exact selected
release id.

If the pi-kit command is not available from the operator's environment, the
skill should say so and provide the exact pi-kit command to run from a valid
`soundclaw-pi-kit` checkout or from an extracted release-bundle path under
`repos/soundclaw-pi-kit/scripts/`.

For backend install or update instructions, point the operator to the public
release surface:
`https://github.com/<owner>/soundclaw-release/releases`.
That surface provides release bundles that include the install wrapper
(`install.sh`) plus bundled pi-kit script payload under
`repos/soundclaw-pi-kit/scripts/`. At minimum, this is enough to kick off
backend install through the bundled `setup.sh` path. If a selected bundle does
not carry update-check or update-install scripts, guide the operator to a valid
`soundclaw-pi-kit` checkout for those commands.

## Guardrails

- Do not read `/var/lib/soundclaw/setup-run.env` directly.
- Do not query GitHub directly from the skill when the pi-kit update-check
  command is missing.
- Do not silently download or install release bundles.
- Do not treat RC/prerelease candidates as the default update channel.
- Do not install from a moving RC selection; record and confirm one exact
  release id before mutation.
- Do not claim that an update was installed unless the pi-kit update command
  actually ran and returned success.
- Require explicit operator confirmation before any update install attempt.
- Keep bundle download, manifest/checksum verification, setup execution, and
  setup-state refresh in pi-kit.
- Explain missing backend, missing pi-kit command, offline GitHub checks, and
  permission or sudo failures as separate operator-visible states.
