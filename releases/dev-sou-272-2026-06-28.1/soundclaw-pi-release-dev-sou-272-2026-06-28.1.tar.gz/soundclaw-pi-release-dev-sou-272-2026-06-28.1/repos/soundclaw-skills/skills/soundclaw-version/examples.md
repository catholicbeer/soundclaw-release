# SoundClaw Version And Updates Examples

## Example Requests

- "What SoundClaw version is installed?"
- "Which SoundClaw release is this Pi running?"
- "Show me the deployment refs."
- "Is there a newer SoundClaw release on GitHub?"
- "Check whether SoundClaw has an update."
- "Check the latest SoundClaw RC for the update WDR."
- "Check release `dev-sou-141-2026-05-07.1`."
- "Install the latest SoundClaw update."
- "Update SoundClaw to release `2026-04-30.1`."

## Expected Skill Behavior

- Use `soundclawctl deployment status --json` for installed identity.
- Summarize an installed public release by release id and key refs rather than
  raw JSON.
- When the install is local, missing, malformed, or incomplete, say the
  promoted deployment identity is not available and point to the pi-kit-owned
  install or repair path.
- Use the pi-kit read-only update check when available:
  `./scripts/check-release-update.sh --json`.
- Use the explicit RC check only when the operator asks for a dev, prerelease,
  RC, WDR, or RTW candidate:
  `./scripts/check-release-update.sh --channel rc --json`.
- Use an exact release id when the operator names one:
  `./scripts/check-release-update.sh --release-id <release-id> --json`.
- If the update check says `update-available`, report the installed release,
  selected release, release channel when present, and safe pi-kit next step.
- Before WDR or RTW candidate mutation, tell the operator to record the exact
  selected release id and use that id for the pi-kit install command.
- If GitHub is offline or release metadata cannot be read, say the update check
  is unavailable rather than guessing.
- If the pi-kit update-check command is missing, give the exact command to run
  from a valid `soundclaw-pi-kit` checkout instead of scraping GitHub directly.
- Require explicit operator confirmation before running
  `sudo ./scripts/update-install.sh --release-id <release-id> --yes`.
- If sudo or operator permission is missing, explain that the install did not
  run and that pi-kit owns the host mutation.
- Never claim an update completed unless the pi-kit command returned success.
- After a successful pi-kit install or update, tell the operator to return to
  the same OpenClaw workspace and rerun readiness or version checks.
