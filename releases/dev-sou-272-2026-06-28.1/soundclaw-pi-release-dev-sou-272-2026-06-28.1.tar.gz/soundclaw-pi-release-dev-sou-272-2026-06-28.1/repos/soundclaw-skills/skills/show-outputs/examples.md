# Show Outputs Examples

## Example Requests

- "What output layouts are available?"
- "Show me the details for `perimeter-wide-4`."
- "What are the runtime defaults right now?"
- "What is the default output?"

## Expected Skill Behavior

- Use the runtime discovery commands rather than reading config files directly.
- Name available outputs clearly.
- Show defaults only when the runtime has declared them, including whether a default output is set.
- Keep the explanation grounded in runtime-owned terminology.
