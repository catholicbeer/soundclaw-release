# Show Outputs

Purpose: Inspect the runtime's available logical outputs and deployment defaults through the documented `soundclawctl` discovery surface.

Runtime dependency:

- `soundclawctl outputs list [--json]`
- `soundclawctl outputs show --output <id> [--json]`
- `soundclawctl config defaults [--json]`

## Operator Job

This skill helps an operator or another skill understand which output layouts exist for the current deployment and which defaults, if any, the runtime has declared.

It should translate runtime-owned discovery data into clear operator language without exposing raw config-file parsing or runtime-internal details.
For the replayed control-surface wave, this read-only discovery skill also provides the output context that `manage-output` uses before low-risk output and zone admin workflows.

## Guardrails

- Prefer read-only discovery commands instead of parsing runtime config files.
- Treat outputs as named presentation layouts, not assumed geographic zones. One layout may still span many destination channels for a single synchronized playback instance.
- Use `outputs list` and `outputs show` to describe runtime-owned output details such as ordered destination channels and destination-channel counts.
- Use `config defaults` to report runtime-owned defaults such as `default_output`.
- If the runtime exposes additional defaults that affect output selection, describe them as runtime-owned discovery data rather than as skill-layer policy.
- Report when no default output is configured, and describe the runtime-owned output layout instead of inventing one.
- Do not treat this skill as permission to edit runtime config.
- Do not pretend output add, update, or remove flows are available through this skill before the runtime promotes those commands.
