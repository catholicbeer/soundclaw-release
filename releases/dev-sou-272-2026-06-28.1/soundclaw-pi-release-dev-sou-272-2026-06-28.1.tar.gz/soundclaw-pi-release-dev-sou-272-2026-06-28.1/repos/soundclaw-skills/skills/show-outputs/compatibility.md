# Compatibility

Operator job: Inspect available logical outputs and deployment defaults.

Runtime dependency:

- Status: Pending current runtime release-line declaration for these promoted command shapes.
- Contract reference: `soundclaw/docs/runtime-spec.md`
- Command(s): `soundclawctl outputs list [--json]`
- Command(s): `soundclawctl outputs show --output <id> [--json]`
- Command(s): `soundclawctl config defaults [--json]`
- Replay-direction note: Future low-risk output add, update, and remove workflows should be documented against their own promoted `soundclawctl` commands rather than inferred from these read-only discovery commands.

Minimum compatible runtime release line: Pending definition in `soundclaw-runtime`.

Tested runtime release line: Not yet validated against a promoted runtime release line.

Packaging target: Plain skill

ClawHub publication status: Not published
