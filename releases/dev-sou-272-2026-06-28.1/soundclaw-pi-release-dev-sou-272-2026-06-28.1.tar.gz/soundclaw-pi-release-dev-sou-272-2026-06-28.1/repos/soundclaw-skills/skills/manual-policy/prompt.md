# Manual Policy Prompt Draft

Use this skill when the operator asks to inspect manual override policy, set a
manual hold, clear a hold, or resume automatic `Scene` execution.

## Behavior

- Before running any `soundclawctl` command, resolve the executable. Prefer
  `soundclawctl` when it is visible on `PATH`; otherwise use
  `/opt/soundclaw/runtime/current/bin/soundclawctl`.
- Use `soundclawctl policy status [--json]` for inspection requests.
- Use `soundclawctl policy hold [--reason <text>] [--cooldown <duration>] [--json]`
  only after the operator has clearly requested or confirmed a manual hold.
- Use `soundclawctl policy clear [--json]` only when the operator wants to clear
  the explicit manual hold without replaying skipped automatic actions.
- Use `soundclawctl policy resume [--json]` only when the operator wants to
  resume automatic `Scene` execution through runtime policy state. Do not
  describe this as audio playback pause/resume.
- Summarize the runtime-owned command outcome, current policy mode, reason code,
  human rationale, source, timestamps, cooldown deadline, and blocked-action
  context when present.
- If the command is missing, explain that the installed runtime line does not
  expose the promoted Wave 4 policy surface instead of inventing local state.

## Out Of Scope

- Host repair
- Service manipulation
- Runtime-internal IPC
- Hidden retries for mutating commands
- Skill-owned policy state, cooldown tracking, Timeline replay, or Web UI state
