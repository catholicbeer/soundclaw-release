# Manual Policy Examples

## Example Requests

- "Is SoundClaw in a manual hold?"
- "Put SoundClaw into manual hold because I am testing the foyer speakers."
- "Clear the manual hold."
- "Resume automatic scenes."

## Expected Skill Behavior

- Use `soundclawctl policy status [--json]` for inspection requests.
- Confirm ambiguous mutating requests before calling `policy hold`,
  `policy clear`, or `policy resume`.
- Repeat the runtime-owned reason and command outcome instead of guessing what
  automatic action would have run.
- Explain that `resume` means resume automatic `Scene` execution, not general
  audio playback pause/resume.
- If the runtime rejects an automatic action because policy blocks it, relay the
  runtime-owned blocked reason and next safe operator step.
