#!/usr/bin/env bash
set -euo pipefail

timestamp_utc="$(date -u +%Y-%m-%dT%H:%M:%SZ)"
hostname_value="$(hostname)"
cwd_value="$(pwd)"

echo "timestamp_utc=${timestamp_utc}"
echo "hostname=${hostname_value}"
echo "cwd=${cwd_value}"

if command -v git >/dev/null 2>&1 && git rev-parse --show-toplevel >/dev/null 2>&1; then
  echo "git_root=$(git rev-parse --show-toplevel)"
  echo "git_head=$(git rev-parse HEAD)"
  echo "git_branch=$(git branch --show-current 2>/dev/null || true)"
  if [[ -n "$(git status --porcelain --untracked-files=all 2>/dev/null)" ]]; then
    echo "git_dirty=true"
  else
    echo "git_dirty=false"
  fi
else
  echo "git_root="
  echo "git_head="
  echo "git_branch="
  echo "git_dirty=unknown"
fi

fingerprint_file() {
  local target="$1"
  local size mtime hash_value
  size="$(stat -c '%s' "$target")"
  mtime="$(stat -c '%Y' "$target")"
  hash_value="$(sha256sum "$target" | awk '{print $1}')"
  printf 'path=%s\ttype=file\tsize=%s\tmtime_epoch=%s\tsha256=%s\n' \
    "$target" "$size" "$mtime" "$hash_value"
}

fingerprint_dir() {
  local target="$1"
  local manifest_hash file_count dir_mtime
  dir_mtime="$(stat -c '%Y' "$target")"
  file_count="$(find "$target" -type f -printf '.' | wc -c | awk '{print $1}')"
  manifest_hash="$(
    find "$target" -type f -exec sha256sum "{}" + \
      | LC_ALL=C sort \
      | sha256sum \
      | awk '{print $1}'
  )"
  printf 'path=%s\ttype=dir\tfiles=%s\tmtime_epoch=%s\tmanifest_sha256=%s\n' \
    "$target" "$file_count" "$dir_mtime" "$manifest_hash"
}

if [[ "$#" -eq 0 ]]; then
  echo "usage: fingerprint-paths.sh <path> [<path> ...]" >&2
  exit 64
fi

for target in "$@"; do
  if [[ ! -e "$target" ]]; then
    printf 'path=%s\ttype=missing\n' "$target"
    continue
  fi

  if [[ -f "$target" ]]; then
    fingerprint_file "$target"
    continue
  fi

  if [[ -d "$target" ]]; then
    fingerprint_dir "$target"
    continue
  fi

  printf 'path=%s\ttype=other\n' "$target"
done
