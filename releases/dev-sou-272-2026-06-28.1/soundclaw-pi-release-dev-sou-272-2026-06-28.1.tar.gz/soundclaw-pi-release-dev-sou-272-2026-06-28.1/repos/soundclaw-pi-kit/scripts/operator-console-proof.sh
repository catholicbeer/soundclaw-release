#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# shellcheck source=lib/pi-kit.sh
source "${SCRIPT_DIR}/../lib/pi-kit.sh"

OUTPUT_DIR=""
CANDIDATE_LABEL="installed-deployment"
OPERATOR_URL=""
OPERATOR_BIND=""
OUTPUT_ID=""
ASSET_ID=""
VOLUME_PERCENT=""
SKIP_CONTROL=0

usage() {
  cat <<'EOF'
Usage: operator-console-proof.sh [options]

Capture Phase 1a/1b target-Pi evidence for the local operator-console HTTP
surface. The runner records raw HTTP outputs, rendered-control evidence,
deployment identity, configured bind/url, and service logs; runtime owns HTTP
semantics, command behavior, and UI rendering.

Options:
  --output-dir PATH       Evidence directory. Defaults under /var/lib/soundclaw.
  --candidate-label TEXT  Human label for the tested candidate.
  --url URL               Operator-console base URL. Overrides config detection.
  --bind HOST:PORT        Runtime web_bind value. Used when --url is omitted.
  --output ID             Runtime logical output for optional control checks.
  --asset ID              Runtime asset id for optional play control check.
  --volume-percent N      Optional global operator volume percent check.
  --skip-control          Do not send play/stop control requests.
  --dry-run               Print commands that would run.
  --help, -h              Show this help.

The optional play HTTP block runs only when --output and --asset are both
provided and --skip-control is not set. Stop runs when --output is provided.
Volume runs when --volume-percent is provided.
EOF
}

evidence_timestamp() {
  date -u +"%Y%m%dT%H%M%SZ"
}

append_status() {
  local label="$1"
  local status="$2"
  local output_file="$3"

  printf '%s\t%s\t%s\t%s\n' "$(timestamp_utc)" "$label" "$status" "$output_file" \
    >>"${OUTPUT_DIR}/command-status.tsv"
}

capture_command() {
  local label="$1"
  local output_file="$2"
  shift 2
  local command_text
  local status

  command_text="$(quote_cmd "$@")"
  printf '%s\t%s\n' "$label" "$command_text" >>"${OUTPUT_DIR}/commands.tsv"

  if [[ "$DRY_RUN" == "1" ]]; then
    info "[dry-run] ${command_text}"
    printf 'dry-run command: %s\n' "$command_text" >"$output_file"
    append_status "$label" 0 "$output_file"
    return 0
  fi

  set +e
  "$@" >"$output_file" 2>"${output_file}.stderr"
  status=$?
  set -e

  append_status "$label" "$status" "$output_file"
  return "$status"
}

load_setup_state_if_present() {
  local setup_state

  setup_state="$(root_path "$(setup_run_state_path)")"
  [[ -f "$setup_state" ]] || return 0

  # setup-run.env is pi-kit generated shell-safe evidence.
  # shellcheck disable=SC1090
  source "$setup_state"
}

load_deploy_state_if_present() {
  local state_file="$1"

  [[ -f "$state_file" ]] || return 0

  # Deployment state files are pi-kit generated shell-safe evidence.
  # shellcheck disable=SC1090
  source "$state_file"
}

detect_operator_bind_from_config() {
  local runtime_config
  local detected

  runtime_config="$(root_path "$(runtime_config_path)")"
  [[ -f "$runtime_config" ]] || return 1

  detected="$(
    sed -nE 's/^[[:space:]]*web_bind[[:space:]]*=[[:space:]]*"([^"]+)".*$/\1/p' \
      "$runtime_config" | head -n 1
  )"
  [[ -n "$detected" ]] || return 1
  printf '%s\n' "$detected"
}

resolve_operator_bind() {
  local detected

  if [[ -n "$OPERATOR_BIND" ]]; then
    printf '%s\n' "$OPERATOR_BIND"
    return 0
  fi

  if [[ -n "${SC_RUNTIME_OPERATOR_HTTP_BIND:-}" ]]; then
    printf '%s\n' "$SC_RUNTIME_OPERATOR_HTTP_BIND"
    return 0
  fi

  if detected="$(detect_operator_bind_from_config)"; then
    printf '%s\n' "$detected"
    return 0
  fi

  printf '0.0.0.0:8765\n'
}

url_from_bind() {
  local bind="$1"
  local host="${bind%:*}"
  local port="${bind##*:}"

  [[ -n "$port" && "$port" != "$bind" ]] || die "operator console bind must include a port: ${bind}"
  [[ -n "$host" ]] || host="127.0.0.1"

  case "$host" in
    "0.0.0.0"|"::"|"[::]")
      host="127.0.0.1"
      ;;
  esac

  printf 'http://%s:%s\n' "${SC_RUNTIME_OPERATOR_HTTP_HOST:-$host}" "$port"
}

resolve_operator_url() {
  local bind="$1"

  if [[ -n "$OPERATOR_URL" ]]; then
    printf '%s\n' "${OPERATOR_URL%/}"
    return 0
  fi

  if [[ -n "${SC_RUNTIME_OPERATOR_HTTP_URL:-}" ]]; then
    printf '%s\n' "${SC_RUNTIME_OPERATOR_HTTP_URL%/}"
    return 0
  fi

  url_from_bind "$bind"
}

json_escape() {
  local value="$1"
  value="${value//\\/\\\\}"
  value="${value//\"/\\\"}"
  value="${value//$'\n'/\\n}"
  printf '%s' "$value"
}

write_summary() {
  local created_at="$1"
  local bind="$2"
  local url="$3"
  local profile="${INSTALLED_PI_KIT_PROFILE:-${SETUP_PROFILE:-unknown}}"
  local hostname_value
  local setup_public_release_id="${SETUP_PUBLIC_RELEASE_ID:-}"
  local setup_public_source_tuple="${SETUP_PUBLIC_SOURCE_TUPLE:-}"
  local setup_runtime_release_ref="${SETUP_RUNTIME_RELEASE_REF:-}"
  local setup_runtime_config_variant="${SETUP_RUNTIME_CONFIG_VARIANT:-}"
  local setup_pi_kit_ref="${SETUP_PI_KIT_REF:-}"
  local setup_skills_ref="${SETUP_SKILLS_REF:-}"
  local runtime_deploy_release_ref="${RUNTIME_RELEASE_REF:-}"
  local library_deploy_release_ref="${LIBRARY_RELEASE_REF:-}"

  hostname_value="$(hostname)"

  cat >"${OUTPUT_DIR}/summary.env" <<EOF
PHASE1A_OPERATOR_CONSOLE_PROOF_SCHEMA='phase1a-operator-console-proof-v1'
PHASE1A_OPERATOR_CONSOLE_PROOF_CREATED_AT=${created_at@Q}
PHASE1A_OPERATOR_CONSOLE_PROOF_CANDIDATE_LABEL=${CANDIDATE_LABEL@Q}
PHASE1A_OPERATOR_CONSOLE_PROOF_HOSTNAME=${hostname_value@Q}
PHASE1A_OPERATOR_CONSOLE_PROOF_PROFILE=${profile@Q}
PHASE1A_OPERATOR_CONSOLE_PROOF_BIND=${bind@Q}
PHASE1A_OPERATOR_CONSOLE_PROOF_URL=${url@Q}
PHASE1A_OPERATOR_CONSOLE_PROOF_OUTPUT_ID=${OUTPUT_ID@Q}
PHASE1A_OPERATOR_CONSOLE_PROOF_ASSET_ID=${ASSET_ID@Q}
PHASE1A_OPERATOR_CONSOLE_PROOF_BOUNDARY='pi-kit captures deploy, URL, HTTP response, status, and log evidence; runtime owns HTTP semantics and command behavior'
PHASE1B_OPERATOR_CONSOLE_PROOF_SCHEMA='phase1b-operator-console-proof-v1'
PHASE1B_OPERATOR_CONSOLE_PROOF_VOLUME_PERCENT=${VOLUME_PERCENT@Q}
PHASE1B_OPERATOR_CONSOLE_PROOF_RENDERED_ROOT='operator-root-rendered-check.txt'
PHASE1B_OPERATOR_CONSOLE_PROOF_BOUNDARY='pi-kit captures rendered-control, command-envelope, host, and log evidence; runtime owns UI semantics, route behavior, and playback behavior'
SETUP_PUBLIC_RELEASE_ID=${setup_public_release_id@Q}
SETUP_PUBLIC_SOURCE_TUPLE=${setup_public_source_tuple@Q}
SETUP_RUNTIME_RELEASE_REF=${setup_runtime_release_ref@Q}
SETUP_RUNTIME_CONFIG_VARIANT=${setup_runtime_config_variant@Q}
SETUP_PI_KIT_REF=${setup_pi_kit_ref@Q}
SETUP_SKILLS_REF=${setup_skills_ref@Q}
RUNTIME_DEPLOY_RELEASE_REF=${runtime_deploy_release_ref@Q}
LIBRARY_DEPLOY_RELEASE_REF=${library_deploy_release_ref@Q}
EOF
}

capture_host_profile() {
  {
    printf 'timestamp_utc=%s\n' "$(timestamp_utc)"
    printf 'hostname=%s\n' "$(hostname)"
    printf 'kernel=%s\n' "$(uname -a)"
    printf 'user=%s\n' "$(id)"
    printf 'sc_root=%s\n' "$SC_ROOT"
    printf 'runtime_service=%s\n' "$SC_RUNTIME_SERVICE_UNIT_NAME"
    printf 'runtime_config=%s\n' "$(runtime_config_path)"
    printf 'runtime_state_dir=%s\n' "$SC_RUNTIME_STATE_DIR"
    printf 'runtime_log_dir=%s\n' "$SC_RUNTIME_LOG_DIR"
  } >"${OUTPUT_DIR}/host-profile.txt"
}

capture_fingerprints() {
  local fingerprint_script="${SCRIPT_DIR}/fingerprint-paths.sh"

  capture_command \
    "path-fingerprints" \
    "${OUTPUT_DIR}/path-fingerprints.txt" \
    "$fingerprint_script" \
    "$(root_path "$(runtime_current_dir)")" \
    "$(root_path "$(runtime_config_path)")" \
    "$(root_path "$(runtime_deploy_state_path)")" \
    "$(root_path "$(library_deploy_state_path)")" \
    "$(root_path "$(setup_run_state_path)")"
}

capture_rendered_root_check() {
  local root_html="${OUTPUT_DIR}/operator-root.html"
  local output_file="${OUTPUT_DIR}/operator-root-rendered-check.txt"
  local status=0

  if [[ "$DRY_RUN" == "1" ]]; then
    printf 'dry-run rendered-root check not exercised\n' >"$output_file"
    append_status "operator-root-rendered-check" 0 "$output_file"
    return 0
  fi

  {
    printf 'required_rendered_controls:\n'
    for token in \
      'id="play-button"' \
      'id="stop-button"' \
      'id="output-select"' \
      'id="asset-select"' \
      'id="asset-list"' \
      'id="volume-range"' \
      '/api/control/volume'
    do
      if grep -q "$token" "$root_html"; then
        printf 'ok\t%s\n' "$token"
      else
        printf 'missing\t%s\n' "$token"
        status=1
      fi
    done

    if grep -q 'id="snapshot"' "$root_html"; then
      printf 'unexpected_primary_snapshot\tid="snapshot"\n'
      status=1
    else
      printf 'ok\tno primary raw snapshot element\n'
    fi
  } >"$output_file"

  append_status "operator-root-rendered-check" "$status" "$output_file"
  return 0
}

capture_http_surface() {
  local url="$1"
  local control_body
  local stop_body
  local volume_body

  capture_command "operator-root" "${OUTPUT_DIR}/operator-root.html" \
    curl -fsS "${url}/" || true
  capture_rendered_root_check
  capture_command "operator-healthz" "${OUTPUT_DIR}/operator-healthz.json" \
    curl -fsS "${url}/healthz" || true
  capture_command "operator-readyz" "${OUTPUT_DIR}/operator-readyz.json" \
    curl -fsS "${url}/readyz" || true
  capture_command "operator-snapshot" "${OUTPUT_DIR}/operator-snapshot.json" \
    curl -fsS "${url}/api/console/snapshot" || true
  capture_command "operator-events-resync" "${OUTPUT_DIR}/operator-events.sse" \
    curl -fsS --max-time 5 "${url}/api/console/events" || true

  if [[ "$SKIP_CONTROL" == "1" ]]; then
    printf 'operator control checks skipped by operator\n' \
      >"${OUTPUT_DIR}/operator-control-skipped.txt"
    return 0
  fi

  if [[ -z "$OUTPUT_ID" ]]; then
    printf 'operator play/stop checks not exercised; provide --output and --asset\n' \
      >"${OUTPUT_DIR}/operator-control-not-exercised.txt"
  else
    if [[ -n "$ASSET_ID" ]]; then
      control_body="$(
        printf '{"output_id":"%s","asset_id":"%s"}' \
          "$(json_escape "$OUTPUT_ID")" "$(json_escape "$ASSET_ID")"
      )"
      capture_command "operator-play" "${OUTPUT_DIR}/operator-play.json" \
        curl -fsS -X POST -H "Content-Type: application/json" \
          --data "$control_body" "${url}/api/control/play" || true
    else
      printf 'operator play check not exercised; provide --asset\n' \
        >"${OUTPUT_DIR}/operator-play-not-exercised.txt"
    fi

    stop_body="$(
      printf '{"output_id":"%s"}' \
        "$(json_escape "$OUTPUT_ID")"
    )"
    capture_command "operator-stop" "${OUTPUT_DIR}/operator-stop.json" \
      curl -fsS -X POST -H "Content-Type: application/json" \
        --data "$stop_body" "${url}/api/control/stop" || true
  fi

  if [[ -n "$VOLUME_PERCENT" ]]; then
    volume_body="$(
      printf '{"global_volume_percent":%s}' "$VOLUME_PERCENT"
    )"
    capture_command "operator-volume" "${OUTPUT_DIR}/operator-volume.json" \
      curl -fsS -X POST -H "Content-Type: application/json" \
        --data "$volume_body" "${url}/api/control/volume" || true
  else
    printf 'operator volume check not exercised; provide --volume-percent\n' \
      >"${OUTPUT_DIR}/operator-volume-not-exercised.txt"
  fi
}

capture_runtime_logs() {
  if ! is_live_root; then
    printf 'runtime log capture not exercised because SC_ROOT is not the live Pi root\n' \
      >"${OUTPUT_DIR}/runtime-logs-not-exercised.txt"
    return 0
  fi

  if command_exists journalctl; then
    capture_command "runtime-journal-tail" "${OUTPUT_DIR}/runtime-journal-tail.txt" \
      journalctl -u "$SC_RUNTIME_SERVICE_UNIT_NAME" -n 200 --no-pager || true
  else
    printf 'journalctl is unavailable\n' >"${OUTPUT_DIR}/runtime-journal-unavailable.txt"
  fi
}

main() {
  local created_at
  local default_output_dir
  local resolved_bind
  local resolved_url

  while [[ $# -gt 0 ]]; do
    case "$1" in
      --output-dir)
        [[ $# -ge 2 ]] || die "--output-dir requires a value"
        OUTPUT_DIR="$2"
        shift 2
        ;;
      --candidate-label)
        [[ $# -ge 2 ]] || die "--candidate-label requires a value"
        CANDIDATE_LABEL="$2"
        shift 2
        ;;
      --url)
        [[ $# -ge 2 ]] || die "--url requires a value"
        OPERATOR_URL="$2"
        shift 2
        ;;
      --bind)
        [[ $# -ge 2 ]] || die "--bind requires a value"
        OPERATOR_BIND="$2"
        shift 2
        ;;
      --output)
        [[ $# -ge 2 ]] || die "--output requires a value"
        OUTPUT_ID="$2"
        shift 2
        ;;
      --asset)
        [[ $# -ge 2 ]] || die "--asset requires a value"
        ASSET_ID="$2"
        shift 2
        ;;
      --volume-percent)
        [[ $# -ge 2 ]] || die "--volume-percent requires a value"
        VOLUME_PERCENT="$2"
        [[ "$VOLUME_PERCENT" =~ ^[0-9]+$ ]] || die "--volume-percent must be an integer"
        shift 2
        ;;
      --skip-control)
        SKIP_CONTROL=1
        shift
        ;;
      --dry-run)
        DRY_RUN=1
        shift
        ;;
      --help|-h)
        usage
        exit 0
        ;;
      *)
        die "unknown argument: $1"
        ;;
    esac
  done

  created_at="$(timestamp_utc)"
  load_installed_layout || warn "no installed pi-kit layout found; using current environment defaults"
  load_setup_state_if_present
  load_deploy_state_if_present "$(root_path "$(runtime_deploy_state_path)")"
  load_deploy_state_if_present "$(root_path "$(library_deploy_state_path)")"

  default_output_dir="$(root_path "${SC_STATE_DIR%/}/phase1a-operator-console-proof/$(evidence_timestamp)")"
  OUTPUT_DIR="${OUTPUT_DIR:-$default_output_dir}"
  [[ "$OUTPUT_DIR" == /* ]] || die "--output-dir must be an absolute path"

  resolved_bind="$(resolve_operator_bind)"
  resolved_url="$(resolve_operator_url "$resolved_bind")"

  mkdir -p "$OUTPUT_DIR"
  printf 'timestamp_utc\tlabel\tstatus\toutput_file\n' >"${OUTPUT_DIR}/command-status.tsv"
  printf 'label\tcommand\n' >"${OUTPUT_DIR}/commands.tsv"

  write_summary "$created_at" "$resolved_bind" "$resolved_url"
  capture_host_profile

  capture_command \
    "deployment-status" \
    "${OUTPUT_DIR}/deployment-status.json" \
    "${SCRIPT_DIR}/deployment-status.sh" --json || true

  capture_fingerprints || true
  capture_http_surface "$resolved_url"
  capture_runtime_logs

  info "Phase 1a/1b operator-console evidence captured in ${OUTPUT_DIR}"
  info "operator console URL: ${resolved_url}"
}

main "$@"
