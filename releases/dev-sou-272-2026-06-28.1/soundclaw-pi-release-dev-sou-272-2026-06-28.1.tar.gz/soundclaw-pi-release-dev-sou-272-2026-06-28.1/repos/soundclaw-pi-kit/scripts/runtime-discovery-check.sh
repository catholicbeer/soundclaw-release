#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# shellcheck source=../lib/pi-kit.sh
source "${SCRIPT_DIR}/../lib/pi-kit.sh"

declare -a OUTPUT_IDS=()
INCLUDE_POLICY_STATUS=0

usage() {
  cat <<'EOF'
Usage: runtime-discovery-check.sh --output <output-id> [--output <output-id> ...] [--include-policy-status]

Capture the promoted post-deploy runtime discovery surface in a repeatable way.
This helper stays on the public soundclawctl boundary and does not parse
runtime.toml directly.

Use --include-policy-status for Wave 4 candidates that need read-only
runtime-owned manual policy status evidence. Mutating policy checks such as
hold, clear, resume, or blocked automatic-action proof remain explicit
runtime-owned WDR commands outside this helper.
EOF
}

run_check() {
  local label="$1"
  shift

  printf '\n== %s ==\n' "$label"
  printf '+ '
  quote_cmd "$@"
  "$@"
}

resolve_runtime_ctl() {
  printf '%s/bin/soundclawctl\n' "$(root_path "$(runtime_current_dir)")"
}

load_layout_if_present() {
  local config_file

  config_file="$(root_path "$(pi_kit_env_path)")"

  if load_installed_layout; then
    info "loaded installed pi-kit layout from ${config_file}"
    return 0
  fi

  warn "no installed pi-kit config found at ${config_file}; using current environment defaults"
}

run_runtime_checks() {
  local runtime_ctl="$1"
  local output_id

  run_check "Runtime Config Validation" "$runtime_ctl" config validate
  run_check "Runtime Doctor" "$runtime_ctl" runtime doctor
  run_check "Logical Outputs" "$runtime_ctl" outputs list --json
  run_check "Runtime Defaults" "$runtime_ctl" config defaults --json

  if [[ "$INCLUDE_POLICY_STATUS" == "1" ]]; then
    run_check "Manual Policy Status" "$runtime_ctl" policy status --json
  fi

  for output_id in "${OUTPUT_IDS[@]}"; do
    run_check "Logical Output ${output_id}" \
      "$runtime_ctl" outputs show --output "$output_id" --json
  done
}

run_service_checks() {
  command_exists systemctl || die "systemctl is required for runtime service checks"

  run_check "Runtime Service Status" \
    systemctl status "$SC_RUNTIME_SERVICE_UNIT_NAME" --no-pager
  run_check "Runtime State And Log Directories" \
    ls -ld "$(root_path "$SC_RUNTIME_STATE_DIR")" "$(root_path "$SC_RUNTIME_LOG_DIR")"
  run_check "Runtime Access Group" getent group "$SC_RUNTIME_ACCESS_GROUP"
}

main() {
  local runtime_ctl

  while [[ $# -gt 0 ]]; do
    case "$1" in
      --output)
        [[ $# -ge 2 ]] || die "--output requires a value"
        OUTPUT_IDS+=("$2")
        shift 2
        ;;
      --include-policy-status)
        INCLUDE_POLICY_STATUS=1
        shift
        ;;
      --help|-h)
        usage
        exit 0
        ;;
      *)
        die "unknown argument: $1"
        ;;
    esac
  done

  [[ ${#OUTPUT_IDS[@]} -gt 0 ]] || die \
    "provide at least one --output so the discovery capture includes outputs show evidence"

  is_live_root || die "run this helper on the live Pi after deploy; it does not support SC_ROOT"

  load_layout_if_present

  runtime_ctl="$(resolve_runtime_ctl)"
  [[ -x "$runtime_ctl" ]] || die "soundclawctl is not executable at ${runtime_ctl}"

  info "using runtime control CLI at ${runtime_ctl}"

  run_runtime_checks "$runtime_ctl"
  run_service_checks
}

main "$@"
