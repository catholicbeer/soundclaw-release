#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# shellcheck source=lib/pi-kit.sh
source "${SCRIPT_DIR}/../lib/pi-kit.sh"

OUTPUT_DIR=""
CANDIDATE_LABEL="installed-deployment"
OUTPUT_ID=""
ASSET_ID=""
ITERATIONS=5
ALLOW_NO_AUDIO=0
SKIP_SMOKE=0
SKIP_RESTART=0

usage() {
  cat <<'EOF'
Usage: wave5-proof-capture.sh [options]

Capture Phase 1 Wave 5 target-Pi evidence from promoted pi-kit and runtime
surfaces. The runner records raw command output and timing measurements; it
does not parse private runtime state, socket payloads, Timeline storage, or
runtime internals.

Options:
  --output-dir PATH       Evidence directory. Defaults under /var/lib/soundclaw.
  --candidate-label TEXT  Human label for the tested candidate.
  --output ID             Runtime logical output for optional play/stop timing.
  --asset ID              Runtime asset id for optional play/stop timing.
  --iterations N          Timing iterations for optional play/stop checks.
  --allow-no-audio        Pass --allow-no-audio to smoke-test.sh.
  --skip-smoke            Skip smoke-test.sh capture.
  --skip-restart          Skip soundclaw-runtime.service restart proof.
  --dry-run               Print commands that would run.
  --help, -h              Show this help.

The optional play/stop timing block runs only when both --output and --asset are
provided. Restart proof runs only on the live Pi root unless --skip-restart is
provided.
EOF
}

evidence_timestamp() {
  date -u +"%Y%m%dT%H%M%SZ"
}

resolve_runtime_ctl() {
  printf '%s/bin/soundclawctl\n' "$(root_path "$(runtime_current_dir)")"
}

append_status() {
  local label="$1"
  local status="$2"
  local output_file="$3"

  printf '%s\t%s\t%s\t%s\n' "$(timestamp_utc)" "$label" "$status" "$output_file" \
    >>"${OUTPUT_DIR}/command-status.tsv"
}

capture_command() {
  local label="$1"
  local output_file="$2"
  shift 2
  local command_text
  local status

  command_text="$(quote_cmd "$@")"
  printf '%s\t%s\n' "$label" "$command_text" >>"${OUTPUT_DIR}/commands.tsv"

  if [[ "$DRY_RUN" == "1" ]]; then
    info "[dry-run] ${command_text}"
    printf 'dry-run command: %s\n' "$command_text" >"$output_file"
    append_status "$label" 0 "$output_file"
    return 0
  fi

  set +e
  "$@" >"$output_file" 2>"${output_file}.stderr"
  status=$?
  set -e

  append_status "$label" "$status" "$output_file"
  return "$status"
}

capture_timed_command() {
  local label="$1"
  local output_file="$2"
  shift 2
  local start_ms
  local end_ms
  local duration_ms
  local status

  start_ms="$(date +%s%3N)"
  set +e
  capture_command "$label" "$output_file" "$@"
  status=$?
  set -e
  end_ms="$(date +%s%3N)"
  duration_ms=$((end_ms - start_ms))

  printf '%s\t%s\t%s\t%s\n' "$label" "$status" "$duration_ms" "$output_file" \
    >>"${OUTPUT_DIR}/timing-results.tsv"

  return "$status"
}

load_setup_state_if_present() {
  local setup_state

  setup_state="$(root_path "$(setup_run_state_path)")"
  [[ -f "$setup_state" ]] || return 0

  # setup-run.env is pi-kit generated shell-safe evidence.
  # shellcheck disable=SC1090
  source "$setup_state"
}

load_deploy_state_if_present() {
  local state_file="$1"

  [[ -f "$state_file" ]] || return 0

  # Deployment state files are pi-kit generated shell-safe evidence.
  # shellcheck disable=SC1090
  source "$state_file"
}

write_summary() {
  local created_at="$1"
  local runtime_ctl="$2"
  local profile="${INSTALLED_PI_KIT_PROFILE:-${SETUP_PROFILE:-unknown}}"
  local audio_policy="${INSTALLED_PI_KIT_AUDIO_POLICY:-unknown}"
  local hostname_value
  local setup_public_release_id="${SETUP_PUBLIC_RELEASE_ID:-}"
  local setup_public_source_tuple="${SETUP_PUBLIC_SOURCE_TUPLE:-}"
  local setup_runtime_release_ref="${SETUP_RUNTIME_RELEASE_REF:-}"
  local setup_runtime_config_variant="${SETUP_RUNTIME_CONFIG_VARIANT:-}"
  local setup_pi_kit_ref="${SETUP_PI_KIT_REF:-}"
  local setup_skills_ref="${SETUP_SKILLS_REF:-}"
  local setup_library_release_ref="${SETUP_LIBRARY_RELEASE_REF:-}"
  local setup_asset_library_ref="${SETUP_ASSET_LIBRARY_REF:-}"
  local runtime_deploy_release_ref="${RUNTIME_RELEASE_REF:-}"
  local library_deploy_release_ref="${LIBRARY_RELEASE_REF:-}"

  hostname_value="$(hostname)"

  cat >"${OUTPUT_DIR}/summary.env" <<EOF
WAVE5_PROOF_SCHEMA='phase1-wave5-pi-proof-v1'
WAVE5_PROOF_CREATED_AT=${created_at@Q}
WAVE5_PROOF_CANDIDATE_LABEL=${CANDIDATE_LABEL@Q}
WAVE5_PROOF_HOSTNAME=${hostname_value@Q}
WAVE5_PROOF_PROFILE=${profile@Q}
WAVE5_PROOF_AUDIO_POLICY=${audio_policy@Q}
WAVE5_PROOF_RUNTIME_CTL=${runtime_ctl@Q}
WAVE5_PROOF_OUTPUT_ID=${OUTPUT_ID@Q}
WAVE5_PROOF_ASSET_ID=${ASSET_ID@Q}
WAVE5_PROOF_ITERATIONS=${ITERATIONS@Q}
WAVE5_PROOF_SOU208_PRIOR_PACKAGING_PREFLIGHT='completed'
WAVE5_PROOF_BOUNDARY='pi-kit captures deploy, host, command, timing, restart, and evidence files; runtime owns proof semantics'
SETUP_PUBLIC_RELEASE_ID=${setup_public_release_id@Q}
SETUP_PUBLIC_SOURCE_TUPLE=${setup_public_source_tuple@Q}
SETUP_RUNTIME_RELEASE_REF=${setup_runtime_release_ref@Q}
SETUP_RUNTIME_CONFIG_VARIANT=${setup_runtime_config_variant@Q}
SETUP_PI_KIT_REF=${setup_pi_kit_ref@Q}
SETUP_SKILLS_REF=${setup_skills_ref@Q}
SETUP_LIBRARY_RELEASE_REF=${setup_library_release_ref@Q}
SETUP_ASSET_LIBRARY_REF=${setup_asset_library_ref@Q}
RUNTIME_DEPLOY_RELEASE_REF=${runtime_deploy_release_ref@Q}
LIBRARY_DEPLOY_RELEASE_REF=${library_deploy_release_ref@Q}
EOF
}

capture_host_profile() {
  {
    printf 'timestamp_utc=%s\n' "$(timestamp_utc)"
    printf 'hostname=%s\n' "$(hostname)"
    printf 'kernel=%s\n' "$(uname -a)"
    printf 'user=%s\n' "$(id)"
    printf 'sc_root=%s\n' "$SC_ROOT"
    printf 'runtime_service=%s\n' "$SC_RUNTIME_SERVICE_UNIT_NAME"
    printf 'runtime_state_dir=%s\n' "$SC_RUNTIME_STATE_DIR"
    printf 'runtime_log_dir=%s\n' "$SC_RUNTIME_LOG_DIR"
    if command_exists aplay; then
      printf '\n[aplay -l]\n'
      aplay -l || true
    else
      printf '\naplay=missing\n'
    fi
  } >"${OUTPUT_DIR}/host-profile.txt"
}

capture_fingerprints() {
  local fingerprint_script="${SCRIPT_DIR}/fingerprint-paths.sh"

  capture_command \
    "path-fingerprints" \
    "${OUTPUT_DIR}/path-fingerprints.txt" \
    "$fingerprint_script" \
    "$(root_path "$(runtime_current_dir)")" \
    "$(root_path "$(runtime_config_path)")" \
    "$(root_path "$(runtime_deploy_state_path)")" \
    "$(root_path "$(library_deploy_state_path)")" \
    "$(root_path "$(setup_run_state_path)")"
}

capture_optional_playback_timing() {
  local runtime_ctl="$1"
  local index

  if [[ -z "$OUTPUT_ID" || -z "$ASSET_ID" ]]; then
    printf 'optional playback timing not exercised; provide --output and --asset\n' \
      >"${OUTPUT_DIR}/playback-timing-not-exercised.txt"
    return 0
  fi

  for ((index = 1; index <= ITERATIONS; index++)); do
    capture_timed_command \
      "manual-play-${index}" \
      "${OUTPUT_DIR}/manual-play-${index}.json" \
      "$runtime_ctl" playback play --asset "$ASSET_ID" --output "$OUTPUT_ID" --json || true
    capture_timed_command \
      "manual-stop-${index}" \
      "${OUTPUT_DIR}/manual-stop-${index}.json" \
      "$runtime_ctl" playback stop --output "$OUTPUT_ID" --json || true
  done
}

capture_restart_proof() {
  local runtime_ctl="$1"

  if [[ "$SKIP_RESTART" == "1" ]]; then
    printf 'restart proof skipped by operator\n' >"${OUTPUT_DIR}/restart-skipped.txt"
    return 0
  fi

  if ! is_live_root; then
    printf 'restart proof not exercised because SC_ROOT is not the live Pi root\n' \
      >"${OUTPUT_DIR}/restart-not-exercised.txt"
    return 0
  fi

  capture_command \
    "runtime-service-restart" \
    "${OUTPUT_DIR}/runtime-service-restart.txt" \
    systemctl restart "$SC_RUNTIME_SERVICE_UNIT_NAME" || true
  sleep 2
  capture_timed_command \
    "runtime-wave5-proof-after-restart" \
    "${OUTPUT_DIR}/runtime-phase1-wave5-proof-after-restart.json" \
    "$runtime_ctl" runtime phase1-wave5-proof --json || true
}

main() {
  local created_at
  local runtime_ctl
  local default_output_dir
  local smoke_args=()

  while [[ $# -gt 0 ]]; do
    case "$1" in
      --output-dir)
        [[ $# -ge 2 ]] || die "--output-dir requires a value"
        OUTPUT_DIR="$2"
        shift 2
        ;;
      --candidate-label)
        [[ $# -ge 2 ]] || die "--candidate-label requires a value"
        CANDIDATE_LABEL="$2"
        shift 2
        ;;
      --output)
        [[ $# -ge 2 ]] || die "--output requires a value"
        OUTPUT_ID="$2"
        shift 2
        ;;
      --asset)
        [[ $# -ge 2 ]] || die "--asset requires a value"
        ASSET_ID="$2"
        shift 2
        ;;
      --iterations)
        [[ $# -ge 2 ]] || die "--iterations requires a value"
        [[ "$2" =~ ^[1-9][0-9]*$ ]] || die "--iterations must be a positive integer"
        ITERATIONS="$2"
        shift 2
        ;;
      --allow-no-audio)
        ALLOW_NO_AUDIO=1
        shift
        ;;
      --skip-smoke)
        SKIP_SMOKE=1
        shift
        ;;
      --skip-restart)
        SKIP_RESTART=1
        shift
        ;;
      --dry-run)
        DRY_RUN=1
        shift
        ;;
      --help|-h)
        usage
        exit 0
        ;;
      *)
        die "unknown argument: $1"
        ;;
    esac
  done

  created_at="$(timestamp_utc)"
  load_installed_layout || warn "no installed pi-kit layout found; using current environment defaults"
  load_setup_state_if_present
  load_deploy_state_if_present "$(root_path "$(runtime_deploy_state_path)")"
  load_deploy_state_if_present "$(root_path "$(library_deploy_state_path)")"

  default_output_dir="$(root_path "${SC_STATE_DIR%/}/wave5-proof/$(evidence_timestamp)")"
  OUTPUT_DIR="${OUTPUT_DIR:-$default_output_dir}"
  [[ "$OUTPUT_DIR" == /* ]] || die "--output-dir must be an absolute path"

  mkdir -p "$OUTPUT_DIR"
  printf 'timestamp_utc\tlabel\tstatus\toutput_file\n' >"${OUTPUT_DIR}/command-status.tsv"
  printf 'label\tcommand\n' >"${OUTPUT_DIR}/commands.tsv"
  printf 'label\tstatus\tduration_ms\toutput_file\n' >"${OUTPUT_DIR}/timing-results.tsv"

  runtime_ctl="$(resolve_runtime_ctl)"
  [[ -x "$runtime_ctl" || "$DRY_RUN" == "1" ]] || die "soundclawctl is not executable at ${runtime_ctl}"

  write_summary "$created_at" "$runtime_ctl"
  capture_host_profile

  capture_command \
    "deployment-status" \
    "${OUTPUT_DIR}/deployment-status.json" \
    "${SCRIPT_DIR}/deployment-status.sh" --json || true

  if [[ "$SKIP_SMOKE" == "1" ]]; then
    printf 'smoke test skipped by operator\n' >"${OUTPUT_DIR}/smoke-skipped.txt"
  else
    if [[ "$ALLOW_NO_AUDIO" == "1" ]]; then
      smoke_args+=(--allow-no-audio)
    fi
    capture_command \
      "smoke-test" \
      "${OUTPUT_DIR}/smoke-test.txt" \
      "${SCRIPT_DIR}/smoke-test.sh" "${smoke_args[@]}" || true
  fi

  capture_fingerprints || true

  capture_timed_command \
    "runtime-wave5-proof" \
    "${OUTPUT_DIR}/runtime-phase1-wave5-proof.json" \
    "$runtime_ctl" runtime phase1-wave5-proof --json || true

  capture_optional_playback_timing "$runtime_ctl"
  capture_restart_proof "$runtime_ctl"

  info "Wave 5 evidence captured in ${OUTPUT_DIR}"
  info "SOU-208 packaging-preflight evidence is treated as prior completed prerequisite"
}

main "$@"
