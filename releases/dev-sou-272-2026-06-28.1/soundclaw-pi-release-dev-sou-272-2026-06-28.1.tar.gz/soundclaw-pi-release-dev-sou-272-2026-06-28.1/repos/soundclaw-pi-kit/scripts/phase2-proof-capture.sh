#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# shellcheck source=../lib/pi-kit.sh
source "${SCRIPT_DIR}/../lib/pi-kit.sh"

OUTPUT_DIR=""
CANDIDATE_LABEL="installed-deployment"
SCENE_ID=""
LAYER_ID=""
ASSET_ID=""
OUTPUT_ID=""
FADE_IN_MS=""
FADE_OUT_MS=""
POLICY_BLOCK_SCENE=""
INCLUDE_LIBRARY_INGEST=0
ALLOW_NO_AUDIO=0
SKIP_SMOKE=0

usage() {
  cat <<'EOF'
Usage: phase2-proof-capture.sh [options]

Capture Phase 2 one-Layer and source-preserving ingest target-Pi evidence from
promoted pi-kit and runtime surfaces. The runner records raw command output and
bounded failures; it does not parse runtime state, socket payloads, Timeline
storage, asset-library internals, or skill behavior.

Options:
  --output-dir PATH          Evidence directory. Defaults under /var/lib/soundclaw.
  --candidate-label TEXT     Human label for the tested candidate.
  --scene ID                 Scene id for one-Layer run/stop proof.
  --layer ID                 Layer id for one-Layer run/stop proof.
  --asset ID                 Runtime asset id for one-Layer run proof.
  --output ID                Runtime logical output for one-Layer run/stop proof.
  --fade-in-ms N             Optional fade-in milliseconds for run-layer.
  --fade-out-ms N            Optional fade-out milliseconds for stop-layer.
  --policy-block-scene PATH  Optional runtime Scene intent JSON for blocked-action proof.
  --include-library-ingest   Capture soundclawctl library ingest --json.
  --allow-no-audio           Pass --allow-no-audio to smoke-test.sh.
  --skip-smoke               Skip smoke-test.sh capture.
  --dry-run                  Print commands that would run.
  --help, -h                 Show this help.

The run/stop proof runs only when --scene, --layer, --asset, and --output are
provided. The policy block proof runs only when --policy-block-scene is
provided. Runtime-configured library ingest runs only with
--include-library-ingest because it is host-mutating owner behavior.
EOF
}

evidence_timestamp() {
  date -u +"%Y%m%dT%H%M%SZ"
}

resolve_runtime_ctl() {
  printf '%s/bin/soundclawctl\n' "$(root_path "$(runtime_current_dir)")"
}

append_status() {
  local label="$1"
  local status="$2"
  local output_file="$3"

  printf '%s\t%s\t%s\t%s\n' "$(timestamp_utc)" "$label" "$status" "$output_file" \
    >>"${OUTPUT_DIR}/command-status.tsv"
}

capture_command() {
  local label="$1"
  local output_file="$2"
  shift 2
  local command_text
  local status

  command_text="$(quote_cmd "$@")"
  printf '%s\t%s\n' "$label" "$command_text" >>"${OUTPUT_DIR}/commands.tsv"

  if [[ "$DRY_RUN" == "1" ]]; then
    info "[dry-run] ${command_text}"
    printf 'dry-run command: %s\n' "$command_text" >"$output_file"
    append_status "$label" 0 "$output_file"
    return 0
  fi

  set +e
  "$@" >"$output_file" 2>"${output_file}.stderr"
  status=$?
  set -e

  append_status "$label" "$status" "$output_file"
  return "$status"
}

load_setup_state_if_present() {
  local setup_state

  setup_state="$(root_path "$(setup_run_state_path)")"
  [[ -f "$setup_state" ]] || return 0

  # setup-run.env is pi-kit generated shell-safe evidence.
  # shellcheck disable=SC1090
  source "$setup_state"
}

load_deploy_state_if_present() {
  local state_file="$1"

  [[ -f "$state_file" ]] || return 0

  # Deployment state files are pi-kit generated shell-safe evidence.
  # shellcheck disable=SC1090
  source "$state_file"
}

write_summary() {
  local created_at="$1"
  local runtime_ctl="$2"
  local profile="${INSTALLED_PI_KIT_PROFILE:-${SETUP_PROFILE:-unknown}}"
  local audio_policy="${INSTALLED_PI_KIT_AUDIO_POLICY:-unknown}"
  local hostname_value
  local setup_public_release_id="${SETUP_PUBLIC_RELEASE_ID:-}"
  local setup_public_source_tuple="${SETUP_PUBLIC_SOURCE_TUPLE:-}"
  local setup_runtime_release_ref="${SETUP_RUNTIME_RELEASE_REF:-}"
  local setup_runtime_config_variant="${SETUP_RUNTIME_CONFIG_VARIANT:-}"
  local setup_pi_kit_ref="${SETUP_PI_KIT_REF:-}"
  local setup_skills_ref="${SETUP_SKILLS_REF:-}"
  local setup_library_release_ref="${SETUP_LIBRARY_RELEASE_REF:-}"
  local setup_asset_library_ref="${SETUP_ASSET_LIBRARY_REF:-}"
  local runtime_deploy_release_ref="${RUNTIME_RELEASE_REF:-}"
  local library_deploy_release_ref="${LIBRARY_RELEASE_REF:-}"
  local library_ingest_source="${LIBRARY_INGEST_SOURCE:-}"
  local library_ingest_asset_library_ref="${LIBRARY_INGEST_ASSET_LIBRARY_REF:-}"

  hostname_value="$(hostname)"

  cat >"${OUTPUT_DIR}/summary.env" <<EOF
PHASE2_PROOF_SCHEMA='phase2-one-layer-pi-proof-v1'
PHASE2_PROOF_CREATED_AT=${created_at@Q}
PHASE2_PROOF_CANDIDATE_LABEL=${CANDIDATE_LABEL@Q}
PHASE2_PROOF_HOSTNAME=${hostname_value@Q}
PHASE2_PROOF_PROFILE=${profile@Q}
PHASE2_PROOF_AUDIO_POLICY=${audio_policy@Q}
PHASE2_PROOF_RUNTIME_CTL=${runtime_ctl@Q}
PHASE2_PROOF_SCENE_ID=${SCENE_ID@Q}
PHASE2_PROOF_LAYER_ID=${LAYER_ID@Q}
PHASE2_PROOF_ASSET_ID=${ASSET_ID@Q}
PHASE2_PROOF_OUTPUT_ID=${OUTPUT_ID@Q}
PHASE2_PROOF_POLICY_BLOCK_SCENE=${POLICY_BLOCK_SCENE@Q}
PHASE2_PROOF_INCLUDE_LIBRARY_INGEST=${INCLUDE_LIBRARY_INGEST@Q}
PHASE2_PROOF_BOUNDARY='pi-kit captures deploy, host, command, library-ingest, and evidence files; runtime owns Layer/policy/Timeline semantics and asset-library owns import/index semantics'
SETUP_PUBLIC_RELEASE_ID=${setup_public_release_id@Q}
SETUP_PUBLIC_SOURCE_TUPLE=${setup_public_source_tuple@Q}
SETUP_RUNTIME_RELEASE_REF=${setup_runtime_release_ref@Q}
SETUP_RUNTIME_CONFIG_VARIANT=${setup_runtime_config_variant@Q}
SETUP_PI_KIT_REF=${setup_pi_kit_ref@Q}
SETUP_SKILLS_REF=${setup_skills_ref@Q}
SETUP_LIBRARY_RELEASE_REF=${setup_library_release_ref@Q}
SETUP_ASSET_LIBRARY_REF=${setup_asset_library_ref@Q}
RUNTIME_DEPLOY_RELEASE_REF=${runtime_deploy_release_ref@Q}
LIBRARY_DEPLOY_RELEASE_REF=${library_deploy_release_ref@Q}
LIBRARY_INGEST_SOURCE=${library_ingest_source@Q}
LIBRARY_INGEST_ASSET_LIBRARY_REF=${library_ingest_asset_library_ref@Q}
SC_LIBRARY_INTAKE_DIR=${SC_LIBRARY_INTAKE_DIR@Q}
EOF
}

capture_host_profile() {
  {
    printf 'timestamp_utc=%s\n' "$(timestamp_utc)"
    printf 'hostname=%s\n' "$(hostname)"
    printf 'kernel=%s\n' "$(uname -a)"
    printf 'user=%s\n' "$(id)"
    printf 'sc_root=%s\n' "$SC_ROOT"
    printf 'runtime_service=%s\n' "$SC_RUNTIME_SERVICE_UNIT_NAME"
    printf 'runtime_state_dir=%s\n' "$SC_RUNTIME_STATE_DIR"
    printf 'runtime_log_dir=%s\n' "$SC_RUNTIME_LOG_DIR"
    printf 'library_dir=%s\n' "$SC_LIBRARY_DIR"
    printf 'library_intake_dir=%s\n' "$SC_LIBRARY_INTAKE_DIR"
    if command_exists aplay; then
      printf '\n[aplay -l]\n'
      aplay -l || true
    else
      printf '\naplay=missing\n'
    fi
  } >"${OUTPUT_DIR}/host-profile.txt"
}

capture_fingerprints() {
  local fingerprint_script="${SCRIPT_DIR}/fingerprint-paths.sh"

  capture_command \
    "path-fingerprints" \
    "${OUTPUT_DIR}/path-fingerprints.txt" \
    "$fingerprint_script" \
    "$(root_path "$(runtime_current_dir)")" \
    "$(root_path "$(runtime_config_path)")" \
    "$(root_path "$(runtime_deploy_state_path)")" \
    "$(root_path "$(library_deploy_state_path)")" \
    "$(root_path "$(setup_run_state_path)")" \
    "$(root_path "$SC_LIBRARY_DIR")" \
    "$(root_path "$SC_LIBRARY_INTAKE_DIR")"
}

capture_one_layer() {
  local runtime_ctl="$1"
  local -a run_args
  local -a stop_args

  if [[ -z "$SCENE_ID" || -z "$LAYER_ID" || -z "$ASSET_ID" || -z "$OUTPUT_ID" ]]; then
    printf 'one-Layer run/stop proof not exercised; provide --scene, --layer, --asset, and --output\n' \
      >"${OUTPUT_DIR}/one-layer-not-exercised.txt"
    return 0
  fi

  run_args=(
    "$runtime_ctl" familiar run-layer
    --scene "$SCENE_ID"
    --layer "$LAYER_ID"
    --asset "$ASSET_ID"
    --output "$OUTPUT_ID"
  )
  if [[ -n "$FADE_IN_MS" ]]; then
    run_args+=(--fade-in-ms "$FADE_IN_MS")
  fi
  run_args+=(--json)

  capture_command \
    "familiar-run-layer" \
    "${OUTPUT_DIR}/familiar-run-layer.json" \
    "${run_args[@]}" || true

  stop_args=(
    "$runtime_ctl" familiar stop-layer
    --scene "$SCENE_ID"
    --layer "$LAYER_ID"
    --output "$OUTPUT_ID"
  )
  if [[ -n "$FADE_OUT_MS" ]]; then
    stop_args+=(--fade-out-ms "$FADE_OUT_MS")
  fi
  stop_args+=(--json)

  capture_command \
    "familiar-stop-layer" \
    "${OUTPUT_DIR}/familiar-stop-layer.json" \
    "${stop_args[@]}" || true
}

capture_policy_block_proof() {
  local runtime_ctl="$1"

  if [[ -z "$POLICY_BLOCK_SCENE" ]]; then
    printf 'policy block proof not exercised; provide --policy-block-scene\n' \
      >"${OUTPUT_DIR}/policy-block-not-exercised.txt"
    return 0
  fi

  if [[ "$DRY_RUN" != "1" && ! -f "$POLICY_BLOCK_SCENE" ]]; then
    printf 'policy block scene file missing: %s\n' "$POLICY_BLOCK_SCENE" \
      >"${OUTPUT_DIR}/policy-block-not-exercised.txt"
    append_status "familiar-prove-policy-block" 2 "${OUTPUT_DIR}/policy-block-not-exercised.txt"
    return 0
  fi

  capture_command \
    "familiar-prove-policy-block" \
    "${OUTPUT_DIR}/familiar-prove-policy-block.json" \
    "$runtime_ctl" familiar prove-policy-block --scene "$POLICY_BLOCK_SCENE" --json || true
}

capture_library_ingest() {
  local runtime_ctl="$1"

  if [[ "$INCLUDE_LIBRARY_INGEST" != "1" ]]; then
    printf 'library ingest proof not exercised; pass --include-library-ingest after operator approval\n' \
      >"${OUTPUT_DIR}/library-ingest-not-exercised.txt"
    return 0
  fi

  capture_command \
    "library-ingest" \
    "${OUTPUT_DIR}/library-ingest.json" \
    "$runtime_ctl" library ingest --json || true

  capture_command \
    "library-list-after-ingest" \
    "${OUTPUT_DIR}/library-list-after-ingest.json" \
    "$runtime_ctl" library list --json || true
}

capture_runtime_logs() {
  if ! is_live_root; then
    printf 'runtime log capture not exercised because SC_ROOT is not the live Pi root\n' \
      >"${OUTPUT_DIR}/runtime-logs-not-exercised.txt"
    return 0
  fi

  if command_exists journalctl; then
    capture_command "runtime-journal-tail" "${OUTPUT_DIR}/runtime-journal-tail.txt" \
      journalctl -u "$SC_RUNTIME_SERVICE_UNIT_NAME" -n 200 --no-pager || true
  else
    printf 'journalctl is unavailable\n' >"${OUTPUT_DIR}/runtime-journal-unavailable.txt"
  fi
}

main() {
  local created_at
  local runtime_ctl
  local default_output_dir
  local smoke_args=()

  while [[ $# -gt 0 ]]; do
    case "$1" in
      --output-dir)
        [[ $# -ge 2 ]] || die "--output-dir requires a value"
        OUTPUT_DIR="$2"
        shift 2
        ;;
      --candidate-label)
        [[ $# -ge 2 ]] || die "--candidate-label requires a value"
        CANDIDATE_LABEL="$2"
        shift 2
        ;;
      --scene)
        [[ $# -ge 2 ]] || die "--scene requires a value"
        SCENE_ID="$2"
        shift 2
        ;;
      --layer)
        [[ $# -ge 2 ]] || die "--layer requires a value"
        LAYER_ID="$2"
        shift 2
        ;;
      --asset)
        [[ $# -ge 2 ]] || die "--asset requires a value"
        ASSET_ID="$2"
        shift 2
        ;;
      --output)
        [[ $# -ge 2 ]] || die "--output requires a value"
        OUTPUT_ID="$2"
        shift 2
        ;;
      --fade-in-ms)
        [[ $# -ge 2 ]] || die "--fade-in-ms requires a value"
        [[ "$2" =~ ^[0-9]+$ ]] || die "--fade-in-ms must be a non-negative integer"
        FADE_IN_MS="$2"
        shift 2
        ;;
      --fade-out-ms)
        [[ $# -ge 2 ]] || die "--fade-out-ms requires a value"
        [[ "$2" =~ ^[0-9]+$ ]] || die "--fade-out-ms must be a non-negative integer"
        FADE_OUT_MS="$2"
        shift 2
        ;;
      --policy-block-scene)
        [[ $# -ge 2 ]] || die "--policy-block-scene requires a value"
        POLICY_BLOCK_SCENE="$2"
        shift 2
        ;;
      --include-library-ingest)
        INCLUDE_LIBRARY_INGEST=1
        shift
        ;;
      --allow-no-audio)
        ALLOW_NO_AUDIO=1
        shift
        ;;
      --skip-smoke)
        SKIP_SMOKE=1
        shift
        ;;
      --dry-run)
        DRY_RUN=1
        shift
        ;;
      --help|-h)
        usage
        exit 0
        ;;
      *)
        die "unknown argument: $1"
        ;;
    esac
  done

  created_at="$(timestamp_utc)"
  load_installed_layout || warn "no installed pi-kit layout found; using current environment defaults"
  load_setup_state_if_present
  load_deploy_state_if_present "$(root_path "$(runtime_deploy_state_path)")"
  load_deploy_state_if_present "$(root_path "$(library_deploy_state_path)")"

  default_output_dir="$(root_path "${SC_STATE_DIR%/}/phase2-proof/$(evidence_timestamp)")"
  OUTPUT_DIR="${OUTPUT_DIR:-$default_output_dir}"
  [[ "$OUTPUT_DIR" == /* ]] || die "--output-dir must be an absolute path"

  mkdir -p "$OUTPUT_DIR"
  printf 'timestamp_utc\tlabel\tstatus\toutput_file\n' >"${OUTPUT_DIR}/command-status.tsv"
  printf 'label\tcommand\n' >"${OUTPUT_DIR}/commands.tsv"

  runtime_ctl="$(resolve_runtime_ctl)"
  [[ -x "$runtime_ctl" || "$DRY_RUN" == "1" ]] || die "soundclawctl is not executable at ${runtime_ctl}"

  write_summary "$created_at" "$runtime_ctl"
  capture_host_profile

  capture_command \
    "deployment-status" \
    "${OUTPUT_DIR}/deployment-status.json" \
    "${SCRIPT_DIR}/deployment-status.sh" --json || true

  if [[ "$SKIP_SMOKE" == "1" ]]; then
    printf 'smoke test skipped by operator\n' >"${OUTPUT_DIR}/smoke-skipped.txt"
  else
    if [[ "$ALLOW_NO_AUDIO" == "1" ]]; then
      smoke_args+=(--allow-no-audio)
    fi
    capture_command \
      "smoke-test" \
      "${OUTPUT_DIR}/smoke-test.txt" \
      "${SCRIPT_DIR}/smoke-test.sh" "${smoke_args[@]}" || true
  fi

  capture_fingerprints || true

  capture_command \
    "runtime-status" \
    "${OUTPUT_DIR}/runtime-status.json" \
    "$runtime_ctl" runtime status --json || true
  capture_command \
    "runtime-doctor" \
    "${OUTPUT_DIR}/runtime-doctor.json" \
    "$runtime_ctl" runtime doctor --json || true

  capture_one_layer "$runtime_ctl"
  capture_policy_block_proof "$runtime_ctl"
  capture_library_ingest "$runtime_ctl"
  capture_runtime_logs

  info "Phase 2 evidence captured in ${OUTPUT_DIR}"
  info "pi-kit captured raw promoted command output; runtime and asset-library own semantics"
}

main "$@"
