#!/usr/bin/env bash
set -euo pipefail

BUNDLE_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# shellcheck source=repos/soundclaw-pi-kit/lib/pi-kit.sh
source "$BUNDLE_ROOT/repos/soundclaw-pi-kit/lib/pi-kit.sh"

usage() {
  cat <<'USAGE'
Usage: install.sh [--bundle PATH | --bundle-url URL] [setup options]

Wrapper around the bundled soundclaw-pi-kit setup flow.

You must supply either:
  --library-source /path/to/prepared/library
or:
  --asset-library-root /path/to/soundclaw-asset-library --library-import-source /path/to/local-library

Any extra arguments are forwarded to the bundled setup.sh.
USAGE
}

if [[ "${1:-}" == "--help" ]] || [[ "${1:-}" == "-h" ]]; then
  usage
  exit 0
fi

declare -a forward_args=()
while [[ $# -gt 0 ]]; do
  case "$1" in
    --bundle)
      [[ $# -ge 2 ]] || {
        printf 'error: --bundle requires a value\n' >&2
        exit 64
      }
      SOUNDCLAW_PUBLIC_BUNDLE_SOURCE="$2"
      SOUNDCLAW_PUBLIC_BUNDLE_ASSET="$(basename "$2")"
      shift 2
      ;;
    --bundle-url)
      [[ $# -ge 2 ]] || {
        printf 'error: --bundle-url requires a value\n' >&2
        exit 64
      }
      SOUNDCLAW_PUBLIC_BUNDLE_SOURCE="$2"
      SOUNDCLAW_PUBLIC_BUNDLE_ASSET="$(basename "${2%%\?*}")"
      shift 2
      ;;
    *)
      forward_args+=("$1")
      shift
      ;;
  esac
done

if [[ ! -x "$BUNDLE_ROOT/repos/soundclaw-pi-kit/scripts/setup.sh" ]]; then
  chmod +x "$BUNDLE_ROOT/repos/soundclaw-pi-kit/scripts/setup.sh"
fi

source "$BUNDLE_ROOT/manifest.env"

setup_path="$BUNDLE_ROOT/repos/soundclaw-pi-kit/scripts/setup.sh"
manifest_sha256="$(
  sha256sum "$BUNDLE_ROOT/manifest.env" | awk '{print $1}'
)"
checksums_sha256="$(
  sha256sum "$BUNDLE_ROOT/checksums.txt" | awk '{print $1}'
)"
public_source_tuple="runtime=${SOUNDCLAW_RUNTIME_REF} runtime_config=${SOUNDCLAW_RUNTIME_CONFIG_REF} pi_kit=${SOUNDCLAW_PI_KIT_REF} skills=${SOUNDCLAW_SKILLS_REF} library=${SOUNDCLAW_LIBRARY_RELEASE_REF}"

declare -a args=(
  --runtime-source "$BUNDLE_ROOT/runtime"
  --runtime-release-ref "runtime-${SOUNDCLAW_RUNTIME_REF:0:7}"
  --runtime-config "$BUNDLE_ROOT/config/runtime.toml"
  --runtime-config-ref "$SOUNDCLAW_RUNTIME_CONFIG_REF"
  --library-release-ref "$SOUNDCLAW_LIBRARY_RELEASE_REF"
  --skills-source "$BUNDLE_ROOT/repos/soundclaw-skills"
  --skills-ref "$SOUNDCLAW_SKILLS_REF"
  --pi-kit-ref "$SOUNDCLAW_PI_KIT_REF"
)

if "$setup_path" --help | grep -q -- "--public-release-id"; then
  args+=(
    --public-release-id "$SOUNDCLAW_RELEASE_ID"
    --public-bundle-source "${SOUNDCLAW_PUBLIC_BUNDLE_SOURCE:-$BUNDLE_ROOT}"
    --public-bundle-asset "${SOUNDCLAW_PUBLIC_BUNDLE_ASSET:-$(basename "$BUNDLE_ROOT")}"
    --public-manifest-sha256 "$manifest_sha256"
    --public-checksums-sha256 "$checksums_sha256"
    --public-source-tuple "$public_source_tuple"
  )
fi

if [[ -n "${SOUNDCLAW_DEFAULT_SKILLS:-}" ]]; then
  for skill_name in $SOUNDCLAW_DEFAULT_SKILLS; do
    args+=(--skill "$skill_name")
  done
fi

exec "$setup_path" "${args[@]}" "${forward_args[@]}"
