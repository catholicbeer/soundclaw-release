#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# shellcheck source=../lib/pi-kit.sh
source "${SCRIPT_DIR}/../lib/pi-kit.sh"

PROFILE="$DEFAULT_PROFILE"
SKIP_PACKAGES=0
ALLOW_NO_AUDIO=0

usage() {
  cat <<'EOF'
Usage: repair.sh [--profile shared|exclusive] [--skip-packages] [--allow-no-audio] [--dry-run]

Repair a host by rerunning bootstrap and then validating the result with the
same smoke test used after first install.
EOF
}

main() {
  local bootstrap_args=()
  local smoke_args=()

  while [[ $# -gt 0 ]]; do
    case "$1" in
      --profile)
        [[ $# -ge 2 ]] || die "--profile requires a value"
        PROFILE="$2"
        shift 2
        ;;
      --skip-packages)
        SKIP_PACKAGES=1
        shift
        ;;
      --allow-no-audio)
        ALLOW_NO_AUDIO=1
        shift
        ;;
      --dry-run)
        DRY_RUN=1
        shift
        ;;
      --help|-h)
        usage
        exit 0
        ;;
      *)
        die "unknown argument: $1"
        ;;
    esac
  done

  bootstrap_args=(--profile "$PROFILE")

  if [[ "$SKIP_PACKAGES" == "1" ]]; then
    bootstrap_args+=(--skip-packages)
  fi

  if [[ "$DRY_RUN" == "1" ]]; then
    bootstrap_args+=(--dry-run)
  fi

  if [[ "$ALLOW_NO_AUDIO" == "1" ]]; then
    smoke_args+=(--allow-no-audio)
  fi

  info "rerunning bootstrap"
  "${SCRIPT_DIR}/bootstrap.sh" "${bootstrap_args[@]}"

  if [[ "$DRY_RUN" == "1" ]]; then
    info "dry-run repair complete; smoke test skipped"
    exit 0
  fi

  info "running smoke test"
  "${SCRIPT_DIR}/smoke-test.sh" "${smoke_args[@]}"
}

main "$@"
