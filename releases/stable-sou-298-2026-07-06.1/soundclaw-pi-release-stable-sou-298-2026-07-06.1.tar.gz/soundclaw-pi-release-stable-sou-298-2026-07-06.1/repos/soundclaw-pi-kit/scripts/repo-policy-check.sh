#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "${SCRIPT_DIR}/.." && pwd)"

usage() {
  cat <<'EOF'
Usage: repo-policy-check.sh

Verify that the soundclaw-pi-kit wrapper docs and CI keep the shared
Git/Linear closeout rule visible:
- child issues do not move to Done from disposable topic branches
- stacked child work records one umbrella-owned integration branch
- this repo's CI still cannot prove Linear state or durable landed refs, so that
  closeout gate remains manual
EOF
}

require_literal() {
  local file="$1"
  local literal="$2"

  if ! grep -Fq "$literal" "$file"; then
    printf 'missing required text in %s:\n%s\n' "$file" "$literal" >&2
    exit 1
  fi
}

main() {
  case "${1-}" in
    --help|-h)
      usage
      exit 0
      ;;
    "")
      ;;
    *)
      usage >&2
      exit 64
      ;;
  esac

  cd "$REPO_ROOT"

  require_literal "AGENTS.md" \
    "Do not move a child issue to \`Done\` while its repo work exists only on a"
  require_literal "AGENTS.md" \
    "repo state on one explicitly named umbrella-owned integration branch first,"
  require_literal "AGENTS.md" \
    "reached \`main\` or an explicitly named umbrella-owned integration branch, or"

  require_literal "docs/git-usage.md" \
    "Do not move a child issue to \`Done\` while its repo work exists only on a"
  require_literal "docs/git-usage.md" \
    "If stacked child work needs to close before landing on \`main\`, carry that"
  require_literal "docs/git-usage.md" \
    "CI in this repo can verify that this wrapper keeps the shared rule visible,"

  require_literal ".github/workflows/shell-smoke.yml" \
    "./scripts/repo-policy-check.sh"

  printf 'repo policy check: OK\n'
  printf '%s\n' \
    'manual closeout gate remains: CI cannot prove Linear state or that the durable landed ref was recorded in the parent umbrella'
}

main "$@"
