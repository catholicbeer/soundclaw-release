#!/usr/bin/env bash
set -euo pipefail

REMOTE="origin"
DO_FETCH=1

usage() {
  cat <<'EOF'
Usage: git-provenance-check.sh [--remote <name>] [--no-fetch]

Emit machine-readable key=value provenance facts for the current Git checkout.
Runs `git fetch --prune <remote>` by default before comparing refs.
EOF
}

print_kv() {
  local key="$1"
  local value="${2-}"
  printf '%s=%s\n' "$key" "$value"
}

fail() {
  print_kv "error" "$1"
  exit 1
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --remote)
      [[ $# -ge 2 ]] || {
        usage >&2
        exit 64
      }
      REMOTE="$2"
      shift 2
      ;;
    --no-fetch)
      DO_FETCH=0
      shift
      ;;
    --help|-h)
      usage
      exit 0
      ;;
    *)
      usage >&2
      exit 64
      ;;
  esac
done

CHECKED_AT_UTC="$(date -u +%Y-%m-%dT%H:%M:%SZ)"

print_kv "checked_at_utc" "$CHECKED_AT_UTC"
print_kv "remote" "$REMOTE"
print_kv "fetch_performed" "$([[ "$DO_FETCH" -eq 1 ]] && echo true || echo false)"

if ! GIT_ROOT="$(git rev-parse --show-toplevel 2>/dev/null)"; then
  print_kv "git_root" ""
  print_kv "git_head" ""
  print_kv "git_branch" ""
  print_kv "git_upstream" ""
  print_kv "git_upstream_head" ""
  print_kv "git_clean" "false"
  print_kv "ahead_count" ""
  print_kv "behind_count" ""
  print_kv "has_unpushed_commits" "unknown"
  print_kv "has_uncommitted_changes" "unknown"
  print_kv "has_upstream" "false"
  fail "not a git repository"
fi

cd "$GIT_ROOT"

if ! git remote get-url "$REMOTE" >/dev/null 2>&1; then
  print_kv "git_root" "$GIT_ROOT"
  print_kv "git_head" "$(git rev-parse HEAD)"
  print_kv "git_branch" "$(git branch --show-current 2>/dev/null || true)"
  print_kv "git_upstream" ""
  print_kv "git_upstream_head" ""
  print_kv "git_clean" "false"
  print_kv "ahead_count" ""
  print_kv "behind_count" ""
  print_kv "has_unpushed_commits" "unknown"
  print_kv "has_uncommitted_changes" "unknown"
  print_kv "has_upstream" "false"
  fail "remote '$REMOTE' does not exist"
fi

if [[ "$DO_FETCH" -eq 1 ]]; then
  if ! FETCH_OUTPUT="$(git fetch --prune --quiet "$REMOTE" 2>&1)"; then
    print_kv "git_root" "$GIT_ROOT"
    print_kv "git_head" "$(git rev-parse HEAD)"
    print_kv "git_branch" "$(git branch --show-current 2>/dev/null || true)"
    print_kv "git_upstream" ""
    print_kv "git_upstream_head" ""
    print_kv "git_clean" "false"
    print_kv "ahead_count" ""
    print_kv "behind_count" ""
    print_kv "has_unpushed_commits" "unknown"
    print_kv "has_uncommitted_changes" "unknown"
    print_kv "has_upstream" "false"
    fail "git fetch failed for remote '$REMOTE': ${FETCH_OUTPUT//$'\n'/ ; }"
  fi
fi

GIT_HEAD="$(git rev-parse HEAD)"
GIT_BRANCH="$(git branch --show-current 2>/dev/null || true)"
GIT_UPSTREAM="$(git rev-parse --abbrev-ref --symbolic-full-name '@{upstream}' 2>/dev/null || true)"
STATUS_OUTPUT="$(git status --porcelain --untracked-files=all 2>/dev/null || true)"

if [[ -n "$STATUS_OUTPUT" ]]; then
  GIT_CLEAN="false"
  HAS_UNCOMMITTED_CHANGES="true"
else
  GIT_CLEAN="true"
  HAS_UNCOMMITTED_CHANGES="false"
fi

GIT_UPSTREAM_HEAD=""
HAS_UPSTREAM="false"
AHEAD_COUNT=""
BEHIND_COUNT=""
HAS_UNPUSHED_COMMITS="unknown"

if [[ -n "$GIT_UPSTREAM" ]]; then
  HAS_UPSTREAM="true"
  GIT_UPSTREAM_HEAD="$(git rev-parse "$GIT_UPSTREAM")"
  read -r BEHIND_COUNT AHEAD_COUNT < <(git rev-list --left-right --count "${GIT_UPSTREAM}...HEAD")
  if [[ "$AHEAD_COUNT" != "0" ]]; then
    HAS_UNPUSHED_COMMITS="true"
  else
    HAS_UNPUSHED_COMMITS="false"
  fi
fi

print_kv "git_root" "$GIT_ROOT"
print_kv "git_head" "$GIT_HEAD"
print_kv "git_branch" "$GIT_BRANCH"
print_kv "git_upstream" "$GIT_UPSTREAM"
print_kv "git_upstream_head" "$GIT_UPSTREAM_HEAD"
print_kv "git_clean" "$GIT_CLEAN"
print_kv "ahead_count" "$AHEAD_COUNT"
print_kv "behind_count" "$BEHIND_COUNT"
print_kv "has_unpushed_commits" "$HAS_UNPUSHED_COMMITS"
print_kv "has_uncommitted_changes" "$HAS_UNCOMMITTED_CHANGES"
print_kv "has_upstream" "$HAS_UPSTREAM"
