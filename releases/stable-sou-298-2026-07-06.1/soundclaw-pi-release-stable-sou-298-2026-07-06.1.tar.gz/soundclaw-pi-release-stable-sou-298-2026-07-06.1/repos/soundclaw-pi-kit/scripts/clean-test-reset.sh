#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

usage() {
  cat <<'EOF'
Usage: clean-test-reset.sh [--purge-packages] [--dry-run]

Remove pi-kit-managed SoundClaw host state before a clean-install rehearsal.
By default this preserves Raspberry Pi OS, OpenClaw workspaces, ClawHub state,
unrelated user files, and generic host tools. Package removal stays explicit:
pass --purge-packages only when the operator also wants to remove SoundClaw
audio/backend packages.
EOF
}

for arg in "$@"; do
  case "$arg" in
    --help|-h)
      usage
      exit 0
      ;;
  esac
done

printf 'info: clean test reset uses the pi-kit uninstall path and preserves OpenClaw by default\n'
exec "${SCRIPT_DIR}/uninstall.sh" "$@"
