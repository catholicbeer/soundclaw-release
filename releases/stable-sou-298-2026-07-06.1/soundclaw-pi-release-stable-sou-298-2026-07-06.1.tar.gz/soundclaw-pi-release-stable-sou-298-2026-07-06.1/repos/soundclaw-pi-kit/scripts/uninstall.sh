#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# shellcheck source=../lib/pi-kit.sh
source "${SCRIPT_DIR}/../lib/pi-kit.sh"

PURGE_PACKAGES=0

usage() {
  cat <<'EOF'
Usage: uninstall.sh [--purge-packages] [--dry-run]

Remove the current pi-kit-owned SoundClaw host contract from the machine:
disable the runtime service, remove the pi-kit-managed files and directories,
and delete the runtime service user and access group. By default this keeps the
generic host tools already installed by install.sh. Use --purge-packages to
also remove the audio and GStreamer packages added for SoundClaw.

For repeated clean-install rehearsals, prefer scripts/clean-test-reset.sh. It
uses this uninstall path while making the OpenClaw-preserving test-reset intent
explicit for operators.
EOF
}

load_recorded_install_if_present() {
  if load_installed_layout; then
    info "loaded installed pi-kit layout from $(root_path "$(pi_kit_env_path)")"
    return 0
  fi

  warn "no installed pi-kit config found at $(root_path "$(pi_kit_env_path)"); using the current environment defaults for uninstall"
}

disable_runtime_service() {
  local unit_file

  unit_file="$(root_path "$(runtime_service_unit_path)")"

  if [[ ! -f "$unit_file" ]]; then
    info "runtime systemd unit already absent: ${unit_file}"
    return 0
  fi

  if ! is_live_root; then
    info "skipping live systemctl disable for SC_ROOT=${SC_ROOT}"
    return 0
  fi

  if ! systemd_ready; then
    warn "systemd is not active; removing the runtime unit file without systemctl disable"
    return 0
  fi

  info "stopping and disabling ${SC_RUNTIME_SERVICE_UNIT_NAME}"
  run_cmd systemctl disable --now "$SC_RUNTIME_SERVICE_UNIT_NAME"
}

remove_runtime_unit() {
  local unit_file

  unit_file="$(runtime_service_unit_path)"
  remove_managed_path "$unit_file"

  if ! is_live_root; then
    return 0
  fi

  if ! systemd_ready; then
    return 0
  fi

  run_cmd systemctl daemon-reload
  run_cmd systemctl reset-failed
}

remove_managed_filesystem() {
  remove_managed_path "$SC_CONFIG_DIR"
  remove_managed_path "$SC_STATE_DIR"
  remove_managed_path "$SC_LOG_DIR"
  remove_managed_path "$SC_BASE_DIR"
}

remove_runtime_principals() {
  if ! is_live_root; then
    info "skipping live user/group removal for SC_ROOT=${SC_ROOT}"
    return 0
  fi

  if user_exists "$SC_RUNTIME_SERVICE_USER"; then
    info "removing runtime service user ${SC_RUNTIME_SERVICE_USER}"
    run_cmd userdel "$SC_RUNTIME_SERVICE_USER"
  else
    info "runtime service user already absent: ${SC_RUNTIME_SERVICE_USER}"
  fi

  if group_exists "$SC_RUNTIME_SERVICE_USER"; then
    info "removing runtime primary group ${SC_RUNTIME_SERVICE_USER}"
    run_cmd groupdel "$SC_RUNTIME_SERVICE_USER"
  else
    info "runtime primary group already absent: ${SC_RUNTIME_SERVICE_USER}"
  fi

  if group_exists "$SC_RUNTIME_ACCESS_GROUP"; then
    info "removing runtime access group ${SC_RUNTIME_ACCESS_GROUP}"
    run_cmd groupdel "$SC_RUNTIME_ACCESS_GROUP"
  else
    info "runtime access group already absent: ${SC_RUNTIME_ACCESS_GROUP}"
  fi
}

purge_runtime_packages_if_requested() {
  if [[ "$PURGE_PACKAGES" != "1" ]]; then
    info "keeping installed packages; rerun uninstall.sh with --purge-packages to remove ${PURGEABLE_PACKAGES[*]}"
    return 0
  fi

  if ! is_live_root; then
    info "skipping apt package purge for SC_ROOT=${SC_ROOT}"
    return 0
  fi

  info "purging SoundClaw audio/backend packages: ${PURGEABLE_PACKAGES[*]}"
  run_cmd apt-get purge -y "${PURGEABLE_PACKAGES[@]}"
  run_cmd apt-get autoremove -y
}

main() {
  while [[ $# -gt 0 ]]; do
    case "$1" in
      --purge-packages)
        PURGE_PACKAGES=1
        shift
        ;;
      --dry-run)
        DRY_RUN=1
        shift
        ;;
      --help|-h)
        usage
        exit 0
        ;;
      *)
        die "unknown argument: $1"
        ;;
    esac
  done

  load_recorded_install_if_present
  require_root

  disable_runtime_service
  remove_runtime_unit
  remove_managed_filesystem
  remove_runtime_principals
  purge_runtime_packages_if_requested

  info "uninstall complete"
}

main "$@"
