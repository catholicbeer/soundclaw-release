#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# shellcheck source=../lib/pi-kit.sh
source "${SCRIPT_DIR}/../lib/pi-kit.sh"

GITHUB_REPO="catholicbeer/soundclaw-release"
BUNDLE_PATH=""
BUNDLE_URL=""
PUBLIC_BUNDLE_URL=""
RELEASE_ID=""
APPROVED=0
FORCE=0
UPDATE_DRY_RUN=0
declare -a FORWARD_ARGS=()

usage() {
  cat <<'EOF'
Usage: update-install.sh (--release-id ID | --bundle-url URL | --bundle PATH --public-bundle-url URL) --yes [setup options]

Install a selected public SoundClaw release update through install-release.sh.
This wrapper keeps update mutation explicit while preserving install-release.sh
manifest and checksum verification.

Options:
  --release-id ID     Build the canonical GitHub release bundle URL for ID
  --bundle-url URL    Install the selected public release bundle URL
  --bundle PATH       Install an already-downloaded copy of the public asset
  --public-bundle-url URL  Exact canonical public asset URL required with --bundle
  --yes               Confirm operator approval for host mutation
  --force             Allow reinstalling a release id already recorded locally
  --dry-run           Print the install-release.sh handoff without mutating

All other arguments are forwarded to install-release.sh/setup.sh.
EOF
}

load_setup_state() {
  local state_file="$1"

  [[ -f "$state_file" ]] || return 1

  # shellcheck disable=SC1090
  source "$state_file"
}

release_id_from_bundle_url() {
  local url="$1"
  local release_id=""

  if [[ "$url" =~ /release-bundle-([^/]+)/ ]]; then
    release_id="${BASH_REMATCH[1]}"
  elif [[ "$url" =~ soundclaw-pi-release-([^/]+)\.tar\.gz ]]; then
    release_id="${BASH_REMATCH[1]}"
  fi

  printf '%s\n' "$release_id"
}

print_handoff() {
  if [[ -n "$BUNDLE_PATH" ]]; then
    quote_cmd "${SCRIPT_DIR}/install-release.sh" --bundle "$BUNDLE_PATH" --public-bundle-url "$PUBLIC_BUNDLE_URL" "${FORWARD_ARGS[@]}"
  else
    quote_cmd "${SCRIPT_DIR}/install-release.sh" --bundle-url "$BUNDLE_URL" "${FORWARD_ARGS[@]}"
  fi
}

main() {
  local selector_count=0
  local installed_release_id=""
  local selected_release_id=""

  while [[ $# -gt 0 ]]; do
    case "$1" in
      --release-id)
        [[ $# -ge 2 ]] || die "--release-id requires a value"
        RELEASE_ID="$2"
        shift 2
        ;;
      --bundle-url)
        [[ $# -ge 2 ]] || die "--bundle-url requires a value"
        BUNDLE_URL="$2"
        shift 2
        ;;
      --bundle)
        [[ $# -ge 2 ]] || die "--bundle requires a value"
        BUNDLE_PATH="$2"
        shift 2
        ;;
      --public-bundle-url)
        [[ $# -ge 2 ]] || die "--public-bundle-url requires a value"
        PUBLIC_BUNDLE_URL="$2"
        shift 2
        ;;
      --repo)
        die "--repo is no longer accepted; production updates use catholicbeer/soundclaw-release only"
        ;;
      --yes|--approve)
        APPROVED=1
        shift
        ;;
      --force)
        FORCE=1
        shift
        ;;
      --dry-run)
        UPDATE_DRY_RUN=1
        shift
        ;;
      --help|-h)
        usage
        exit 0
        ;;
      *)
        FORWARD_ARGS+=("$1")
        shift
        ;;
    esac
  done

  [[ -n "$RELEASE_ID" ]] && selector_count=$((selector_count + 1))
  [[ -n "$BUNDLE_URL" ]] && selector_count=$((selector_count + 1))
  [[ -n "$BUNDLE_PATH" ]] && selector_count=$((selector_count + 1))
  [[ "$selector_count" -eq 1 ]] || die "choose exactly one of --release-id, --bundle-url, or --bundle"

  if [[ "$UPDATE_DRY_RUN" == "0" && "$APPROVED" != "1" ]]; then
    die "update installation mutates the host; rerun with --yes after confirming the selected release"
  fi

  if [[ -n "$RELEASE_ID" ]]; then
    BUNDLE_URL="https://github.com/${GITHUB_REPO}/releases/download/release-bundle-${RELEASE_ID}/soundclaw-pi-release-${RELEASE_ID}.tar.gz"
    selected_release_id="$RELEASE_ID"
  elif [[ -n "$BUNDLE_URL" ]]; then
    selected_release_id="$(release_id_from_bundle_url "$BUNDLE_URL")"
  elif [[ -n "$BUNDLE_PATH" ]]; then
    [[ -n "$PUBLIC_BUNDLE_URL" ]] || die "--public-bundle-url is required with --bundle"
    selected_release_id="$(release_id_from_bundle_url "$PUBLIC_BUNDLE_URL")"
  fi

  if load_setup_state "$(root_path "$(setup_run_state_path)")"; then
    installed_release_id="${SETUP_PUBLIC_RELEASE_ID:-}"
  fi

  if [[ -n "$selected_release_id" && "$selected_release_id" == "$installed_release_id" && "$FORCE" != "1" ]]; then
    die "refusing to reinstall already-installed release ${selected_release_id}; pass --force to override"
  fi

  if [[ "$UPDATE_DRY_RUN" == "1" ]]; then
    info "dry run: install-release.sh handoff would be:"
    print_handoff
    return 0
  fi

  if [[ -n "$BUNDLE_PATH" ]]; then
    "${SCRIPT_DIR}/install-release.sh" --bundle "$BUNDLE_PATH" --public-bundle-url "$PUBLIC_BUNDLE_URL" "${FORWARD_ARGS[@]}"
  else
    "${SCRIPT_DIR}/install-release.sh" --bundle-url "$BUNDLE_URL" "${FORWARD_ARGS[@]}"
  fi
}

main "$@"
