#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# shellcheck source=../lib/pi-kit.sh
source "${SCRIPT_DIR}/../lib/pi-kit.sh"

PROFILE="$DEFAULT_PROFILE"
SKIP_PACKAGES=0

usage() {
  cat <<'EOF'
Usage: bootstrap.sh [--profile shared|exclusive] [--skip-packages] [--dry-run]

Bootstrap a SoundClaw-ready host by installing the required host packages,
creating the host directory contract, installing the runtime service wiring,
and writing pi-kit state/config files.
EOF
}

install_packages() {
  if [[ "$SKIP_PACKAGES" == "1" ]]; then
    info "skipping package installation"
    return 0
  fi

  if ! is_live_root; then
    warn "SC_ROOT is set to a test root; skipping apt package installation"
    return 0
  fi

  info "installing host packages: ${HOST_PACKAGES[*]}"
  run_cmd apt-get update
  run_cmd apt-get install -y "${HOST_PACKAGES[@]}"
}

install_runtime_service_principals() {
  if ! is_live_root; then
    info "skipping live runtime user/group provisioning for SC_ROOT=${SC_ROOT}"
    return 0
  fi

  ensure_system_group "$SC_RUNTIME_ACCESS_GROUP"
  ensure_system_group "$SC_RUNTIME_SERVICE_USER"
  ensure_system_user "$SC_RUNTIME_SERVICE_USER" "$SC_RUNTIME_SERVICE_USER"

  if group_exists audio; then
    ensure_user_in_group "$SC_RUNTIME_SERVICE_USER" audio
  else
    warn "audio group is missing; verify the runtime service user can access the ALSA device on this host"
  fi

  if [[ -z "${SC_OPERATOR_USER}" ]]; then
    warn "no operator user was detected; rerun with SC_OPERATOR_USER=<user> if you want pi-kit to grant non-root soundclawctl access"
    return 0
  fi

  if [[ "${SC_OPERATOR_USER}" == "root" ]]; then
    info "skipping soundclaw group assignment for root"
    return 0
  fi

  user_exists "$SC_OPERATOR_USER" || die \
    "operator user does not exist: ${SC_OPERATOR_USER}"
  ensure_user_in_group "$SC_OPERATOR_USER" "$SC_RUNTIME_ACCESS_GROUP"
}

ensure_host_layout() {
  ensure_dir "$SC_BASE_DIR"
  ensure_dir "$SC_RUNTIME_DIR"
  ensure_dir "$SC_RELEASES_DIR"
  ensure_library_dir_access
  ensure_dir "$SC_LIBRARY_INTAKE_DIR"
  ensure_dir "$SC_LOG_DIR"

  if is_live_root; then
    ensure_runtime_config_dir_access
    ensure_owned_dir "$SC_RUNTIME_STATE_DIR" \
      "$SC_RUNTIME_SERVICE_USER" "$SC_RUNTIME_ACCESS_GROUP" 2770
    ensure_owned_dir "$SC_RUNTIME_LOG_DIR" \
      "$SC_RUNTIME_SERVICE_USER" "$SC_RUNTIME_ACCESS_GROUP" 2770
    return 0
  fi

  ensure_runtime_config_dir_access
  ensure_dir_mode "$SC_RUNTIME_STATE_DIR" 2770
  ensure_dir_mode "$SC_RUNTIME_LOG_DIR" 2770
}

install_runtime_service_unit() {
  local unit_file

  unit_file="$(root_path "$(runtime_service_unit_path)")"

  render_runtime_service_unit | write_text_file "$unit_file"
  run_cmd chmod 0644 "$unit_file"

  if ! is_live_root; then
    info "wrote runtime systemd unit into test root: ${unit_file}"
    return 0
  fi

  run_cmd systemctl daemon-reload
  run_cmd systemctl enable "$SC_RUNTIME_SERVICE_UNIT_NAME"
}

restart_runtime_service_if_ready() {
  local runtime_entrypoint
  local runtime_daemon
  local runtime_config

  if ! is_live_root; then
    return 0
  fi

  runtime_entrypoint="$(root_path "$(runtime_current_dir)/bin/soundclaw-runtime")"
  runtime_daemon="$(root_path "$(runtime_current_dir)/libexec/soundclaw-runtime-daemon")"
  runtime_config="$(root_path "${SC_CONFIG_DIR}/runtime.toml")"

  if [[ ! -x "$runtime_entrypoint" ]] || [[ ! -x "$runtime_daemon" ]] || [[ ! -f "$runtime_config" ]]; then
    info "runtime service enabled; it will start once a staged runtime and ${SC_CONFIG_DIR}/runtime.toml are present"
    return 0
  fi

  info "restarting ${SC_RUNTIME_SERVICE_UNIT_NAME}"
  run_cmd systemctl restart "$SC_RUNTIME_SERVICE_UNIT_NAME"
}

write_host_config() {
  local config_file
  local bootstrapped_at
  local runtime_service_unit
  local runtime_socket_path

  config_file="$(root_path "$(pi_kit_env_path)")"
  bootstrapped_at="$(timestamp_utc)"
  runtime_service_unit="$(runtime_service_unit_path)"
  runtime_socket_path="$(runtime_control_socket_path)"

  write_text_file "$config_file" <<EOF
INSTALLED_PI_KIT_VERSION=${PI_KIT_VERSION@Q}
INSTALLED_PI_KIT_PROFILE=${PROFILE@Q}
INSTALLED_PI_KIT_PROFILE_DESCRIPTION=${PROFILE_DESCRIPTION@Q}
INSTALLED_PI_KIT_AUDIO_POLICY=${AUDIO_POLICY@Q}
INSTALLED_PI_KIT_EXPECT_EXCLUSIVE_AUDIO=${EXPECT_EXCLUSIVE_AUDIO}
INSTALLED_SC_BASE_DIR=${SC_BASE_DIR@Q}
INSTALLED_SC_RUNTIME_DIR=${SC_RUNTIME_DIR@Q}
INSTALLED_SC_RELEASES_DIR=${SC_RELEASES_DIR@Q}
INSTALLED_SC_CONFIG_DIR=${SC_CONFIG_DIR@Q}
INSTALLED_SC_STATE_DIR=${SC_STATE_DIR@Q}
INSTALLED_SC_RUNTIME_STATE_DIR=${SC_RUNTIME_STATE_DIR@Q}
INSTALLED_SC_LIBRARY_DIR=${SC_LIBRARY_DIR@Q}
INSTALLED_SC_LIBRARY_INTAKE_DIR=${SC_LIBRARY_INTAKE_DIR@Q}
INSTALLED_SC_LOG_DIR=${SC_LOG_DIR@Q}
INSTALLED_SC_RUNTIME_LOG_DIR=${SC_RUNTIME_LOG_DIR@Q}
INSTALLED_SC_SYSTEMD_UNIT_DIR=${SC_SYSTEMD_UNIT_DIR@Q}
INSTALLED_SC_RUNTIME_SERVICE_UNIT_NAME=${SC_RUNTIME_SERVICE_UNIT_NAME@Q}
INSTALLED_SC_RUNTIME_SERVICE_USER=${SC_RUNTIME_SERVICE_USER@Q}
INSTALLED_SC_RUNTIME_ACCESS_GROUP=${SC_RUNTIME_ACCESS_GROUP@Q}
INSTALLED_SC_RUNTIME_OPERATOR_USER=${SC_OPERATOR_USER@Q}
INSTALLED_SC_RUNTIME_SERVICE_UNIT=${runtime_service_unit@Q}
INSTALLED_SC_RUNTIME_SOCKET_PATH=${runtime_socket_path@Q}
INSTALLED_PI_KIT_BOOTSTRAPPED_AT=${bootstrapped_at@Q}
EOF
}

write_state_file() {
  local state_file
  local bootstrapped_at

  state_file="$(root_path "$(pi_kit_state_path)")"
  bootstrapped_at="$(timestamp_utc)"

  write_text_file "$state_file" <<EOF
bootstrapped_at=${bootstrapped_at}
profile=${PROFILE}
audio_policy=${AUDIO_POLICY}
runtime_service_user=${SC_RUNTIME_SERVICE_USER}
runtime_access_group=${SC_RUNTIME_ACCESS_GROUP}
runtime_operator_user=${SC_OPERATOR_USER}
EOF
}

main() {
  while [[ $# -gt 0 ]]; do
    case "$1" in
      --profile)
        [[ $# -ge 2 ]] || die "--profile requires a value"
        PROFILE="$2"
        shift 2
        ;;
      --skip-packages)
        SKIP_PACKAGES=1
        shift
        ;;
      --dry-run)
        DRY_RUN=1
        shift
        ;;
      --help|-h)
        usage
        exit 0
        ;;
      *)
        die "unknown argument: $1"
        ;;
    esac
  done

  load_profile "$PROFILE"
  require_root

  if is_live_root; then
    require_live_systemd
  fi

  install_packages
  install_runtime_service_principals
  ensure_host_layout
  normalize_runtime_config_permissions

  write_host_config
  write_state_file
  install_runtime_service_unit
  restart_runtime_service_if_ready

  info "bootstrap complete for profile '${PROFILE}'"
  info "next step: run ./scripts/smoke-test.sh"
}

main "$@"
