#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# shellcheck source=lib/pi-kit.sh
source "${SCRIPT_DIR}/../lib/pi-kit.sh"

BUNDLE_PATH=""
RUN_LAYOUT_DRY_RUN=1
declare -a TEMP_DIRS=()

cleanup_temp_dirs() {
  local dir

  for dir in "${TEMP_DIRS[@]}"; do
    [[ -n "$dir" ]] || continue
    [[ -e "$dir" ]] || continue
    rm -rf "$dir"
  done
}

trap cleanup_temp_dirs EXIT

usage() {
  cat <<'EOF'
Usage: preflight-release-bundle.sh --bundle /path/to/soundclaw-pi-release.tar.gz [--skip-layout-dry-run]

Validate a generated public SoundClaw release bundle before publication. This
checks the bundle shape that the Pi consumes, including the top-level generated
installer, shell line endings, checksums, and a local SC_ROOT dry-run through
the bundled installer.
EOF
}

detect_bundle_root() {
  local extracted_root="$1"
  local -a top_level_entries=()

  if [[ -f "${extracted_root}/manifest.env" ]]; then
    printf '%s\n' "$extracted_root"
    return 0
  fi

  mapfile -t top_level_entries < <(find "$extracted_root" -mindepth 1 -maxdepth 1 -type d | sort)

  if [[ ${#top_level_entries[@]} -eq 1 ]] && [[ -f "${top_level_entries[0]}/manifest.env" ]]; then
    printf '%s\n' "${top_level_entries[0]}"
    return 0
  fi

  die "could not locate bundle root after extraction; expected manifest.env at the archive root or in a single top-level directory"
}

extract_bundle() {
  local archive_path="$1"
  local extract_dir
  local bundle_root

  [[ -f "$archive_path" ]] || die "release bundle archive does not exist: $archive_path"

  extract_dir="$(mktemp -d)"
  TEMP_DIRS+=("$extract_dir")

  tar -xzf "$archive_path" -C "$extract_dir"
  bundle_root="$(detect_bundle_root "$extract_dir")"
  printf '%s\n' "$bundle_root"
}

verify_checksums() {
  local bundle_root="$1"

  if command_exists sha256sum; then
    (
      cd "$bundle_root"
      sha256sum --check checksums.txt >/dev/null
    )
    return 0
  fi

  if command_exists shasum; then
    (
      cd "$bundle_root"
      shasum -a 256 --check checksums.txt >/dev/null
    )
    return 0
  fi

  die "sha256 checksum verification requires sha256sum or shasum"
}

validate_required_layout() {
  local bundle_root="$1"
  local required_path
  local -a required_paths=(
    "install.sh"
    "manifest.env"
    "checksums.txt"
    "config/runtime.toml"
    "runtime"
    "repos/soundclaw-pi-kit/config/profiles/shared.env"
    "repos/soundclaw-pi-kit/config/profiles/exclusive.env"
    "repos/soundclaw-pi-kit/lib/pi-kit.sh"
    "repos/soundclaw-pi-kit/scripts/bootstrap.sh"
    "repos/soundclaw-pi-kit/scripts/check-release-update.sh"
    "repos/soundclaw-pi-kit/scripts/deploy-asset-library.sh"
    "repos/soundclaw-pi-kit/scripts/deploy-runtime.sh"
    "repos/soundclaw-pi-kit/scripts/deployment-status.sh"
    "repos/soundclaw-pi-kit/scripts/fingerprint-paths.sh"
    "repos/soundclaw-pi-kit/scripts/ingest-library.sh"
    "repos/soundclaw-pi-kit/scripts/install.sh"
    "repos/soundclaw-pi-kit/scripts/operator-console-proof.sh"
    "repos/soundclaw-pi-kit/scripts/phase2-proof-capture.sh"
    "repos/soundclaw-pi-kit/scripts/setup.sh"
    "repos/soundclaw-pi-kit/scripts/smoke-test.sh"
    "repos/soundclaw-pi-kit/scripts/update-install.sh"
    "repos/soundclaw-pi-kit/scripts/wave5-proof-capture.sh"
    "repos/soundclaw-pi-kit/systemd/soundclaw-runtime.service.in"
    "repos/soundclaw-skills/skills"
  )

  for required_path in "${required_paths[@]}"; do
    [[ -e "${bundle_root}/${required_path}" ]] || die \
      "release bundle is missing required path ${required_path}: ${bundle_root}"
  done

  find "${bundle_root}/repos/soundclaw-skills/skills" -mindepth 2 -maxdepth 2 -name skill.toml \
    | grep -q . || die \
      "release bundle skills payload must include at least one skills/<name>/skill.toml: ${bundle_root}"

  if find "$bundle_root" -path '*/.git' -print -quit | grep -q .; then
    die "release bundle must not include Git metadata: ${bundle_root}"
  fi
}

validate_shell_line_endings() {
  local bundle_root="$1"
  local crlf_match=""

  crlf_match="$(
    find "$bundle_root" -type f \
      \( -name '*.sh' -o -name install.sh -o -path '*/bin/soundclaw*' -o -path '*/lib/runtime-common.sh' \) \
      -print0 |
      xargs -0 grep -Il $'\r$' |
      head -n 1 || true
  )"

  [[ -z "$crlf_match" ]] || die \
    "release bundle contains CRLF shell payload line endings: ${crlf_match}"
}

validate_root_installer() {
  local bundle_root="$1"
  local root_installer="${bundle_root}/install.sh"

  [[ -f "$root_installer" ]] || die "release bundle is missing top-level install.sh"

  bash -n "$root_installer"

  if grep -q '\.\./lib/pi-kit\.sh' "$root_installer"; then
    die "top-level install.sh uses repo-local ../lib/pi-kit.sh instead of bundled repos/soundclaw-pi-kit/lib/pi-kit.sh"
  fi

  # shellcheck disable=SC2016
  if grep -Fq '${SCRIPT_DIR}/setup.sh' "$root_installer"; then
    die "top-level install.sh uses repo-local setup.sh instead of bundled repos/soundclaw-pi-kit/scripts/setup.sh"
  fi

  grep -q 'repos/soundclaw-pi-kit/lib/pi-kit.sh' "$root_installer" || die \
    "top-level install.sh does not source bundled repos/soundclaw-pi-kit/lib/pi-kit.sh"
  grep -q 'repos/soundclaw-pi-kit/scripts/setup.sh' "$root_installer" || die \
    "top-level install.sh does not invoke bundled repos/soundclaw-pi-kit/scripts/setup.sh"
}

run_layout_dry_run() {
  local bundle_root="$1"
  local archive_path="$2"
  local dry_root
  local library_source

  dry_root="$(mktemp -d)"
  library_source="$(mktemp -d)"
  TEMP_DIRS+=("$dry_root" "$library_source")

  mkdir -p "${library_source}/assets/preflight"
  printf '{"assets":[{"id":"preflight_silence","format":"wav","relative_path":"preflight/silence.wav"}]}\n' \
    >"${library_source}/index.json"
  printf 'preflight\n' >"${library_source}/assets/preflight/silence.wav"

  SC_ROOT="$dry_root" \
    "${bundle_root}/install.sh" \
    --bundle "$archive_path" \
    --profile shared \
    --skip-packages \
    --allow-no-audio \
    --dry-run \
    --runtime-selector plughw:Preflight \
    --library-source "$library_source" >/dev/null
}

main() {
  local bundle_root

  while [[ $# -gt 0 ]]; do
    case "$1" in
      --bundle)
        [[ $# -ge 2 ]] || die "--bundle requires a value"
        BUNDLE_PATH="$2"
        shift 2
        ;;
      --skip-layout-dry-run)
        RUN_LAYOUT_DRY_RUN=0
        shift
        ;;
      --help|-h)
        usage
        exit 0
        ;;
      *)
        die "unknown argument: $1"
        ;;
    esac
  done

  [[ -n "$BUNDLE_PATH" ]] || die "--bundle is required"

  bundle_root="$(extract_bundle "$BUNDLE_PATH")"
  validate_required_layout "$bundle_root"
  validate_shell_line_endings "$bundle_root"
  validate_root_installer "$bundle_root"
  verify_checksums "$bundle_root"

  if [[ "$RUN_LAYOUT_DRY_RUN" == "1" ]]; then
    run_layout_dry_run "$bundle_root" "$BUNDLE_PATH"
  fi

  printf 'result: PASS\n'
}

main "$@"
