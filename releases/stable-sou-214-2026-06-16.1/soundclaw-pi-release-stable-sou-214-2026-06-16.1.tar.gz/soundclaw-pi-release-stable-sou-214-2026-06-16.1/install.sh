#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# shellcheck source=repos/soundclaw-pi-kit/lib/pi-kit.sh
source "${SCRIPT_DIR}/repos/soundclaw-pi-kit/lib/pi-kit.sh"

BUNDLE_PATH=""
BUNDLE_URL=""
declare -a FORWARD_ARGS=()
declare -a TEMP_DIRS=()

cleanup_temp_dirs() {
  local dir

  for dir in "${TEMP_DIRS[@]}"; do
    [[ -n "$dir" ]] || continue
    [[ -e "$dir" ]] || continue
    rm -rf "$dir"
  done
}

trap cleanup_temp_dirs EXIT

usage() {
  cat <<'EOF'
Usage: install-release.sh (--bundle /path/to/soundclaw-pi-release.tar.gz | --bundle-url https://example.com/soundclaw-pi-release.tar.gz) [setup options]

Download or unpack a published SoundClaw release bundle, verify its manifest and
checksums, then forward the bundled runtime/config/skills inputs into the
existing setup.sh flow.

You must still supply one of the library handoff modes expected by setup.sh:
  --library-source /path/to/prepared/library
or:
  --asset-library-root /path/to/soundclaw-asset-library --library-import-source /path/to/local-library

All other arguments are forwarded to setup.sh.
EOF
}

download_bundle() {
  local download_dir
  local bundle_name
  local download_target

  command_exists curl || die "curl is required for --bundle-url"

  download_dir="$(mktemp -d)"
  TEMP_DIRS+=("$download_dir")

  bundle_name="$(basename "${BUNDLE_URL%%\?*}")"
  [[ -n "$bundle_name" ]] || bundle_name="soundclaw-pi-release.tar.gz"
  download_target="${download_dir}/${bundle_name}"

  info "downloading release bundle from ${BUNDLE_URL}" >&2
  run_cmd curl --fail --location --silent --show-error --output "$download_target" "$BUNDLE_URL"

  printf '%s\n' "$download_target"
}

detect_bundle_root() {
  local extracted_root="$1"
  local -a top_level_entries=()

  if [[ -f "${extracted_root}/manifest.env" ]]; then
    printf '%s\n' "$extracted_root"
    return 0
  fi

  mapfile -t top_level_entries < <(find "$extracted_root" -mindepth 1 -maxdepth 1 -type d | sort)

  if [[ ${#top_level_entries[@]} -eq 1 ]] && [[ -f "${top_level_entries[0]}/manifest.env" ]]; then
    printf '%s\n' "${top_level_entries[0]}"
    return 0
  fi

  die "could not locate bundle root after extraction; expected manifest.env at the archive root or in a single top-level directory"
}

extract_bundle() {
  local archive_path="$1"
  local extract_dir
  local bundle_root

  [[ -f "$archive_path" ]] || die "release bundle archive does not exist: $archive_path"

  extract_dir="$(mktemp -d)"
  TEMP_DIRS+=("$extract_dir")

  info "extracting release bundle ${archive_path}" >&2
  run_cmd tar -xzf "$archive_path" -C "$extract_dir"

  bundle_root="$(detect_bundle_root "$extract_dir")"
  printf '%s\n' "$bundle_root"
}

verify_checksums() {
  local bundle_root="$1"

  if command_exists sha256sum; then
    (
      cd "$bundle_root"
      sha256sum --check checksums.txt
    )
    return 0
  fi

  if command_exists shasum; then
    (
      cd "$bundle_root"
      shasum -a 256 --check checksums.txt
    )
    return 0
  fi

  die "sha256 checksum verification requires sha256sum or shasum"
}

file_sha256() {
  local file_path="$1"

  if command_exists sha256sum; then
    sha256sum "$file_path" | awk '{print $1}'
    return 0
  fi

  if command_exists shasum; then
    shasum -a 256 "$file_path" | awk '{print $1}'
    return 0
  fi

  die "sha256 hashing requires sha256sum or shasum"
}

validate_bundle_layout() {
  local bundle_root="$1"
  local required_pi_kit_path
  local -a required_pi_kit_paths=(
    "config/profiles/shared.env"
    "config/profiles/exclusive.env"
    "lib/pi-kit.sh"
    "scripts/bootstrap.sh"
    "scripts/check-release-update.sh"
    "scripts/deploy-asset-library.sh"
    "scripts/deploy-runtime.sh"
    "scripts/deployment-status.sh"
    "scripts/fingerprint-paths.sh"
    "scripts/install.sh"
    "scripts/setup.sh"
    "scripts/smoke-test.sh"
    "scripts/update-install.sh"
    "scripts/wave5-proof-capture.sh"
    "systemd/soundclaw-runtime.service.in"
  )

  [[ -f "${bundle_root}/manifest.env" ]] || die \
    "release bundle is missing manifest.env: ${bundle_root}"
  [[ -f "${bundle_root}/checksums.txt" ]] || die \
    "release bundle is missing checksums.txt: ${bundle_root}"
  [[ -d "${bundle_root}/runtime" ]] || die \
    "release bundle is missing runtime/: ${bundle_root}"
  [[ -f "${bundle_root}/config/runtime.toml" ]] || die \
    "release bundle is missing config/runtime.toml: ${bundle_root}"
  for required_pi_kit_path in "${required_pi_kit_paths[@]}"; do
    [[ -e "${bundle_root}/repos/soundclaw-pi-kit/${required_pi_kit_path}" ]] || die \
      "release bundle is missing pi-kit install payload path ${required_pi_kit_path}: ${bundle_root}"
  done
  [[ -d "${bundle_root}/repos/soundclaw-skills/skills" ]] || die \
    "release bundle is missing repos/soundclaw-skills/skills: ${bundle_root}"
  find "${bundle_root}/repos/soundclaw-skills/skills" -mindepth 2 -maxdepth 2 -name skill.toml \
    | grep -q . || die \
      "release bundle skills payload must include at least one skills/<name>/skill.toml: ${bundle_root}"
  if find "$bundle_root" -path '*/.git' -print -quit | grep -q .; then
    die "release bundle must not include Git metadata: ${bundle_root}"
  fi

  verify_checksums "$bundle_root"
}

validate_manifest() {
  [[ -n "${SOUNDCLAW_RELEASE_ID:-}" ]] || die \
    "bundle manifest is missing SOUNDCLAW_RELEASE_ID"
  [[ -n "${SOUNDCLAW_RUNTIME_REF:-}" ]] || die \
    "bundle manifest is missing SOUNDCLAW_RUNTIME_REF"
  [[ -n "${SOUNDCLAW_RUNTIME_CONFIG_REF:-}" ]] || die \
    "bundle manifest is missing SOUNDCLAW_RUNTIME_CONFIG_REF"
  [[ -n "${SOUNDCLAW_PI_KIT_REF:-}" ]] || die \
    "bundle manifest is missing SOUNDCLAW_PI_KIT_REF"
  [[ -n "${SOUNDCLAW_SKILLS_REF:-}" ]] || die \
    "bundle manifest is missing SOUNDCLAW_SKILLS_REF"
}

main() {
  local archive_path=""
  local bundle_root=""
  local bundle_source=""
  local bundle_asset=""
  local manifest_sha256=""
  local checksums_sha256=""
  local source_tuple=""
  local -a setup_args=()
  local skill_name

  while [[ $# -gt 0 ]]; do
    case "$1" in
      --bundle)
        [[ $# -ge 2 ]] || die "--bundle requires a value"
        BUNDLE_PATH="$2"
        shift 2
        ;;
      --bundle-url)
        [[ $# -ge 2 ]] || die "--bundle-url requires a value"
        BUNDLE_URL="$2"
        shift 2
        ;;
      --help|-h)
        usage
        exit 0
        ;;
      *)
        FORWARD_ARGS+=("$1")
        shift
        ;;
    esac
  done

  if [[ -n "$BUNDLE_PATH" ]] && [[ -n "$BUNDLE_URL" ]]; then
    die "choose either --bundle or --bundle-url"
  fi

  if [[ -z "$BUNDLE_PATH" ]] && [[ -z "$BUNDLE_URL" ]]; then
    die "either --bundle or --bundle-url is required"
  fi

  if [[ -n "$BUNDLE_URL" ]]; then
    archive_path="$(download_bundle)"
    bundle_source="$BUNDLE_URL"
  else
    archive_path="$BUNDLE_PATH"
    bundle_source="$BUNDLE_PATH"
  fi
  bundle_asset="$(basename "${bundle_source%%\?*}")"

  bundle_root="$(extract_bundle "$archive_path")"
  validate_bundle_layout "$bundle_root"

  # shellcheck disable=SC1090
  source "${bundle_root}/manifest.env"
  validate_manifest

  manifest_sha256="$(file_sha256 "${bundle_root}/manifest.env")"
  checksums_sha256="$(file_sha256 "${bundle_root}/checksums.txt")"
  source_tuple="runtime=${SOUNDCLAW_RUNTIME_REF} runtime_config=${SOUNDCLAW_RUNTIME_CONFIG_REF} pi_kit=${SOUNDCLAW_PI_KIT_REF} skills=${SOUNDCLAW_SKILLS_REF}"
  if [[ -n "${SOUNDCLAW_LIBRARY_RELEASE_REF:-}" ]]; then
    source_tuple+=" library=${SOUNDCLAW_LIBRARY_RELEASE_REF}"
  fi

  setup_args=(
    --runtime-source "${bundle_root}/runtime"
    --runtime-release-ref "runtime-${SOUNDCLAW_RUNTIME_REF:0:7}"
    --runtime-config "${bundle_root}/config/runtime.toml"
    --runtime-config-ref "$SOUNDCLAW_RUNTIME_CONFIG_REF"
    --skills-source "${bundle_root}/repos/soundclaw-skills"
    --skills-ref "$SOUNDCLAW_SKILLS_REF"
    --public-release-id "$SOUNDCLAW_RELEASE_ID"
    --public-bundle-source "$bundle_source"
    --public-bundle-asset "$bundle_asset"
    --public-manifest-sha256 "$manifest_sha256"
    --public-checksums-sha256 "$checksums_sha256"
    --public-source-tuple "$source_tuple"
  )

  if [[ -n "${SOUNDCLAW_LIBRARY_RELEASE_REF:-}" ]]; then
    setup_args+=(--library-release-ref "$SOUNDCLAW_LIBRARY_RELEASE_REF")
  fi

  if [[ -n "${SOUNDCLAW_PI_KIT_REF:-}" ]]; then
    setup_args+=(--pi-kit-ref "$SOUNDCLAW_PI_KIT_REF")
  fi

  if [[ -n "${SOUNDCLAW_DEFAULT_SKILLS:-}" ]]; then
    for skill_name in ${SOUNDCLAW_DEFAULT_SKILLS}; do
      setup_args+=(--skill "$skill_name")
    done
  fi

  info "running setup flow from release bundle ${SOUNDCLAW_RELEASE_ID}"
  "${bundle_root}/repos/soundclaw-pi-kit/scripts/setup.sh" "${setup_args[@]}" "${FORWARD_ARGS[@]}"
}

main "$@"
