# Set Volume Examples

## Example Requests

- "What is the current global volume?"
- "Set global volume to 82 percent."
- "Set global volume to 70 percent and reload now."
- "Set per-channel gain on route `1:9:85`."

## Expected Skill Behavior

- Use `soundclawctl volume show [--json]` for inspection requests.
- Use `soundclawctl volume set-global --global-volume-percent <0-200> [--json]`
  only when the target value is explicit and in range.
- Explain that `set-global` updates config and that running daemons require
  `soundclawctl runtime reload [--json]` to observe the new value.
- Run reload only when the operator requested immediate apply in the same
  workflow.
- Route per-channel or per-route gain requests to `manage-output` and preserve
  `--route <source:dest[:gain_percent]>` wording.
