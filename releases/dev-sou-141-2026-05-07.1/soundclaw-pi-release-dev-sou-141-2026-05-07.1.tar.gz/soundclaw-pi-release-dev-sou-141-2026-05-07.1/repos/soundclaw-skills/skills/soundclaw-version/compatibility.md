# Compatibility

Operator job: Report installed SoundClaw deployment identity and guide public
GitHub update checks through the pi-kit-owned path.

Runtime and pi-kit dependency:

- Status: Pending current runtime and pi-kit release-line declaration for this
  promoted command shape.
- Contract reference: `soundclaw/docs/system-architecture.md`
- Command(s): `soundclawctl deployment status [--json]`
- Command(s): `soundclaw-pi-kit/scripts/check-release-update.sh [--json]`
- Command(s): `soundclaw-pi-kit/scripts/update-install.sh --release-id <release-id> --yes [setup options]`

Minimum compatible runtime release line: Pending definition in
`soundclaw-runtime`.

Minimum compatible pi-kit release line: Pending definition in
`soundclaw-pi-kit`.

Tested runtime release line: Not yet validated against a promoted runtime
release line.

Tested pi-kit release line: Not yet validated against a promoted pi-kit release
line.

Packaging target: Plain skill

ClawHub publication status: Not published

## Boundary Notes

This skill depends on the runtime-promoted deployment identity surface for
installed version reporting. It must not parse pi-kit setup state files.

Update checks and update installs remain pi-kit-owned. The skill may call or
guide the operator to the pi-kit commands, but it must not implement release
lookup, bundle download, checksum verification, setup execution, rollback, or
service management itself.

Public backend install and update instructions live in the pi-kit GitHub
install/update runbook:
`soundclaw-pi-kit/docs/github-install-update.md`.
