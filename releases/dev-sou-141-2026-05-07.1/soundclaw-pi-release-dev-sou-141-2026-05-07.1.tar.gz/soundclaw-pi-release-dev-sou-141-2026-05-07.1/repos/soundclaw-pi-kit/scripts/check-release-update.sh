#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# shellcheck source=../lib/pi-kit.sh
source "${SCRIPT_DIR}/../lib/pi-kit.sh"

OUTPUT_JSON=0
GITHUB_REPO="${SOUNDCLAW_RELEASE_GITHUB_REPO:-soundclaw/soundclaw-release}"
RELEASE_JSON_FILE=""

usage() {
  cat <<'EOF'
Usage: check-release-update.sh [--json] [--repo owner/name] [--release-json /path/to/fixture.json]

Check the public SoundClaw GitHub release surface for the latest release bundle
and compare it with the installed release id in setup-run.env. This command is
read-only.
EOF
}

json_escape() {
  local value="$1"

  value="${value//\\/\\\\}"
  value="${value//\"/\\\"}"
  value="${value//$'\n'/\\n}"
  value="${value//$'\r'/\\r}"
  value="${value//$'\t'/\\t}"

  printf '%s' "$value"
}

json_field() {
  local name="$1"
  local value="$2"
  local suffix="${3-,}"

  printf '  "%s": "%s"%s\n' "$name" "$(json_escape "$value")" "$suffix"
}

load_setup_state() {
  local state_file="$1"

  [[ -f "$state_file" ]] || return 1

  # shellcheck disable=SC1090
  source "$state_file"
}

read_release_json() {
  local api_url

  if [[ -n "$RELEASE_JSON_FILE" ]]; then
    [[ -f "$RELEASE_JSON_FILE" ]] || die "release JSON fixture does not exist: $RELEASE_JSON_FILE"
    cat "$RELEASE_JSON_FILE"
    return 0
  fi

  command_exists curl || die "curl is required to query GitHub releases"
  api_url="https://api.github.com/repos/${GITHUB_REPO}/releases/latest"
  curl --fail --location --silent --show-error \
    --header 'Accept: application/vnd.github+json' \
    "$api_url"
}

json_string_value() {
  local key="$1"
  local json_file="$2"

  grep -o "\"${key}\"[[:space:]]*:[[:space:]]*\"[^\"]*\"" "$json_file" \
    | head -n 1 \
    | sed -E "s/^\"${key}\"[[:space:]]*:[[:space:]]*\"([^\"]*)\"$/\\1/"
}

extract_release_id() {
  local latest_tag="$1"
  local asset_url="$2"
  local release_id=""

  if [[ "$latest_tag" == release-bundle-* ]]; then
    release_id="${latest_tag#release-bundle-}"
  fi

  if [[ -z "$release_id" && "$asset_url" =~ soundclaw-pi-release-([^/]+)\.tar\.gz ]]; then
    release_id="${BASH_REMATCH[1]}"
  fi

  printf '%s\n' "$release_id"
}

print_json() {
  local status="$1"
  local reason="$2"
  local installed_release_id="$3"
  local latest_release_id="$4"
  local latest_tag="$5"
  local bundle_url="$6"
  local release_url="$7"

  printf '{\n'
  json_field "status" "$status"
  json_field "reason" "$reason"
  json_field "installed_release_id" "$installed_release_id"
  json_field "latest_release_id" "$latest_release_id"
  json_field "latest_tag" "$latest_tag"
  json_field "latest_bundle_url" "$bundle_url"
  json_field "latest_bundle_asset" "$(basename "${bundle_url%%\?*}")"
  json_field "release_url" "$release_url"
  json_field "github_repo" "$GITHUB_REPO" ""
  printf '}\n'
}

print_text() {
  local status="$1"
  local reason="$2"
  local installed_release_id="$3"
  local latest_release_id="$4"
  local latest_tag="$5"
  local bundle_url="$6"
  local release_url="$7"

  printf 'status: %s\n' "$status"
  if [[ -n "$reason" ]]; then
    printf 'reason: %s\n' "$reason"
  fi
  printf 'installed_release_id: %s\n' "$installed_release_id"
  printf 'latest_release_id: %s\n' "$latest_release_id"
  printf 'latest_tag: %s\n' "$latest_tag"
  printf 'latest_bundle_url: %s\n' "$bundle_url"
  printf 'latest_bundle_asset: %s\n' "$(basename "${bundle_url%%\?*}")"
  printf 'release_url: %s\n' "$release_url"
  printf 'github_repo: %s\n' "$GITHUB_REPO"
}

main() {
  local setup_state_file
  local installed_release_id=""
  local release_json_tmp
  local latest_tag=""
  local latest_release_id=""
  local bundle_url=""
  local release_url=""
  local status="unavailable"
  local reason=""

  while [[ $# -gt 0 ]]; do
    case "$1" in
      --json)
        OUTPUT_JSON=1
        shift
        ;;
      --repo)
        [[ $# -ge 2 ]] || die "--repo requires a value"
        GITHUB_REPO="$2"
        shift 2
        ;;
      --release-json)
        [[ $# -ge 2 ]] || die "--release-json requires a value"
        RELEASE_JSON_FILE="$2"
        shift 2
        ;;
      --help|-h)
        usage
        exit 0
        ;;
      *)
        die "unknown argument: $1"
        ;;
    esac
  done

  setup_state_file="$(root_path "$(setup_run_state_path)")"
  if load_setup_state "$setup_state_file"; then
    installed_release_id="${SETUP_PUBLIC_RELEASE_ID:-}"
  fi

  release_json_tmp="$(mktemp)"
  trap "rm -f '$release_json_tmp'" EXIT

  if ! read_release_json >"$release_json_tmp"; then
    reason="could not query GitHub release metadata"
  else
    latest_tag="$(json_string_value tag_name "$release_json_tmp" || true)"
    release_url="$(json_string_value html_url "$release_json_tmp" || true)"
    bundle_url="$(
      grep -o '"browser_download_url"[[:space:]]*:[[:space:]]*"[^"]*soundclaw-pi-release[^"]*\.tar\.gz[^"]*"' "$release_json_tmp" \
        | head -n 1 \
        | sed -E 's/^"browser_download_url"[[:space:]]*:[[:space:]]*"([^"]*)"$/\1/' \
        || true
    )"
    latest_release_id="$(extract_release_id "$latest_tag" "$bundle_url")"

    if [[ -z "$installed_release_id" ]]; then
      reason="installed setup state does not include a public release id"
    elif [[ -z "$latest_release_id" || -z "$bundle_url" ]]; then
      reason="latest GitHub release metadata does not include a recognizable SoundClaw release bundle"
    elif [[ "$latest_release_id" == "$installed_release_id" ]]; then
      status="no-update"
      reason="installed release is already the latest public release"
    else
      status="update-available"
      reason="latest public release differs from installed release"
    fi
  fi

  if [[ "$OUTPUT_JSON" == "1" ]]; then
    print_json \
      "$status" \
      "$reason" \
      "$installed_release_id" \
      "$latest_release_id" \
      "$latest_tag" \
      "$bundle_url" \
      "$release_url"
  else
    print_text \
      "$status" \
      "$reason" \
      "$installed_release_id" \
      "$latest_release_id" \
      "$latest_tag" \
      "$bundle_url" \
      "$release_url"
  fi
}

main "$@"
