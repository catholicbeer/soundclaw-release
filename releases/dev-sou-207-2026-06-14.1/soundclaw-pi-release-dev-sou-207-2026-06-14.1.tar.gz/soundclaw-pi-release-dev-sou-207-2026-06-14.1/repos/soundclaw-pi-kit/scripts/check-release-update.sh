#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# shellcheck source=../lib/pi-kit.sh
source "${SCRIPT_DIR}/../lib/pi-kit.sh"

OUTPUT_JSON=0
GITHUB_REPO="${SOUNDCLAW_RELEASE_GITHUB_REPO:-soundclaw/soundclaw-release}"
RELEASE_JSON_FILE=""
RELEASE_CHANNEL="prod"
TARGET_RELEASE_ID=""

usage() {
  cat <<'EOF'
Usage: check-release-update.sh [--json] [--repo owner/name] [--channel prod|rc] [--release-id ID] [--release-json /path/to/fixture.json]

Check the public SoundClaw GitHub release surface for the latest release bundle
and compare it with the installed release id in setup-run.env. The default
production channel uses GitHub /releases/latest. The rc channel selects the
latest SoundClaw prerelease bundle without treating it as production latest.
Use --release-id for an exact WDR/RTW candidate. This command is read-only.
EOF
}

json_escape() {
  local value="$1"

  value="${value//\\/\\\\}"
  value="${value//\"/\\\"}"
  value="${value//$'\n'/\\n}"
  value="${value//$'\r'/\\r}"
  value="${value//$'\t'/\\t}"

  printf '%s' "$value"
}

json_field() {
  local name="$1"
  local value="$2"
  local suffix="${3-,}"

  printf '  "%s": "%s"%s\n' "$name" "$(json_escape "$value")" "$suffix"
}

load_setup_state() {
  local state_file="$1"

  [[ -f "$state_file" ]] || return 1

  # shellcheck disable=SC1090
  source "$state_file"
}

read_release_json() {
  local api_url

  if [[ -n "$RELEASE_JSON_FILE" ]]; then
    [[ -f "$RELEASE_JSON_FILE" ]] || die "release JSON fixture does not exist: $RELEASE_JSON_FILE"
    cat "$RELEASE_JSON_FILE"
    return 0
  fi

  command_exists curl || die "curl is required to query GitHub releases"
  if [[ -n "$TARGET_RELEASE_ID" ]]; then
    api_url="https://api.github.com/repos/${GITHUB_REPO}/releases/tags/release-bundle-${TARGET_RELEASE_ID}"
  elif [[ "$RELEASE_CHANNEL" == "rc" ]]; then
    api_url="https://api.github.com/repos/${GITHUB_REPO}/releases?per_page=30"
  else
    api_url="https://api.github.com/repos/${GITHUB_REPO}/releases/latest"
  fi

  curl --fail --location --silent --show-error \
    --header 'Accept: application/vnd.github+json' \
    "$api_url"
}

select_release_json() {
  local raw_json_file="$1"

  if [[ -n "$TARGET_RELEASE_ID" || "$RELEASE_CHANNEL" == "prod" ]]; then
    cat "$raw_json_file"
    return 0
  fi

  command_exists python3 || die "python3 is required to select the rc release channel"
  python3 - "$raw_json_file" <<'PY'
import json
import sys

with open(sys.argv[1], encoding="utf-8") as handle:
    data = json.load(handle)

releases = data if isinstance(data, list) else [data]

for release in releases:
    if release.get("draft") or not release.get("prerelease"):
        continue

    tag_name = str(release.get("tag_name") or "")
    if not tag_name.startswith("release-bundle-"):
        continue

    release_id = tag_name[len("release-bundle-"):]
    if not (release_id.startswith("dev-") or release_id.startswith("rc-")):
        continue

    for asset in release.get("assets") or []:
        url = str(asset.get("browser_download_url") or "")
        if "soundclaw-pi-release-" in url and url.split("?", 1)[0].endswith(".tar.gz"):
            print(json.dumps(release, separators=(",", ":")))
            sys.exit(0)

sys.exit(2)
PY
}

json_string_value() {
  local key="$1"
  local json_file="$2"

  grep -o "\"${key}\"[[:space:]]*:[[:space:]]*\"[^\"]*\"" "$json_file" \
    | head -n 1 \
    | sed -E "s/^\"${key}\"[[:space:]]*:[[:space:]]*\"([^\"]*)\"$/\\1/"
}

extract_release_id() {
  local latest_tag="$1"
  local asset_url="$2"
  local release_id=""

  if [[ "$latest_tag" == release-bundle-* ]]; then
    release_id="${latest_tag#release-bundle-}"
  fi

  if [[ -z "$release_id" && "$asset_url" =~ soundclaw-pi-release-([^/]+)\.tar\.gz ]]; then
    release_id="${BASH_REMATCH[1]}"
  fi

  printf '%s\n' "$release_id"
}

print_json() {
  local status="$1"
  local reason="$2"
  local installed_release_id="$3"
  local latest_release_id="$4"
  local latest_tag="$5"
  local bundle_url="$6"
  local release_url="$7"
  local release_channel="$8"

  printf '{\n'
  json_field "status" "$status"
  json_field "reason" "$reason"
  json_field "installed_release_id" "$installed_release_id"
  json_field "latest_release_id" "$latest_release_id"
  json_field "latest_tag" "$latest_tag"
  json_field "latest_bundle_url" "$bundle_url"
  json_field "latest_bundle_asset" "$(basename "${bundle_url%%\?*}")"
  json_field "release_url" "$release_url"
  json_field "release_channel" "$release_channel"
  json_field "github_repo" "$GITHUB_REPO" ""
  printf '}\n'
}

print_text() {
  local status="$1"
  local reason="$2"
  local installed_release_id="$3"
  local latest_release_id="$4"
  local latest_tag="$5"
  local bundle_url="$6"
  local release_url="$7"
  local release_channel="$8"

  printf 'status: %s\n' "$status"
  if [[ -n "$reason" ]]; then
    printf 'reason: %s\n' "$reason"
  fi
  printf 'installed_release_id: %s\n' "$installed_release_id"
  printf 'latest_release_id: %s\n' "$latest_release_id"
  printf 'latest_tag: %s\n' "$latest_tag"
  printf 'latest_bundle_url: %s\n' "$bundle_url"
  printf 'latest_bundle_asset: %s\n' "$(basename "${bundle_url%%\?*}")"
  printf 'release_url: %s\n' "$release_url"
  printf 'release_channel: %s\n' "$release_channel"
  printf 'github_repo: %s\n' "$GITHUB_REPO"
}

main() {
  local setup_state_file
  local installed_release_id=""
  local release_json_raw_tmp
  local release_json_tmp
  local latest_tag=""
  local latest_release_id=""
  local bundle_url=""
  local release_url=""
  local release_channel=""
  local status="unavailable"
  local reason=""

  while [[ $# -gt 0 ]]; do
    case "$1" in
      --json)
        OUTPUT_JSON=1
        shift
        ;;
      --repo)
        [[ $# -ge 2 ]] || die "--repo requires a value"
        GITHUB_REPO="$2"
        shift 2
        ;;
      --channel)
        [[ $# -ge 2 ]] || die "--channel requires a value"
        case "$2" in
          prod|rc)
            RELEASE_CHANNEL="$2"
            ;;
          *)
            die "--channel must be one of: prod, rc"
            ;;
        esac
        shift 2
        ;;
      --release-id)
        [[ $# -ge 2 ]] || die "--release-id requires a value"
        TARGET_RELEASE_ID="${2#release-bundle-}"
        [[ -n "$TARGET_RELEASE_ID" ]] || die "--release-id requires a non-empty value"
        shift 2
        ;;
      --release-json)
        [[ $# -ge 2 ]] || die "--release-json requires a value"
        RELEASE_JSON_FILE="$2"
        shift 2
        ;;
      --help|-h)
        usage
        exit 0
        ;;
      *)
        die "unknown argument: $1"
        ;;
    esac
  done
  release_channel="$RELEASE_CHANNEL"
  if [[ -n "$TARGET_RELEASE_ID" ]]; then
    release_channel="exact"
  fi

  setup_state_file="$(root_path "$(setup_run_state_path)")"
  if load_setup_state "$setup_state_file"; then
    installed_release_id="${SETUP_PUBLIC_RELEASE_ID:-}"
  fi

  release_json_raw_tmp="$(mktemp)"
  release_json_tmp="$(mktemp)"
  trap "rm -f '$release_json_raw_tmp' '$release_json_tmp'" EXIT

  if ! read_release_json >"$release_json_raw_tmp"; then
    reason="could not query GitHub release metadata"
  elif ! select_release_json "$release_json_raw_tmp" >"$release_json_tmp"; then
    reason="${release_channel} GitHub release metadata does not include a recognizable SoundClaw release bundle"
  else
    latest_tag="$(json_string_value tag_name "$release_json_tmp" || true)"
    release_url="$(json_string_value html_url "$release_json_tmp" || true)"
    bundle_url="$(
      grep -o '"browser_download_url"[[:space:]]*:[[:space:]]*"[^"]*soundclaw-pi-release[^"]*\.tar\.gz[^"]*"' "$release_json_tmp" \
        | head -n 1 \
        | sed -E 's/^"browser_download_url"[[:space:]]*:[[:space:]]*"([^"]*)"$/\1/' \
        || true
    )"
    latest_release_id="$(extract_release_id "$latest_tag" "$bundle_url")"

    if [[ -z "$installed_release_id" ]]; then
      reason="installed setup state does not include a public release id"
    elif [[ -z "$latest_release_id" || -z "$bundle_url" ]]; then
      reason="${release_channel} GitHub release metadata does not include a recognizable SoundClaw release bundle"
    elif [[ "$latest_release_id" == "$installed_release_id" ]]; then
      status="no-update"
      reason="installed release already matches the selected ${release_channel} release"
    else
      status="update-available"
      reason="selected ${release_channel} release differs from installed release"
    fi
  fi

  if [[ "$OUTPUT_JSON" == "1" ]]; then
    print_json \
      "$status" \
      "$reason" \
      "$installed_release_id" \
      "$latest_release_id" \
      "$latest_tag" \
      "$bundle_url" \
      "$release_url" \
      "$release_channel"
  else
    print_text \
      "$status" \
      "$reason" \
      "$installed_release_id" \
      "$latest_release_id" \
      "$latest_tag" \
      "$bundle_url" \
      "$release_url" \
      "$release_channel"
  fi
}

main "$@"
