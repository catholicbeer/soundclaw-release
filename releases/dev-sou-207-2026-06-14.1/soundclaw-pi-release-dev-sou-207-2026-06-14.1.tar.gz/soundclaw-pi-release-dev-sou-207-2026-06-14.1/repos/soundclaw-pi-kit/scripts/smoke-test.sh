#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# shellcheck source=../lib/pi-kit.sh
source "${SCRIPT_DIR}/../lib/pi-kit.sh"

ALLOW_NO_AUDIO=0
FAILURES=0
WARNINGS=0
GSTREAMER_TOOLING_READY=0

usage() {
  cat <<'EOF'
Usage: smoke-test.sh [--allow-no-audio]

Validate that the host contract laid down by bootstrap exists and that the
backend toolchain required by the SoundClaw runtime MVP is present.
EOF
}

record_failure() {
  printf 'fail: %s\n' "$1" >&2
  FAILURES=$((FAILURES + 1))
}

record_warning() {
  printf 'warn: %s\n' "$1" >&2
  WARNINGS=$((WARNINGS + 1))
}

check_path() {
  local target
  local label="$1"
  local absolute_path="$2"

  target="$(root_path "$absolute_path")"

  if [[ -e "$target" ]]; then
    info "${label}: found ${target}"
  else
    record_failure "${label}: missing ${target}"
  fi
}

check_mode_owner() {
  local label="$1"
  local absolute_path="$2"
  local expected_owner="$3"
  local expected_group="$4"
  local expected_mode="$5"
  local target
  local actual_owner
  local actual_group
  local actual_mode

  target="$(root_path "$absolute_path")"

  if [[ ! -e "$target" ]]; then
    record_failure "${label}: missing ${target}"
    return 1
  fi

  actual_owner="$(stat -c '%U' "$target")"
  actual_group="$(stat -c '%G' "$target")"
  actual_mode="$(stat -c '%a' "$target")"

  if [[ "$actual_owner" == "$expected_owner" ]] && \
     [[ "$actual_group" == "$expected_group" ]] && \
     [[ "$actual_mode" == "$expected_mode" ]]; then
    info "${label}: owner/group/mode ${actual_owner}:${actual_group} ${actual_mode}"
    return 0
  fi

  record_failure \
    "${label}: expected ${expected_owner}:${expected_group} ${expected_mode}, found ${actual_owner}:${actual_group} ${actual_mode}"
}

check_command() {
  local command_name="$1"

  if command_exists "$command_name"; then
    info "command available: ${command_name}"
  else
    record_failure "required command missing: ${command_name}"
  fi
}

check_gstreamer_element() {
  local element="$1"

  if gst-inspect-1.0 "$element" >/dev/null 2>&1; then
    info "GStreamer element available: ${element}"
  else
    record_failure "required GStreamer element missing: ${element}"
  fi
}

load_installed_config() {
  local config_file

  config_file="$(root_path "$(pi_kit_env_path)")"

  if ! load_installed_layout; then
    record_failure "missing config file: ${config_file}"
    return 1
  fi
  return 0
}

check_library_snapshot() {
  local state_file
  local library_index

  state_file="$(root_path "$(library_deploy_state_path)")"

  if [[ ! -f "$state_file" ]]; then
    info "library snapshot not yet promoted into ${SC_LIBRARY_DIR}"
    return 0
  fi

  info "library deploy state found: ${state_file}"
  check_path "library index" "$(library_index_path)"
  check_path "library assets dir" "$(library_assets_dir)"

  if ! is_live_root; then
    info "skipping runtime service user library read check for SC_ROOT=${SC_ROOT}"
    return 0
  fi

  if ! user_exists "$SC_RUNTIME_SERVICE_USER"; then
    record_failure "runtime service user missing: ${SC_RUNTIME_SERVICE_USER}"
    return 1
  fi

  if ! command_exists sudo; then
    record_failure "sudo is required to verify runtime service user library reads"
    return 1
  fi

  library_index="$(root_path "$(library_index_path)")"
  if sudo -u "$SC_RUNTIME_SERVICE_USER" test -r "$library_index"; then
    info "library index is readable by ${SC_RUNTIME_SERVICE_USER}"
  else
    record_failure "library index is not readable by ${SC_RUNTIME_SERVICE_USER}: ${library_index}"
  fi
}

check_audio_device() {
  local audio_output

  if ! is_live_root; then
    info "skipping live audio device checks for SC_ROOT=${SC_ROOT}"
    return 0
  fi

  if ! command_exists aplay; then
    record_failure "alsa-utils is not installed; aplay is unavailable"
    return 1
  fi

  audio_output="$(aplay -l 2>&1 || true)"

  if grep -q '^card ' <<<"$audio_output"; then
    info "audio device detected by ALSA"
    return 0
  fi

  if [[ "$ALLOW_NO_AUDIO" == "1" ]]; then
    record_warning "no ALSA playback device detected"
    return 0
  fi

  record_failure "no ALSA playback device detected"
}

check_backend_commands() {
  local command_name

  for command_name in "${REQUIRED_COMMANDS[@]}"; do
    check_command "$command_name"
  done

  if command_exists gst-inspect-1.0 && command_exists gst-launch-1.0; then
    GSTREAMER_TOOLING_READY=1
  fi
}

check_gstreamer_backend() {
  local element

  if [[ "$GSTREAMER_TOOLING_READY" != "1" ]]; then
    info "skipping GStreamer element inspection because required tooling is unavailable"
    return 0
  fi

  for element in "${REQUIRED_GSTREAMER_ELEMENTS[@]}"; do
    check_gstreamer_element "$element"
  done
}

check_exclusive_profile() {
  local broker
  local detected=0
  local audio_policy="${INSTALLED_PI_KIT_AUDIO_POLICY:-shared}"

  if [[ "$audio_policy" != "exclusive" ]]; then
    return 0
  fi

  if ! is_live_root; then
    info "skipping exclusive-audio broker checks for SC_ROOT=${SC_ROOT}"
    return 0
  fi

  for broker in pipewire pulseaudio wireplumber; do
    if pgrep -x "$broker" >/dev/null 2>&1; then
      record_warning "exclusive profile selected, but audio broker '${broker}' is running"
      detected=1
    fi
  done

  if [[ "$detected" == "0" ]]; then
    info "exclusive profile: no common audio brokers detected"
  fi
}

check_runtime_service_contract() {
  local runtime_service_user="${INSTALLED_SC_RUNTIME_SERVICE_USER:-$SC_RUNTIME_SERVICE_USER}"
  local runtime_access_group="${INSTALLED_SC_RUNTIME_ACCESS_GROUP:-$SC_RUNTIME_ACCESS_GROUP}"
  local runtime_operator_user="${INSTALLED_SC_RUNTIME_OPERATOR_USER:-}"
  local runtime_service_unit="${INSTALLED_SC_RUNTIME_SERVICE_UNIT:-$(runtime_service_unit_path)}"

  check_path "runtime systemd unit" "$runtime_service_unit"

  if ! is_live_root; then
    info "skipping live runtime user/group checks for SC_ROOT=${SC_ROOT}"
    return 0
  fi

  if user_exists "$runtime_service_user"; then
    info "runtime service user present: ${runtime_service_user}"
  else
    record_failure "runtime service user missing: ${runtime_service_user}"
  fi

  if group_exists "$runtime_access_group"; then
    info "runtime access group present: ${runtime_access_group}"
  else
    record_failure "runtime access group missing: ${runtime_access_group}"
  fi

  if group_exists audio; then
    if user_in_group "$runtime_service_user" audio; then
      info "runtime service user is in audio group"
    else
      record_failure "runtime service user is not in the audio group"
    fi
  else
    record_warning "audio group is missing; verify ALSA device permissions for the runtime service user"
  fi

  check_mode_owner "runtime state dir permissions" \
    "$SC_RUNTIME_STATE_DIR" "$runtime_service_user" "$runtime_access_group" 2770
  check_mode_owner "runtime log dir permissions" \
    "$SC_RUNTIME_LOG_DIR" "$runtime_service_user" "$runtime_access_group" 2770
  check_mode_owner "runtime config dir permissions" \
    "$SC_CONFIG_DIR" "$runtime_service_user" "$runtime_access_group" 750

  if [[ -f "$(root_path "$(runtime_config_path)")" ]]; then
    check_mode_owner "runtime config permissions" \
      "$(runtime_config_path)" "$runtime_service_user" "$runtime_access_group" 640
  fi

  if systemd_ready; then
    if systemctl is-enabled --quiet "$SC_RUNTIME_SERVICE_UNIT_NAME"; then
      info "runtime systemd unit enabled: ${SC_RUNTIME_SERVICE_UNIT_NAME}"
    else
      record_failure "runtime systemd unit is not enabled: ${SC_RUNTIME_SERVICE_UNIT_NAME}"
    fi
  else
    record_failure "systemd is not active; runtime service wiring cannot be validated"
  fi

  if [[ -z "$runtime_operator_user" ]]; then
    record_warning "no operator user is recorded in pi-kit.env; rerun bootstrap or repair with SC_OPERATOR_USER=<user> if you need non-root soundclawctl access"
    return 0
  fi

  if ! user_exists "$runtime_operator_user"; then
    record_failure "recorded operator user is missing: ${runtime_operator_user}"
    return 0
  fi

  if user_in_group "$runtime_operator_user" "$runtime_access_group"; then
    info "operator user is in runtime access group: ${runtime_operator_user}"
  else
    record_failure \
      "operator user is not in runtime access group ${runtime_access_group}: ${runtime_operator_user}"
  fi

  if [[ "$(id -un)" == "$runtime_operator_user" ]]; then
    if id -nG | tr ' ' '\n' | grep -Fx "$runtime_access_group" >/dev/null 2>&1; then
      info "current login session already has runtime access group: ${runtime_access_group}"
    else
      record_warning \
        "current login session has not picked up ${runtime_access_group}; start a new login shell or run newgrp ${runtime_access_group} before non-root soundclawctl checks"
    fi
  fi
}

main() {
  while [[ $# -gt 0 ]]; do
    case "$1" in
      --allow-no-audio)
        ALLOW_NO_AUDIO=1
        shift
        ;;
      --help|-h)
        usage
        exit 0
        ;;
      *)
        die "unknown argument: $1"
        ;;
    esac
  done

  load_installed_config || true

  check_path "base dir" "$SC_BASE_DIR"
  check_path "runtime dir" "$SC_RUNTIME_DIR"
  check_path "skills dir" "$SC_SKILLS_DIR"
  check_path "releases dir" "$SC_RELEASES_DIR"
  check_path "config dir" "$SC_CONFIG_DIR"
  check_path "state dir" "$SC_STATE_DIR"
  check_path "runtime state dir" "$SC_RUNTIME_STATE_DIR"
  check_path "library dir" "$SC_LIBRARY_DIR"
  check_path "library intake dir" "$SC_LIBRARY_INTAKE_DIR"
  check_path "log dir" "$SC_LOG_DIR"
  check_path "runtime log dir" "$SC_RUNTIME_LOG_DIR"
  check_path "bootstrap state" "$(pi_kit_state_path)"
  check_library_snapshot

  check_backend_commands
  check_gstreamer_backend

  if is_live_root; then
    check_command aplay
  else
    info "skipping host audio command check for SC_ROOT=${SC_ROOT}"
  fi

  check_audio_device
  check_exclusive_profile
  check_runtime_service_contract

  if [[ "$FAILURES" -gt 0 ]]; then
    printf 'result: FAIL (%s failure(s), %s warning(s))\n' "$FAILURES" "$WARNINGS" >&2
    exit 1
  fi

  printf 'result: PASS (%s warning(s))\n' "$WARNINGS"
}

main "$@"
