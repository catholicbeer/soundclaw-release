#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# shellcheck source=../lib/pi-kit.sh
source "${SCRIPT_DIR}/../lib/pi-kit.sh"

SOURCE_DIR=""
RELEASE_REF=""

usage() {
  cat <<'EOF'
Usage: deploy-runtime.sh --source /path/to/soundclaw-runtime [--release-ref value] [--dry-run]

Copy a staged runtime directory into the host's runtime/current directory so
the Pi has the bits needed for explicit service-managed runtime operation. The
source must include the public wrappers plus the staged Rust daemon and control
CLI under libexec/.
EOF
}

validate_runtime_source() {
  local required_path
  local -a required_paths=(
    "bin/soundclaw-runtime"
    "bin/soundclawctl"
    "lib/runtime-common.sh"
    "libexec/soundclaw-runtime-daemon"
    "libexec/soundclawctl-rust"
  )

  [[ -n "$SOURCE_DIR" ]] || die "--source is required"
  [[ -d "$SOURCE_DIR" ]] || die "runtime source directory does not exist: $SOURCE_DIR"

  for required_path in "${required_paths[@]}"; do
    [[ -e "${SOURCE_DIR%/}/${required_path}" ]] || die \
      "runtime source must include ${required_path}: ${SOURCE_DIR}"
  done
}

restart_runtime_service_if_ready() {
  local runtime_config
  local unit_file

  if ! is_live_root; then
    return 0
  fi

  runtime_config="$(root_path "${SC_CONFIG_DIR}/runtime.toml")"
  unit_file="$(root_path "$(runtime_service_unit_path)")"

  if [[ ! -f "$unit_file" ]]; then
    info "runtime service unit is not installed yet; skipping service restart"
    return 0
  fi

  if [[ ! -f "$runtime_config" ]]; then
    info "runtime deploy completed; skipping service restart because ${SC_CONFIG_DIR}/runtime.toml is missing"
    return 0
  fi

  require_live_systemd
  info "restarting ${SC_RUNTIME_SERVICE_UNIT_NAME}"
  run_cmd systemctl restart "$SC_RUNTIME_SERVICE_UNIT_NAME"
}

write_runtime_state() {
  local state_file
  local deployed_at

  state_file="$(root_path "$(runtime_deploy_state_path)")"
  deployed_at="$(timestamp_utc)"

  write_text_file "$state_file" <<EOF
RUNTIME_SOURCE=${SOURCE_DIR@Q}
RUNTIME_RELEASE_REF=${RELEASE_REF@Q}
RUNTIME_DEPLOYED_AT=${deployed_at@Q}
EOF
}

normalize_runtime_tree_permissions() {
  local runtime_target

  runtime_target="$(root_path "$(runtime_current_dir)")"

  info "normalizing deployed runtime permissions under ${runtime_target}"

  if is_live_root; then
    run_cmd chown -R root:root "$runtime_target"
  fi

  run_cmd chmod -R u=rwX,go=rX "$runtime_target"
}

main() {
  while [[ $# -gt 0 ]]; do
    case "$1" in
      --source)
        [[ $# -ge 2 ]] || die "--source requires a value"
        SOURCE_DIR="$2"
        shift 2
        ;;
      --release-ref)
        [[ $# -ge 2 ]] || die "--release-ref requires a value"
        RELEASE_REF="$2"
        shift 2
        ;;
      --dry-run)
        DRY_RUN=1
        shift
        ;;
      --help|-h)
        usage
        exit 0
        ;;
      *)
        die "unknown argument: $1"
        ;;
    esac
  done

  validate_runtime_source

  if [[ -z "$RELEASE_REF" ]]; then
    RELEASE_REF="$(basename "$SOURCE_DIR")"
  fi

  require_root

  ensure_dir "$SC_RUNTIME_DIR"
  ensure_dir "$SC_STATE_DIR"

  info "deploying runtime from ${SOURCE_DIR} to $(root_path "${SC_RUNTIME_DIR}/current")"
  run_cmd mkdir -p "$(root_path "${SC_RUNTIME_DIR}/current")"
  run_cmd rsync -a --delete "${SOURCE_DIR}/" "$(root_path "${SC_RUNTIME_DIR}/current/")"
  normalize_runtime_tree_permissions

  write_runtime_state
  restart_runtime_service_if_ready

  info "runtime deploy complete"
}

main "$@"
