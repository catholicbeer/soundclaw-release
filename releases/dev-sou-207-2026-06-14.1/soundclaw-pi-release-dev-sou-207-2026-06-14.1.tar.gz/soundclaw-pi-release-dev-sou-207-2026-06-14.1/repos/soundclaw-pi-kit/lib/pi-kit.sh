#!/usr/bin/env bash

# Shared helpers for soundclaw-pi-kit scripts.

if [[ -n "${SOUNDCLAW_PI_KIT_LIB_LOADED:-}" ]]; then
  return 0
fi
SOUNDCLAW_PI_KIT_LIB_LOADED=1

PI_KIT_REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

DRY_RUN="${DRY_RUN:-0}"
SC_ROOT="${SC_ROOT:-/}"
SC_BASE_DIR="${SC_BASE_DIR:-/opt/soundclaw}"
SC_RUNTIME_DIR="${SC_RUNTIME_DIR:-${SC_BASE_DIR}/runtime}"
SC_SKILLS_DIR="${SC_SKILLS_DIR:-${SC_BASE_DIR}/skills}"
SC_RELEASES_DIR="${SC_RELEASES_DIR:-${SC_BASE_DIR}/releases}"
SC_CONFIG_DIR="${SC_CONFIG_DIR:-/etc/soundclaw}"
SC_STATE_DIR="${SC_STATE_DIR:-/var/lib/soundclaw}"
SC_RUNTIME_STATE_DIR="${SC_RUNTIME_STATE_DIR:-${SC_STATE_DIR}/runtime}"
SC_LIBRARY_DIR="${SC_LIBRARY_DIR:-${SC_STATE_DIR}/library}"
SC_LIBRARY_INTAKE_DIR="${SC_LIBRARY_INTAKE_DIR:-${SC_STATE_DIR}/library-intake}"
SC_LOG_DIR="${SC_LOG_DIR:-/var/log/soundclaw}"
SC_RUNTIME_LOG_DIR="${SC_RUNTIME_LOG_DIR:-${SC_LOG_DIR}/runtime}"
SC_SYSTEMD_UNIT_DIR="${SC_SYSTEMD_UNIT_DIR:-/etc/systemd/system}"
SC_RUNTIME_SERVICE_USER="${SC_RUNTIME_SERVICE_USER:-soundclaw-runtime}"
SC_RUNTIME_ACCESS_GROUP="${SC_RUNTIME_ACCESS_GROUP:-soundclaw}"
SC_RUNTIME_SERVICE_UNIT_NAME="${SC_RUNTIME_SERVICE_UNIT_NAME:-soundclaw-runtime.service}"
SC_OPERATOR_USER="${SC_OPERATOR_USER:-${SUDO_USER:-}}"

readonly PI_KIT_VERSION="0.1.0"
readonly DEFAULT_PROFILE="shared"
readonly BASE_PACKAGES=(
  alsa-utils
  ca-certificates
  curl
  git
  rsync
)
readonly RUNTIME_BACKEND_PACKAGES=(
  gstreamer1.0-alsa
  gstreamer1.0-plugins-base
  gstreamer1.0-plugins-good
  gstreamer1.0-tools
)
readonly PURGEABLE_PACKAGES=(
  alsa-utils
  "${RUNTIME_BACKEND_PACKAGES[@]}"
)
readonly HOST_PACKAGES=(
  "${BASE_PACKAGES[@]}"
  "${RUNTIME_BACKEND_PACKAGES[@]}"
)
readonly REQUIRED_COMMANDS=(
  bash
  curl
  git
  rsync
  gst-inspect-1.0
  gst-launch-1.0
)
readonly REQUIRED_GSTREAMER_ELEMENTS=(
  filesrc
  decodebin
  audioconvert
  audioresample
  volume
  alsasink
  flacparse
  flacdec
  wavparse
  mpegaudioparse
  mpg123audiodec
)

info() {
  printf 'info: %s\n' "$*"
}

warn() {
  printf 'warn: %s\n' "$*" >&2
}

die() {
  printf 'error: %s\n' "$*" >&2
  exit 1
}

repo_root() {
  printf '%s\n' "$PI_KIT_REPO_ROOT"
}

is_live_root() {
  [[ "$SC_ROOT" == "/" ]]
}

command_exists() {
  command -v "$1" >/dev/null 2>&1
}

root_path() {
  local path="$1"

  [[ "$path" == /* ]] || die "expected an absolute path, got: $path"

  if is_live_root; then
    printf '%s\n' "$path"
    return 0
  fi

  printf '%s%s\n' "${SC_ROOT%/}" "$path"
}

quote_cmd() {
  local arg

  for arg in "$@"; do
    printf '%q ' "$arg"
  done

  printf '\n'
}

run_cmd() {
  if [[ "$DRY_RUN" == "1" ]]; then
    info "[dry-run] $(quote_cmd "$@")"
    return 0
  fi

  "$@"
}

require_root() {
  if is_live_root && [[ "${EUID:-$(id -u)}" -ne 0 ]]; then
    die "run this script with sudo, or set SC_ROOT to a writable test root"
  fi
}

ensure_dir() {
  local dir_path
  dir_path="$(root_path "$1")"
  run_cmd mkdir -p "$dir_path"
}

ensure_dir_mode() {
  local dir_path
  dir_path="$(root_path "$1")"
  run_cmd mkdir -p "$dir_path"
  run_cmd chmod "$2" "$dir_path"
}

ensure_owned_dir() {
  local dir_path
  dir_path="$(root_path "$1")"
  run_cmd mkdir -p "$dir_path"

  if is_live_root; then
    run_cmd chown "$2:$3" "$dir_path"
  fi

  run_cmd chmod "$4" "$dir_path"
}

ensure_library_dir_access() {
  ensure_dir_mode "$SC_STATE_DIR" 0755
  ensure_dir_mode "$SC_LIBRARY_DIR" 0755
}

normalize_library_permissions() {
  local library_dir

  library_dir="$(root_path "$SC_LIBRARY_DIR")"

  [[ -d "$library_dir" ]] || return 0

  run_cmd find "$library_dir" -type d -exec chmod 0755 {} +
  run_cmd find "$library_dir" -type f -exec chmod 0644 {} +
}

runtime_current_dir() {
  printf '%s\n' "${SC_RUNTIME_DIR%/}/current"
}

runtime_control_socket_path() {
  printf '%s\n' "${SC_RUNTIME_STATE_DIR%/}/runtime.sock"
}

runtime_config_path() {
  printf '%s\n' "${SC_CONFIG_DIR%/}/runtime.toml"
}

runtime_service_unit_path() {
  printf '%s\n' "${SC_SYSTEMD_UNIT_DIR%/}/${SC_RUNTIME_SERVICE_UNIT_NAME}"
}

runtime_service_template_path() {
  printf '%s\n' "${PI_KIT_REPO_ROOT}/systemd/soundclaw-runtime.service.in"
}

ensure_runtime_config_dir_access() {
  if is_live_root; then
    ensure_owned_dir "$SC_CONFIG_DIR" \
      "$SC_RUNTIME_SERVICE_USER" "$SC_RUNTIME_ACCESS_GROUP" 0750
    return 0
  fi

  ensure_dir_mode "$SC_CONFIG_DIR" 0750
}

normalize_runtime_config_permissions() {
  local runtime_config

  runtime_config="$(root_path "$(runtime_config_path)")"

  [[ -e "$runtime_config" ]] || return 0

  if is_live_root; then
    run_cmd chown "$SC_RUNTIME_SERVICE_USER:$SC_RUNTIME_ACCESS_GROUP" "$runtime_config"
  fi

  run_cmd chmod 0640 "$runtime_config"
}

render_runtime_service_unit() {
  sed \
    -e "s|@SC_RUNTIME_DIR@|${SC_RUNTIME_DIR}|g" \
    -e "s|@SC_CONFIG_DIR@|${SC_CONFIG_DIR}|g" \
    -e "s|@SC_STATE_DIR@|${SC_STATE_DIR}|g" \
    -e "s|@SC_LOG_DIR@|${SC_LOG_DIR}|g" \
    -e "s|@SC_RUNTIME_SERVICE_USER@|${SC_RUNTIME_SERVICE_USER}|g" \
    -e "s|@SC_RUNTIME_ACCESS_GROUP@|${SC_RUNTIME_ACCESS_GROUP}|g" \
    "$(runtime_service_template_path)"
}

group_exists() {
  getent group "$1" >/dev/null 2>&1
}

user_exists() {
  getent passwd "$1" >/dev/null 2>&1
}

user_in_group() {
  id -nG "$1" 2>/dev/null | tr ' ' '\n' | grep -Fx "$2" >/dev/null 2>&1
}

ensure_system_group() {
  local group_name="$1"

  group_exists "$group_name" && return 0
  run_cmd groupadd --system "$group_name"
}

ensure_system_user() {
  local user_name="$1"
  local primary_group="$2"

  user_exists "$user_name" && return 0

  run_cmd useradd \
    --system \
    --gid "$primary_group" \
    --home-dir /nonexistent \
    --shell /usr/sbin/nologin \
    --comment "SoundClaw runtime service user" \
    "$user_name"
}

ensure_user_in_group() {
  local user_name="$1"
  local group_name="$2"

  user_in_group "$user_name" "$group_name" && return 0
  run_cmd usermod -a -G "$group_name" "$user_name"
}

systemd_ready() {
  command_exists systemctl && [[ -d /run/systemd/system ]]
}

require_live_systemd() {
  if ! systemd_ready; then
    die "systemd is required on live hosts for soundclaw-runtime service wiring"
  fi
}

library_index_path() {
  printf '%s\n' "${SC_LIBRARY_DIR%/}/index.json"
}

library_assets_dir() {
  printf '%s\n' "${SC_LIBRARY_DIR%/}/assets"
}

pi_kit_env_path() {
  printf '%s\n' "${SC_CONFIG_DIR%/}/pi-kit.env"
}

pi_kit_state_path() {
  printf '%s\n' "${SC_STATE_DIR%/}/pi-kit-installed"
}

runtime_deploy_state_path() {
  printf '%s\n' "${SC_STATE_DIR%/}/runtime-deploy.env"
}

library_deploy_state_path() {
  printf '%s\n' "${SC_STATE_DIR%/}/library-deploy.env"
}

setup_run_state_path() {
  printf '%s\n' "${SC_STATE_DIR%/}/setup-run.env"
}

timestamp_utc() {
  date -u +"%Y-%m-%dT%H:%M:%SZ"
}

load_profile() {
  local profile="${1:-$DEFAULT_PROFILE}"
  local profile_file="${PI_KIT_REPO_ROOT}/config/profiles/${profile}.env"

  [[ -f "$profile_file" ]] || die "unknown profile: $profile"

  PROFILE="$profile"

  # shellcheck disable=SC1090
  source "$profile_file"
}

load_installed_layout() {
  local config_file

  config_file="$(root_path "$(pi_kit_env_path)")"

  [[ -f "$config_file" ]] || return 1

  # shellcheck disable=SC1090
  source "$config_file"

  SC_BASE_DIR="${INSTALLED_SC_BASE_DIR:-$SC_BASE_DIR}"
  SC_RUNTIME_DIR="${INSTALLED_SC_RUNTIME_DIR:-$SC_RUNTIME_DIR}"
  SC_SKILLS_DIR="${INSTALLED_SC_SKILLS_DIR:-$SC_SKILLS_DIR}"
  SC_RELEASES_DIR="${INSTALLED_SC_RELEASES_DIR:-$SC_RELEASES_DIR}"
  SC_CONFIG_DIR="${INSTALLED_SC_CONFIG_DIR:-$SC_CONFIG_DIR}"
  SC_STATE_DIR="${INSTALLED_SC_STATE_DIR:-$SC_STATE_DIR}"
  SC_RUNTIME_STATE_DIR="${INSTALLED_SC_RUNTIME_STATE_DIR:-$SC_RUNTIME_STATE_DIR}"
  SC_LIBRARY_DIR="${INSTALLED_SC_LIBRARY_DIR:-$SC_LIBRARY_DIR}"
  SC_LIBRARY_INTAKE_DIR="${INSTALLED_SC_LIBRARY_INTAKE_DIR:-$SC_LIBRARY_INTAKE_DIR}"
  SC_LOG_DIR="${INSTALLED_SC_LOG_DIR:-$SC_LOG_DIR}"
  SC_RUNTIME_LOG_DIR="${INSTALLED_SC_RUNTIME_LOG_DIR:-$SC_RUNTIME_LOG_DIR}"
  SC_SYSTEMD_UNIT_DIR="${INSTALLED_SC_SYSTEMD_UNIT_DIR:-$SC_SYSTEMD_UNIT_DIR}"
  SC_RUNTIME_SERVICE_UNIT_NAME="${INSTALLED_SC_RUNTIME_SERVICE_UNIT_NAME:-$SC_RUNTIME_SERVICE_UNIT_NAME}"
  SC_RUNTIME_SERVICE_USER="${INSTALLED_SC_RUNTIME_SERVICE_USER:-$SC_RUNTIME_SERVICE_USER}"
  SC_RUNTIME_ACCESS_GROUP="${INSTALLED_SC_RUNTIME_ACCESS_GROUP:-$SC_RUNTIME_ACCESS_GROUP}"
  SC_OPERATOR_USER="${INSTALLED_SC_RUNTIME_OPERATOR_USER:-$SC_OPERATOR_USER}"

  return 0
}

remove_managed_path() {
  local path="$1"
  local target

  [[ "$path" == /* ]] || die "expected an absolute managed path, got: $path"

  case "$path" in
    /|/etc|/opt|/var|/var/lib|/var/log)
      die "refusing to remove overly broad managed path: $path"
      ;;
  esac

  target="$(root_path "$path")"

  if [[ ! -e "$target" ]] && [[ ! -L "$target" ]]; then
    info "path already absent: ${target}"
    return 0
  fi

  run_cmd rm -rf "$target"
}

write_text_file() {
  local target="$1"

  if [[ "$DRY_RUN" == "1" ]]; then
    info "[dry-run] write ${target}"
    cat >/dev/null
    return 0
  fi

  mkdir -p "$(dirname "$target")"
  cat >"$target"
}
