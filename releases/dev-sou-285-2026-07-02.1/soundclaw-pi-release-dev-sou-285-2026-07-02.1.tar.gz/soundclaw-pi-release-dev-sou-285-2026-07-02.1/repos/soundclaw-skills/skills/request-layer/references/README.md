# Request Layer

Purpose: Request or stop one on-demand SoundClaw `Layer` through the promoted
runtime-owned Familiar CLI boundary.

Runtime dependency:

- `soundclawctl familiar run-layer --scene <id> --layer <id> --asset <id> --output <id> [--fade-in-ms <ms>] [--json]`
- `soundclawctl familiar stop-layer --scene <id> --layer <id> --output <id> [--fade-out-ms <ms>] [--json]`
- `soundclawctl outputs list [--json]`
- `soundclawctl outputs show --output <id> [--json]`
- `soundclawctl config defaults [--json]`
- `soundclawctl library list [--json]`
- `soundclawctl library show --asset <id> [--json]`

## Operator Job

This skill handles operator requests to start or stop one on-demand `Layer`.
It maps operator intent to the runtime's one-Layer Familiar command and relays
the runtime-owned accepted, running, interrupted, blocked, or failed outcome.

The skill may help resolve asset ids, logical outputs, and runtime defaults
through promoted discovery commands. It must not build a multi-Layer `Scene`,
store execution state, bypass policy checks, or create a skills-owned execution
loop.

## Guardrails

- Use only the promoted `soundclawctl familiar run-layer` and
  `soundclawctl familiar stop-layer` commands for Layer mutation.
- Ask a clarification question when the scene id, layer id, asset id, or
  logical output is missing or ambiguous.
- Treat runtime JSON as authoritative for policy blocks, duplicate-safe
  running outcomes, interruptions, failures, and completion details.
- If the installed runtime does not expose `familiar run-layer` or
  `familiar stop-layer`, say the deployed runtime line lacks the promoted
  Phase 2 one-Layer surface.
- Do not store Familiar state, replay Timeline events, calculate cooldowns, or
  synthesize raw channel routes locally.
