# Compatibility

Operator job: Request or stop one on-demand SoundClaw `Layer`.

Runtime dependency:

- Status: Pending current runtime release-line declaration for these promoted
  Phase 2 command shapes.
- Contract reference: `soundclaw/docs/runtime-spec.md`
- Runtime implementation reference: `SOU-218` and `SOU-240` landed
  `soundclaw-runtime` `main` with the promoted one-Layer Familiar surface and
  source-preserving ingest support needed by the Phase 2 operator path.
- Command(s): `soundclawctl familiar run-layer --scene <id> --layer <id> --asset <id> --output <id> [--fade-in-ms <ms>] [--json]`
- Command(s): `soundclawctl familiar stop-layer --scene <id> --layer <id> --output <id> [--fade-out-ms <ms>] [--json]`
- Command(s): `soundclawctl outputs list [--json]`
- Command(s): `soundclawctl outputs show --output <id> [--json]`
- Command(s): `soundclawctl config defaults [--json]`
- Command(s): `soundclawctl library list [--json]`
- Command(s): `soundclawctl library show --asset <id> [--json]`
- Scope note: Runtime owns Familiar state, one-Layer reconciliation,
  policy/recovery checks, playback projection, Timeline records, and duplicate
  handling. This skill may explain or invoke those outcomes only through the
  promoted CLI surface.

Minimum compatible runtime release line: Pending definition in `soundclaw-runtime`.

Tested runtime release line: Not yet validated against a promoted runtime release line.

Packaging target: Plain skill

ClawHub publication status: Not published
