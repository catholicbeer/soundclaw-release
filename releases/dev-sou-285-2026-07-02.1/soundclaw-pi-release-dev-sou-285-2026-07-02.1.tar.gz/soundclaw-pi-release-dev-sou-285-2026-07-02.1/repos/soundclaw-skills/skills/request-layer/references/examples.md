# Request Layer Examples

## Example Requests

- "Run layer `bells-intro` in scene `manual-demo` using asset `bells-angelus` on `wide`."
- "Start a one-layer scene for `rain-soft` on the default output."
- "Stop layer `bells-intro` in scene `manual-demo` on `wide`."
- "Fade out that one-layer request over 500 ms."

## Expected Skill Behavior

- Resolve one scene id, one layer id, one asset id, and one logical output
  before mutation.
- Use `soundclawctl config defaults [--json]` when the operator omitted the
  output and the runtime exposes one clear default.
- Use `soundclawctl familiar run-layer --scene <id> --layer <id> --asset <id> --output <id> [--fade-in-ms <ms>] [--json]`
  for the start request.
- Use `soundclawctl familiar stop-layer --scene <id> --layer <id> --output <id> [--fade-out-ms <ms>] [--json]`
  for the stop request.
- Relay accepted, running, interrupted, blocked, and failed outcomes from the
  runtime result without adding a skills-owned execution loop.
- Explain policy blocks, missing capability, runtime failure, and interruption
  using the runtime-owned reason and detail fields when present.
