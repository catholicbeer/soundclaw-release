---
name: play-asset
description: Play a named SoundClaw asset on a logical output through the documented runtime CLI.
---

# Play Asset

Use this skill when the operator wants to start playback for a specific SoundClaw asset on a logical output.

## Behavior

- Before running any `soundclawctl` command, resolve the executable. Prefer
  `soundclawctl` when it is visible on `PATH`; otherwise use
  `/opt/soundclaw/runtime/current/bin/soundclawctl`.
- Resolve the requested asset and logical output.
- If the operator did not specify an output, consult `soundclawctl config defaults [--json]` for a runtime-owned default before asking a clarification question.
- If you need to show or inspect available outputs, use `soundclawctl outputs list [--json]` or `soundclawctl outputs show --output <id> [--json]`.
- If either reference is ambiguous, ask a short clarification question before acting.
- Treat the selected logical output's ordered destination-channel layout and runtime-owned route plan as authoritative rather than inventing channel remaps locally.
- Use `soundclawctl outputs show --output <id> [--json]` when you need to explain an output's declared layout or inspect output details, but do not depend on that preflight for correctness because the runtime owns the final route plan.
- Collect an optional fade-in duration only when the operator requested one or when the workflow already includes it.
- Map the final request to `soundclawctl playback play --asset <id> --output <id> [--fade-in-ms <n>] [--json]`.
- Confirm success in operator language, using the asset id or name and logical output.
- If the runtime reports a shape mismatch or output-selection failure, surface that failure clearly in the operator-facing response.
- If the runtime reports an error, explain that it is a runtime failure and point to the next useful operator step.

## Out Of Scope

- Host repair
- Service restarts
- Raw channel routing
- Skill-layer route synthesis or output-shape overrides
- Semantic speaker-role inference such as automatic ambient-bed or spot-effect placement
- Hidden retries that could trigger duplicate playback

## Local References

- Read `{baseDir}/references/README.md` for the operator job, guardrails, and intent boundary.
- Read `{baseDir}/references/examples.md` for example requests and expected behavior.
- Read `{baseDir}/references/compatibility.md` for runtime dependency and packaging notes.
