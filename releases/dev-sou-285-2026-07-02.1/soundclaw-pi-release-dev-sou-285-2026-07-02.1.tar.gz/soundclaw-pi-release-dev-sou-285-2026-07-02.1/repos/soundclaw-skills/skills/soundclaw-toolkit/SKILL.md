---
name: soundclaw-toolkit
description: Discover supported SoundClaw capabilities and route an operator request to the narrow owning workflow.
---

# SoundClaw Toolkit

Use this skill when the operator asks broadly what SoundClaw can do, does not
know which SoundClaw skill owns a task, or wants a guided route into one of the
supported workflows.

## Behavior

- Classify the request into one owning workflow before taking action.
- If the request is already specific, route directly without running a broad
  status sweep.
- If backend readiness is unknown and matters to the request, use
  `soundclawctl runtime status --json` or route to `soundclaw-onboarding`.
- Use only the smallest promoted read needed to disambiguate a target:
  `library list`, `outputs list`, `zones list`, `scene show`, `policy status`,
  or `deployment status`.
- Route asset lookup to `browse-assets` or `show-asset`; direct playback to
  `play-asset`; one-Layer intent to `request-layer`; bounded multi-Layer intent
  to `request-scene`; and policy requests to `manual-policy`.
- Route output or zone reads to `show-outputs` and deliberate topology changes
  to `manage-output`. Do not translate vague place or speaker language into a
  route plan.
- Route library ingestion to `ingest-library`. Do not treat browse, rename,
  deletion, metadata editing, or arbitrary filesystem access as equivalent to
  the promoted source-preserving ingest workflow.
- Route explicit feedback lifecycle requests to `manage-feedback` only when
  its private capability is present. Otherwise give honest unavailable
  guidance without recording feedback publicly.
- State which workflow owns the request, any capability dependency, and the
  next safe action in a compact response.
- If an owning skill or promoted runtime command is unavailable, stop and name
  the missing capability instead of emulating it.

## Out Of Scope

- Calling private Web UI HTTP routes, DOM, snapshots, or runtime IPC
- Parsing runtime configuration, library indexes, or host files
- Host installation, repair, service control, or hidden reloads
- Skill-owned Scene, policy, topology, library, or Timeline state
- Storing conversation memory, feedback records, credentials, or private paths

## Local References

- Read `{baseDir}/references/README.md` for the operator job, guardrails, and intent boundary.
- Read `{baseDir}/references/examples.md` for example requests and expected behavior.
- Read `{baseDir}/references/compatibility.md` for runtime dependency and packaging notes.
