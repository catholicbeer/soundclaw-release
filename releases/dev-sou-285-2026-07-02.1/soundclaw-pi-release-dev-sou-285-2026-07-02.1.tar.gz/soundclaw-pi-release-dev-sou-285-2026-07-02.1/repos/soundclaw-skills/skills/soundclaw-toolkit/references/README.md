# SoundClaw Toolkit

Purpose: Give OpenClaw one discoverable entrypoint for understanding what
SoundClaw can do and routing an operator to the narrow owning skill.

## Operator Job

Use this skill for broad requests such as "what can SoundClaw do?", "help me
make a Scene", or "where do I manage speakers?" It performs only the smallest
read-only discovery needed to choose an installed workflow, then hands the job
to that workflow.

## Routing Catalog

- readiness and first use: `soundclaw-onboarding`
- deployment identity and updates: `soundclaw-version`
- health and diagnostics: `runtime-health`
- asset discovery: `browse-assets` or `show-asset`
- direct playback and stop: `play-asset` or `stop-playback`
- one bounded Layer: `request-layer`
- one bounded multi-Layer Scene: `request-scene`
- manual hold, clear, or resume: `manual-policy`
- global volume: `set-volume`
- output and zone inspection: `show-outputs`
- output and zone administration: `manage-output`
- source-preserving ingest: `ingest-library`
- explicit private feedback lifecycle: `manage-feedback` when the private
  capability is available
- config validation: `validate-config`

## Guardrails

- Prefer an installed owning skill over reproducing its prompt locally.
- Use promoted `soundclawctl` reads only when capability or target discovery is
  needed.
- Never call private operator-console routes or inspect rendered Web UI state.
- Never parse runtime config or library files.
- Never install, repair, reload, or mutate as part of capability discovery.
- State clearly when an owning skill or runtime capability is unavailable.
- Keep private feedback, conversation memory, credentials, paths, and operator
  identity out of public retained output and Scene requests.
