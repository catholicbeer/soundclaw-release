# SoundClaw Toolkit Examples

## Broad discovery

Operator: "What can SoundClaw do here?"

Expected behavior: Check readiness only if needed, summarize the installed
workflow categories, and offer the narrow next workflow without running every
read command.

## Scene intent

Operator: "Make the garden feel calm this evening."

Expected behavior: Route to `request-scene`, which resolves assets and outputs,
asks only for missing consequential details, previews the proposed Scene, and
submits one self-contained Scene version 1 request after required confirmation.

## Topology administration

Operator: "Add an output for the path speakers."

Expected behavior: Route to `manage-output`; do not guess zone ownership,
channel routes, or source shape from the place name.

## Unsupported library mutation

Operator: "Rename and delete some library files."

Expected behavior: Explain that Phase 4a supports indexed browsing and the
explicit source-preserving ingest workflow, not general library authoring.
