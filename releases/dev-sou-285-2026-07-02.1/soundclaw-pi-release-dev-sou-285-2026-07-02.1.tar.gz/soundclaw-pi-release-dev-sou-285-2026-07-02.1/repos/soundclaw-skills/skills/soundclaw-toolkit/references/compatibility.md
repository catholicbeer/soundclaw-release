# Compatibility

Operator job: Discover supported SoundClaw capabilities and route requests to
the installed owning workflow.

Runtime dependency:

- Status: Compatibility-supported against the Phase 3 stable command surface.
- Contract reference: `soundclaw/docs/development-plan-phase4.md`
- Read commands: runtime and deployment status, library/output/zone discovery,
  active Scene inspection, and policy status.
- The skill does not require private Web UI routes or runtime-internal IPC.

Minimum compatible runtime release line: Phase 3 stable.

Tested runtime release line: Phase 3 stable.

Packaging target: Plain skill

ClawHub publication status: Not published
