# Compatibility

Operator job: Add, update, remove, and deliberately reload one low-risk
logical output workflow.

Runtime dependency:

- Status: Pending current runtime release-line declaration and deployed host-contract support for this low-risk admin surface.
- Contract reference: `soundclaw/docs/runtime-spec.md`
- Runtime implementation reference: `SOU-147` landed `soundclaw-runtime` `main` at `194cbeb7d951d3da949aadc5efcd6f6a7304c1dd` with the promoted `soundclawctl zones` surface.
- Command(s): `soundclawctl zones list [--json]`
- Command(s): `soundclawctl zones show --zone <id> [--json]`
- Command(s): `soundclawctl zones add --zone <id> --device <id> --owned-dest-channel <n>... [--json]`
- Command(s): `soundclawctl zones update --zone <id> --device <id> --owned-dest-channel <n>... [--json]`
- Command(s): `soundclawctl zones remove --zone <id> [--json]`
- Command(s): `soundclawctl outputs list [--json]`
- Command(s): `soundclawctl outputs show --output <id> [--json]`
- Command(s): `soundclawctl outputs add --output <id> --zone <id> --source-channels <n> --route <source:dest[:gain_percent]>... [--json]`
- Command(s): `soundclawctl outputs update --output <id> --zone <id> --source-channels <n> --route <source:dest[:gain_percent]>... [--json]`
- Command(s): `soundclawctl outputs remove --output <id> [--json]`
- Command(s): `soundclawctl runtime reload [--json]`
- JSON fields used for zone discovery: `owned_dest_channels`, `zone_required_output_channels`, `zone_current_backend_supported_output_channels`, `current_backend_supported`, and `current_backend_detail`.
- Scope note: This skill wraps one bounded logical-output admin workflow plus the zone-owned channel inspection or deliberate zone topology step needed to make that output valid. It must stay on the promoted CLI boundary and must not edit `runtime.toml` or perform service management directly.
- Reload note: `zones add`, `zones update`, and `zones remove` are config-backed admin commands; a running daemon observes topology changes only after `soundclawctl runtime reload [--json]`.

Minimum compatible runtime release line: Pending definition in
`soundclaw-runtime`.

Tested runtime release line: Not yet validated against a promoted runtime
release line.

Packaging target: Plain skill

ClawHub publication status: Not published
