# Manage Output

Purpose: Add, update, remove, and deliberately reload one low-risk logical
output through the documented runtime CLI.

Runtime dependency:

- when needed to resolve or inspect existing outputs, `soundclawctl outputs list [--json]`
- when needed to inspect one existing output before update or removal, `soundclawctl outputs show --output <id> [--json]`
- when needed to inspect zone-owned destination channels, `soundclawctl zones list [--json]`
- when needed to inspect one zone, `soundclawctl zones show --zone <id> [--json]`
- when the runtime line declares zone management support, `soundclawctl zones add --zone <id> --device <id> --owned-dest-channel <n>... [--json]`
- when the runtime line declares zone management support, `soundclawctl zones update --zone <id> --device <id> --owned-dest-channel <n>... [--json]`
- when the runtime line declares zone management support, `soundclawctl zones remove --zone <id> [--json]`
- `soundclawctl outputs add --output <id> --zone <id> --source-channels <n> --route <source:dest[:gain_percent]>... [--json]`
- `soundclawctl outputs update --output <id> --zone <id> --source-channels <n> --route <source:dest[:gain_percent]>... [--json]`
- `soundclawctl outputs remove --output <id> [--json]`
- after a topology-changing edit, `soundclawctl runtime reload [--json]`

## Operator Job

This skill handles the bounded admin workflow for adding one logical output,
changing one existing output's zone or route declaration, removing one output,
inspecting or adjusting the zone-owned destination-channel shape needed by that
output, or deliberately reloading the running runtime topology after that
low-risk change.

It should keep the workflow on the runtime-owned CLI boundary, help the
operator confirm the intended output id and route details, and make the reload
step explicit rather than pretending config edits become live automatically.

## Guardrails

- Use runtime discovery commands when the operator needs to confirm existing output ids or current route details.
- Gather or confirm the output id, zone id, source-channel count, and route plan before mutating. Ask a short clarification question if any required piece is missing or ambiguous.
- Treat existing output routes as examples of declared layouts, not as the complete destination-channel capability of the zone.
- Use `zones list` or `zones show` to explain which destination channels a zone owns; do not infer zone capability from output routes.
- Pass explicit operator-requested routes through to `soundclawctl outputs add` or `soundclawctl outputs update` and let runtime-owned validation accept or reject them, including optional per-route gain values in `--route <source:dest[:gain_percent]>`.
- Before any `zones add`, `zones update`, or `zones remove`, ask for concise operator confirmation that names the target zone id, the device id when required, and the full owned destination-channel list for add or update.
- Treat zone mutations as deliberate admin topology work. They are not normal playback, and they still require `soundclawctl runtime reload [--json]` before a running daemon observes the new topology.
- Preserve runtime-owned validation errors for zone ownership, unsupported destination channels, duplicate zone ids, and attempts to remove zones still used by outputs.
- For update requests, treat the runtime's current output declaration as discoverable context, not permission to guess new values the operator did not confirm.
- Treat route validation, duplicate-id checks, zone-ownership checks, and reload semantics as runtime-owned.
- Make it explicit when the current runtime line or deployed host contract does not yet support normal low-risk output or zone admin.
- Do not edit `runtime.toml` directly, touch sockets directly, or perform service-control or host-repair steps.
- Do not invent bulk topology editing, unpromoted zone behavior, or hidden retries.
- Do not reject a requested route merely because another output in the selected zone uses a sparse layout such as `1`, `4`, `7`, and `8`.
