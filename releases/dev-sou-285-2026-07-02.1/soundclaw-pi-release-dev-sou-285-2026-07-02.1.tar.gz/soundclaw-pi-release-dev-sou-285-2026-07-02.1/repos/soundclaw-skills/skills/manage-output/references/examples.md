# Manage Output Examples

## Example Requests

- "Add a `foyer` stereo output in zone `nave` with routes `1:9` and `2:10`."
- "Update output `foyer` to use routes `1:11` and `2:12`, then reload."
- "Update output `foyer` to use route gains `1:11:85` and `2:12:85`, then reload."
- "Add a `side-aisle` output in zone `Sanctuary` with routes `1:2` and `2:3`, even though existing output `nave` uses `1`, `4`, `7`, and `8`."
- "Why can't I add an all-speakers output on the default zone? Show me which channels the zone owns."
- "Create a `full-house` zone on device `main` that owns destination channels `1` through `8`, then add a stereo output in that zone and reload."
- "Update zone `nave` so it owns channels `1` through `8`, then retry the output add."
- "Remove zone `overflow` if the runtime says no outputs still depend on it."
- "Remove output `garden-pad` and reload the runtime."
- "Show me the current route for `foyer` before I change it."

## Expected Skill Behavior

- Use runtime discovery commands when existing output details need confirmation.
- Keep the workflow on the documented `soundclawctl` boundary.
- Ask for missing zone, source-channel, or route information instead of guessing.
- Use `soundclawctl zones list [--json]` or `soundclawctl zones show --zone <id> [--json]` to explain zone-owned destination channels.
- Treat existing output routes as examples, not as a zone-level destination-channel allow-list.
- Pass explicitly requested route entries through to `soundclawctl outputs add` or `soundclawctl outputs update` for runtime-owned validation.
- Preserve optional route gain values when the operator uses `--route <source:dest[:gain_percent]>`.
- If the requested output needs destination channels outside the selected/default zone, guide the operator to `soundclawctl zones add` or `soundclawctl zones update` when the runtime line supports it.
- Before mutating a zone, confirm the target zone id, device id when required, and complete owned destination-channel list.
- Preserve runtime validation failures for invalid zone ownership or attempts to remove zones still used by outputs.
- Treat reload as the deliberate follow-up step after a successful topology-changing edit.
- Explain clearly when the runtime or host contract does not yet support the requested low-risk admin path.
