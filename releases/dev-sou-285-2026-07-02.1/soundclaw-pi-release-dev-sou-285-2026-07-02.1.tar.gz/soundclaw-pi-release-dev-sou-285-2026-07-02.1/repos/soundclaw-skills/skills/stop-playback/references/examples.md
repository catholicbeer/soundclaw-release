# Stop Playback Examples

## Example Requests

- "Stop `main`."
- "Fade out `perimeter-wide-4` over 3 seconds."
- "Stop `all-speakers-10`."

## Expected Skill Behavior

- Resolve the target output before acting.
- Keep fade-out behavior explicit.
- Confirm which logical output was stopped.
- Surface runtime errors directly and clearly.
