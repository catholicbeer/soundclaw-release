# Browse Assets

Purpose: Discover and disambiguate SoundClaw assets through the documented runtime CLI.

Runtime dependency:

- `soundclawctl library list [--json]`
- when needed for candidate inspection, `soundclawctl library show --asset <id> [--json]`

## Operator Job

This skill helps an operator browse the current SoundClaw asset library before
they know one exact asset id.

It should narrow vague requests such as "show me the choir beds" or "what rain
loops do we have?" into a short set of plausible assets, then hand the operator
to a known asset id for `show-asset` or `play-asset`.

## Guardrails

- Use `library list` as the primary discovery surface.
- Use `library show` only when one or a few candidates need deeper inspection.
- Keep the response focused on asset ids, known metadata, and the next useful step.
- Ask a short clarification question when multiple candidates still fit.
- Treat library lookup failures as runtime or data issues, not host repair work.
- Do not browse raw library files or expose file paths as the normal operator-facing surface.
- Do not start playback from this skill.
