---
name: set-volume
description: Inspect or set runtime-owned global volume and make reload requirements explicit.
---

# Set Volume

Use this skill when the operator asks to inspect or set global SoundClaw volume.

## Behavior

- Before running any `soundclawctl` command, resolve the executable. Prefer
  `soundclawctl` on `PATH`; otherwise use
  `/opt/soundclaw/runtime/current/bin/soundclawctl`.
- For read-only requests, call `soundclawctl volume show [--json]` and summarize
  the current global volume in operator language.
- For set requests, collect one explicit `--global-volume-percent <0-100>`
  value. If the request is outside bounds or ambiguous, ask a short
  clarification question before mutating.
- Run `soundclawctl volume set-global --global-volume-percent <0-100> [--json]`
  only after the target value is clear.
- After `set-global`, state clearly that the command updates config and that a
  running daemon requires `soundclawctl runtime reload [--json]` to observe the
  change.
- If the operator asked to apply the change immediately, run
  `soundclawctl runtime reload [--json]` and report the result explicitly.
- If the operator did not ask for immediate apply, still report that reload is
  required for live daemons and leave the decision explicit.
- When the request is really about per-route gain rather than global volume,
  route to `manage-output` with the documented
  `--route <source:dest[:gain_percent]>` syntax.
- Keep failures explicit about whether the problem appears to be in the skill
  layer (missing/ambiguous request details) or runtime layer (command/validation
  error).

## Out Of Scope

- Per-route output gain edits (use `manage-output` and route syntax)
- Host repair or service manipulation
- Direct ALSA, PipeWire, or mixer mutation
- Runtime-internal IPC
- Hidden retries for mutating commands

## Local References

- Read `{baseDir}/references/README.md` for the operator job, guardrails, and intent boundary.
- Read `{baseDir}/references/examples.md` for example requests and expected behavior.
- Read `{baseDir}/references/compatibility.md` for runtime dependency and packaging notes.
