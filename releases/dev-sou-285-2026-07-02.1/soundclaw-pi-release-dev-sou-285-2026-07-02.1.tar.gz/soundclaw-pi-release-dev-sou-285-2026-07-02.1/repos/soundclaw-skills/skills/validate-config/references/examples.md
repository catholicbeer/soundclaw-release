# Validate Config Examples

## Example Requests

- "Validate the SoundClaw config."
- "Check whether the runtime config is okay."
- "Run the config diagnostic."

## Expected Skill Behavior

- Use the promoted config-validation command only.
- Clearly report pass or fail.
- Point to the right follow-up path when validation fails.
