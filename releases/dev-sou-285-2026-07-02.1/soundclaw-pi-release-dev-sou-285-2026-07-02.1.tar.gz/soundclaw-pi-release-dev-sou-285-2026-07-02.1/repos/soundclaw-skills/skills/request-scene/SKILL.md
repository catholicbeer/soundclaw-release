---
name: request-scene
description: Submit, inspect, explain, or stop one bounded Phase 3 Scene through promoted runtime commands.
---

# Request Scene

Use this skill when the operator asks for a bounded multi-Layer automatic
`Scene`, asks what Scene is active or why, or asks to stop the current Scene.

## Behavior

- Resolve `soundclawctl` from `PATH`, falling back to
  `/opt/soundclaw/runtime/current/bin/soundclawctl`.
- For reads, call `soundclawctl scene show --json` or
  `soundclawctl scene explain --json`. Treat runtime-owned lifecycle, Layer,
  diff, policy, failure, recovery, context-provenance, Timeline, and reason-code
  fields as authoritative.
- For apply, construct exactly one schema-version `1` Scene JSON document and
  call `soundclawctl scene apply --file <scene.json> --request-id <uuid> --json`.
  Generate one request UUID and never silently retry with a new UUID.
- Resolve asset and logical-output identifiers through promoted `library` and
  `outputs` commands when needed. Ask for clarification when an asset, output,
  timing, validity window, required context fact, or replacement intent is
  missing, ambiguous, or unsafe.
- Before a consequential apply, summarize the proposed Scene id, Layers,
  assets, outputs, timing, replacement effect, and context state. Ask for
  confirmation when the request would replace an active Scene or when any
  consequential value was inferred rather than stated explicitly.
- After confirmation, write only the canonical Scene version `1` document used
  for submission. Do not treat conversational drafts or private planning state
  as Runtime state.
- Include only normalized `local_time` and `weather` context facts supplied by
  the Phase 3 context provider. Preserve source, observed-at, valid-until,
  freshness, and required/optional semantics; do not infer or repair stale facts.
- Normalize local time as exactly `timezone`, `local_date`, `local_time`,
  `utc_offset_minutes`, and ISO `weekday`. Use `source: host_clock`,
  `trust: host`, exact UTC-second `observed_at`/`expires_at`, and no more than
  60 seconds of freshness. If host clock health is not acceptable, emit an
  `unavailable` fact with `value: null` and equal timestamps; never label it fresh.
- Normalize weather as exactly `condition`, `temperature_milli_c`,
  `precipitation_probability_percent`, and optional `wind_milli_mps`. Map the
  provider result to the contract enum before submission, set `trust: provider`,
  and honor the provider expiry up to six hours. Do not include provider-native
  codes, forecast prose, coordinates, credentials, or raw payloads.
- Compute status deterministically at Scene creation: `fresh` requires a value
  and creation time strictly before `expires_at`; `stale` retains the normalized
  value at or after expiry; `unavailable` has `value: null` and
  `expires_at == observed_at`. Never rewrite stale or unavailable as current.
- A required stale or unavailable fact must prevent submission. An optional
  stale or unavailable weather fact remains explicit and produces the documented
  degraded fallback; record that fallback in privacy-safe `decision_factors`.
  Local time normally remains available from the healthy host clock.
- Do not submit duplicate or conflicting facts of one `kind`. Resolve one
  authoritative source or ask for clarification; never merge values silently.
- For stop, call
  `soundclawctl scene stop --reason <text> --json` exactly once.
- Explain accepted, replaced, blocked, stale, degraded, partially failed,
  recovered, replayed, expired, and stopped outcomes from runtime-owned fields.
  Preserve stable reason codes and identify the affected Layers/outputs.
- If Scene commands are missing, state that the deployed runtime lacks the
  promoted Phase 3 Scene surface instead of emulating it locally.
- Feedback-informed intent may be prepared only by the optional private Garden
  Spirit capability before Scene construction. Submit only the resulting
  self-contained Scene version `1`; never include raw feedback, record identity,
  hashes, opaque references, private paths, or operator identity.

## Out Of Scope

- Private operator HTTP routes, socket calls, or console DOM/snapshot scraping
- Skill-owned Scene state, Timeline replay, audio policy, scheduling, or retries
- Host mutation, service control, raw audio routing, or direct playback
- Learned preference or private feedback storage
- Camera, microphone, calendar, arbitrary sensors, or unbounded scheduling

## Local References

- Read `{baseDir}/references/README.md` for the operator job, guardrails, and intent boundary.
- Read `{baseDir}/references/examples.md` for example requests and expected behavior.
- Read `{baseDir}/references/compatibility.md` for runtime dependency and packaging notes.
