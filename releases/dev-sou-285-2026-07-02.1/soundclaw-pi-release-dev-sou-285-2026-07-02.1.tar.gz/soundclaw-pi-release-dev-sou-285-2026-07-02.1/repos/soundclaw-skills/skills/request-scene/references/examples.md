# Request Scene Examples

## Apply

Operator: “Play rain in the porch and bells in the nave until 9 PM.”

Resolve both asset ids, outputs, and the exact validity timestamp. If any is
ambiguous, ask before writing the bounded Scene file. Submit once with
`soundclawctl scene apply --file <scene.json> --request-id <uuid> --json`, then
explain the runtime-owned outcome and reason codes.

## Explain

Operator: “Why did the weather Scene not start?”

Call `soundclawctl scene explain --json` and report the runtime-owned context,
policy, Layer, and Timeline evidence. Do not guess or acquire new context.

## Stop

Operator: “Stop the automatic Scene.”

Call `soundclawctl scene stop --reason operator_request --json` once and report
the acknowledged result.

## Context outcomes

- Fresh: include a healthy host-clock fact and unexpired normalized provider
  weather with their independent provenance and expiries.
- Stale: preserve the normalized last weather value with `status: stale`; block
  if required or submit the explicit optional degraded fallback.
- Missing/unavailable: use `status: unavailable`, `value: null`, and equal
  observed/expiry timestamps. Never invent a weather value.
- Conflicting: do not submit two weather facts or merge providers; select the
  declared authority or ask the operator to clarify.
- Explain: after apply, use `scene explain --json` to report which facts and
  fallback decision factors the runtime recorded.
