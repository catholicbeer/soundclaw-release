---
name: manage-feedback
description: Capture and manage explicit private SoundClaw feedback through the optional private capability.
---

# Manage Feedback

Use this skill only when the operator explicitly asks to create, inspect,
correct, renew, export, revoke, delete, or use private SoundClaw feedback.

## Behavior

- Resolve `soundclaw-feedback` from `PATH`. Do not probe arbitrary paths or
  inspect private state to discover it.
- If the command is missing or reports unavailable private state, explain that
  personalization is unavailable and leave SoundClaw core operation unchanged.
  Do not install software, create a fallback store, or infer a storage path.
- Treat ordinary play, stop, volume, replacement, replay, dwell, console
  actions, repeated use, and silence as non-feedback. Never create or update a
  record from those signals.
- Before create, present the normalized preference, subject, narrow scope,
  explicit capture source, retention period, and management actions. Ask for
  affirmative confirmation immediately before calling
  `soundclaw-feedback create ... --confirm`.
- Initial retention must be 1 through 180 days. Renewal requires a fresh
  confirmation and may add no more than 365 days per renewal.
- For list and show, summarize only what the operator requested. Do not copy
  results into public notes, Runtime requests, Timeline, logs, or evidence.
- For correction, repeat the selected record and proposed replacement, then
  call `soundclaw-feedback correct` only after ambiguity is resolved.
- For export, require an operator-selected private destination. Never suggest a
  public repository, release artifact, Runtime directory, or evidence folder.
- For revoke, explain that future reuse stops immediately. For delete, require
  explicit confirmation immediately before `soundclaw-feedback delete ...
  --confirm`.
- When the operator asks for a feedback-informed Scene, allow the private
  Garden Spirit capability to resolve eligible feedback before constructing
  intent. Submit only the resulting self-contained Scene version 1 through the
  existing `request-scene` workflow. Never copy feedback text, record identity,
  hashes, opaque references, private paths, or operator identity into Scene.
- If no retention-safe explanation exists, omit the feedback-derived
  explanation and describe only the resulting operational choice.

## Out Of Scope

- Feedback storage, schema, database access, or backup handling
- Implicit preference learning or multi-operator sharing
- Runtime, Timeline, Familiar, or Scene schema changes
- Host mutation, private repository discovery, or private-state repair

## Local References

- Read `{baseDir}/references/README.md` for the operator job, guardrails, and intent boundary.
- Read `{baseDir}/references/examples.md` for example requests and expected behavior.
- Read `{baseDir}/references/compatibility.md` for runtime dependency and packaging notes.
