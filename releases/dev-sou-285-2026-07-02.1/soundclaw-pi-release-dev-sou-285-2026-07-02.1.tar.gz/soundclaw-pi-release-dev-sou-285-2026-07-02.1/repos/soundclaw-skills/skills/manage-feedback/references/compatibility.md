# Compatibility

Operator job: Manage explicit private feedback and optionally apply eligible
preferences during private Garden Spirit planning.

Capability dependency:

- Status: Optional private capability; core SoundClaw remains available when it
  is absent.
- Contract reference: `soundclaw/docs/feedback-privacy-contract.md`
- Private implementation owner: `soundclaw-private-overlay`, excluded from
  public release tuples and public evidence.
- Scene boundary: self-contained Scene schema version 1 through the existing
  `request-scene` workflow; no feedback reference is compatible.

Minimum compatible runtime release line: Any promoted line supporting the
Scene version 1 command contract used by `request-scene`.

Tested runtime release line: Pending integrated Phase 3b WDR.

Packaging target: Plain skill

ClawHub publication status: Not published
