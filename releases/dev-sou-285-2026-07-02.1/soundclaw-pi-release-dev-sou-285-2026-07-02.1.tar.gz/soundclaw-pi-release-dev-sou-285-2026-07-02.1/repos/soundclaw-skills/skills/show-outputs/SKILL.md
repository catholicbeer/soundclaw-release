---
name: show-outputs
description: Inspect runtime-owned logical outputs and deployment defaults through the documented runtime CLI.
---

# Show Outputs

Use this skill when the operator wants to know which logical outputs exist or what the runtime defaults are.

## Behavior

- Before running any `soundclawctl` command, resolve the executable. Prefer
  `soundclawctl` when it is visible on `PATH`; otherwise use
  `/opt/soundclaw/runtime/current/bin/soundclawctl`.
- Use `soundclawctl outputs list [--json]` to discover available outputs.
- Use `soundclawctl outputs show --output <id> [--json]` when the operator asked for details about one output's ordered destination-channel layout or destination-channel count.
- Use `soundclawctl config defaults [--json]` to discover deployment defaults such as `default_output`.
- Summarize the results in clear operator language.
- Keep any additional defaults grounded in runtime-owned terminology rather than turning them into skill-layer promises.
- Make it explicit when a default is absent rather than guessing one.

## Out Of Scope

- Editing runtime config
- Host repair
- Semantic speaker-role inference beyond what the runtime has declared

## Local References

- Read `{baseDir}/references/README.md` for the operator job, guardrails, and intent boundary.
- Read `{baseDir}/references/examples.md` for example requests and expected behavior.
- Read `{baseDir}/references/compatibility.md` for runtime dependency and packaging notes.
