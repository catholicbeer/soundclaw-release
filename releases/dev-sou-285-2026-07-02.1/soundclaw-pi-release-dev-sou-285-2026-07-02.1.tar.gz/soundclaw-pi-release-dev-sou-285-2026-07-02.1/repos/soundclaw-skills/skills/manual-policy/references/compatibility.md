# Compatibility

Operator job: Inspect or change runtime-owned manual override policy.

Runtime dependency:

- Status: Pending current runtime release-line declaration for these promoted
  Wave 4 command shapes.
- Contract reference: `soundclaw/docs/runtime-spec.md`
- Runtime implementation reference: `SOU-201` landed `soundclaw-runtime` `main`
  at `fd97982a3e6855d32ccfe1a3ee293422ac2877ac` with the promoted
  `soundclawctl policy` surface.
- Command(s): `soundclawctl policy status [--json]`
- Command(s): `soundclawctl policy hold [--reason <text>] [--cooldown <duration>] [--json]`
- Command(s): `soundclawctl policy clear [--json]`
- Command(s): `soundclawctl policy resume [--json]`
- Scope note: Runtime owns policy state, persistence, enforcement, cooldown
  deadlines, blocked-action reasons, and resume reconciliation. This skill may
  explain or invoke those outcomes only through the promoted CLI surface.

Minimum compatible runtime release line: Pending definition in `soundclaw-runtime`.

Tested runtime release line: Not yet validated against a promoted runtime release line.

Packaging target: Plain skill

ClawHub publication status: Not published
