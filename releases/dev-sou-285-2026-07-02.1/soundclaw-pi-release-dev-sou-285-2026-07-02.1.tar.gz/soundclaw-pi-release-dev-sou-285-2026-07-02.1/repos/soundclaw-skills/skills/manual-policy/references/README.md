# Manual Policy

Purpose: Inspect or change the runtime-owned manual override policy through the
documented `soundclawctl policy` CLI boundary.

Runtime dependency:

- `soundclawctl policy status [--json]`
- `soundclawctl policy hold [--reason <text>] [--cooldown <duration>] [--json]`
- `soundclawctl policy clear [--json]`
- `soundclawctl policy resume [--json]`

## Operator Job

This skill handles operator requests to inspect the current manual policy,
place SoundClaw into an explicit manual hold, clear that hold, or resume normal
automatic `Scene` execution through the runtime-owned policy surface.

It should relay the runtime's policy state, reason code, human rationale,
source, timestamps, cooldown deadline, and blocked-action context when those
fields are present. It must not calculate policy state locally or replay
runtime events.

## Guardrails

- Resolve and call only the promoted `soundclawctl policy` commands.
- Treat the runtime's JSON result as authoritative for policy state, command
  outcome, reason data, cooldown deadline, and any blocked automatic action.
- Ask for explicit confirmation before `policy hold`, `policy clear`, or
  `policy resume` when the operator request is ambiguous.
- If the installed runtime does not expose `policy`, say the deployed runtime
  line lacks the promoted Wave 4 policy surface.
- Do not store policy state, infer cooldown expiry, replay Timeline events, or
  claim that the skill resumed audio playback.
