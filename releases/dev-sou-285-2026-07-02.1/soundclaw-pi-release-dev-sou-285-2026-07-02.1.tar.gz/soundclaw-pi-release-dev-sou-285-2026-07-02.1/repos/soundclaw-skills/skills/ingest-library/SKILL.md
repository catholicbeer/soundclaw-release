---
name: ingest-library
description: Guide source-preserving SoundClaw library ingest through promoted runtime and pi-kit boundaries.
---

# Ingest Library

Use this skill when the operator asks to import, ingest, refresh, or publish
new SoundClaw library media from the operator intake area while preserving the
source files.

## Behavior

- Before running any `soundclawctl` command, resolve the executable. Prefer
  `soundclawctl` when it is visible on `PATH`; otherwise use
  `/opt/soundclaw/runtime/current/bin/soundclawctl`.
- Explain that source-preserving ingest is host-mutating work. Ask for explicit
  operator approval before running any ingest command.
- For normal OpenClaw-triggered ingest, use `soundclawctl library ingest --json`.
  Do not let the operator provide an arbitrary source path through this skill;
  the runtime uses its configured intake source and pi-kit boundary.
- When the operator needs a shell-run pi-kit path instead of the runtime action,
  guide them to the promoted source-preserving command:
  `soundclaw-pi-kit/scripts/ingest-library.sh --asset-library-root <path> --source <intake-path> [--release-ref <ref>] [--asset-library-ref <ref>]`.
- Keep pi-kit source guidance inside the documented operator intake boundary,
  initially `/var/lib/soundclaw/library-intake`. Do not browse the filesystem
  or suggest ad hoc host paths.
- If ingest returns `completed`, report that the source-preserving ingest
  completed, include the refreshed asset count when present, and mention
  `source_preserving` only as an owner-reported result.
- If ingest returns `blocked`, explain which dependency is missing or
  unconfigured, using the runtime-owned reason.
- If ingest returns `failed`, say the ingest did not complete, include the
  owner-reported failure detail, and avoid claiming the source library changed.
- After successful ingest, use `soundclawctl library list [--json]` only when
  the operator asks to inspect the refreshed library or when confirmation needs
  asset visibility.
- If the command is missing, explain that the installed runtime or pi-kit line
  does not expose the promoted Phase 2 source-preserving ingest surface.

## Out Of Scope

- Silent host mutation
- Arbitrary source-path browsing or imports outside the allowlisted intake path
- Asset-id assignment or index authoring in the skill layer
- Direct edits under `/var/lib/soundclaw/library`
- Private operator-console routes, runtime-internal IPC, or DOM scraping
- Service repair, rollback, installer work, or privileged host commands beyond
  the promoted pi-kit ingest boundary after explicit approval

## Local References

- Read `{baseDir}/references/README.md` for the operator job, guardrails, and intent boundary.
- Read `{baseDir}/references/examples.md` for example requests and expected behavior.
- Read `{baseDir}/references/compatibility.md` for runtime dependency and packaging notes.
