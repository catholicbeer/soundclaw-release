# Ingest Library

Purpose: Guide source-preserving SoundClaw library ingest through promoted
runtime and pi-kit boundaries without browsing arbitrary host paths or silently
mutating the host.

Runtime and pi-kit dependency:

- `soundclawctl library ingest [--json]`
- `soundclawctl library list [--json]`
- `soundclaw-pi-kit/scripts/ingest-library.sh --asset-library-root <path> --source <intake-path> [--release-ref <ref>] [--asset-library-ref <ref>]`

## Operator Job

This skill handles operator requests to ingest staged library media into the
SoundClaw library while preserving the source files. It should explain the
operator-safe intake path, require explicit approval before mutation, and route
the action through the promoted runtime or pi-kit boundary.

Runtime-backed ingest is preferred when available because it uses the configured
pi-kit boundary and does not let callers provide arbitrary source paths. Direct
pi-kit guidance is limited to the promoted source-preserving script path and
must still require explicit operator approval.

## Guardrails

- Prefer `soundclawctl library ingest --json` for OpenClaw-triggered ingest.
- Do not pass arbitrary source paths through OpenClaw. The runtime command uses
  the configured intake source, and pi-kit guidance should stay within the
  documented allowlisted intake path such as `/var/lib/soundclaw/library-intake`.
- Require explicit operator approval before any host-mutating ingest command.
- Treat `completed`, `blocked`, and `failed` as runtime or pi-kit-owned
  outcomes. Relay `source_preserving`, asset count, and failure detail only
  when the owning command reports them.
- If the runtime or pi-kit command is missing or unconfigured, say the Phase 2
  ingest capability is unavailable in this deployment.
- Do not browse local directories, assign asset ids, edit `/var/lib/soundclaw/library`,
  call private operator-console routes, or run privileged repair commands.
