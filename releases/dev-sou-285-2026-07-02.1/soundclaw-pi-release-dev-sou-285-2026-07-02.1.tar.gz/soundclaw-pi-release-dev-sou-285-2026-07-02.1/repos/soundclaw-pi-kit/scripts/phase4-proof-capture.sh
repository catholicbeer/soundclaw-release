#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=../lib/pi-kit.sh disable=SC1091
source "${SCRIPT_DIR}/../lib/pi-kit.sh"

OUTPUT_DIR=""
CANDIDATE_LABEL="installed-deployment"
CONSOLE_URL="http://127.0.0.1:8765"
SCENE_FILE=""
SKILLS_DIR=""

usage() {
  cat <<'EOF'
Usage: phase4-proof-capture.sh --scene PATH [options]
  --scene PATH             Valid Scene v1 JSON.
  --console-url URL        Web UI base URL (default http://127.0.0.1:8765).
  --skills-dir PATH        Installed OpenClaw skills root.
  --output-dir PATH        Evidence directory.
  --candidate-label TEXT   Exact release or tuple label.
  --dry-run                Record commands without executing them.
EOF
}

capture() {
  local label="$1" output="$2"; shift 2
  local status=0 command_text
  command_text="$(quote_cmd "$@")"
  printf '%s\t%s\n' "$label" "$command_text" >>"${OUTPUT_DIR}/commands.tsv"
  if [[ "$DRY_RUN" == "1" ]]; then
    printf 'dry-run command: %s\n' "$command_text" >"$output"
  else
    set +e; "$@" >"$output" 2>"${output}.stderr"; status=$?; set -e
  fi
  printf '%s\t%s\t%s\t%s\n' "$(timestamp_utc)" "$label" "$status" "$output" >>"${OUTPUT_DIR}/command-status.tsv"
  return "$status"
}

new_request_id() {
  if [[ "$DRY_RUN" == "1" ]]; then
    printf '00000000-0000-4000-8000-000000000004\n'
  elif command_exists uuidgen; then
    uuidgen | tr '[:upper:]' '[:lower:]'
  else
    cat /proc/sys/kernel/random/uuid
  fi
}

main() {
  local created_at default_output runtime_ctl
  while [[ $# -gt 0 ]]; do
    case "$1" in
      --scene) SCENE_FILE="$2"; shift 2 ;;
      --console-url) CONSOLE_URL="${2%/}"; shift 2 ;;
      --skills-dir) SKILLS_DIR="$2"; shift 2 ;;
      --output-dir) OUTPUT_DIR="$2"; shift 2 ;;
      --candidate-label) CANDIDATE_LABEL="$2"; shift 2 ;;
      --dry-run) DRY_RUN=1; shift ;;
      --help|-h) usage; exit 0 ;;
      *) die "unknown argument: $1" ;;
    esac
  done
  [[ -n "$SCENE_FILE" ]] || die "--scene is required"
  [[ "$DRY_RUN" == "1" || -f "$SCENE_FILE" ]] || die "Scene fixture is missing: ${SCENE_FILE}"
  load_installed_layout || warn "no installed layout; using environment defaults"
  runtime_ctl="$(root_path "$(runtime_current_dir)")/bin/soundclawctl"
  SKILLS_DIR="${SKILLS_DIR:-$(root_path "$SC_SKILLS_DIR")}" 
  default_output="$(root_path "${SC_STATE_DIR%/}/phase4-proof/$(date -u +%Y%m%dT%H%M%SZ)")"
  OUTPUT_DIR="${OUTPUT_DIR:-$default_output}"
  [[ "$OUTPUT_DIR" == /* ]] || die "--output-dir must be absolute"
  mkdir -p "$OUTPUT_DIR"
  printf 'label\tcommand\n' >"${OUTPUT_DIR}/commands.tsv"
  printf 'timestamp_utc\tlabel\tstatus\toutput_file\n' >"${OUTPUT_DIR}/command-status.tsv"
  created_at="$(timestamp_utc)"
  cat >"${OUTPUT_DIR}/summary.env" <<EOF
PHASE4_PROOF_SCHEMA='phase4a-openclaw-webui2-pi-proof-v1'
PHASE4_PROOF_CREATED_AT=${created_at@Q}
PHASE4_PROOF_CANDIDATE_LABEL=${CANDIDATE_LABEL@Q}
PHASE4_PROOF_HOSTNAME=$(hostname | sed "s/.*/'&'/")
PHASE4_PROOF_CONSOLE_URL=${CONSOLE_URL@Q}
PHASE4_PROOF_BOUNDARY='pi-kit captures deployment identity and promoted browser, CLI, and installed-skill surfaces; runtime owns UI and Scene semantics; skills owns OpenClaw prompts'
EOF
  capture deployment-status "${OUTPUT_DIR}/deployment-status.json" "${SCRIPT_DIR}/deployment-status.sh" --json || true
  capture runtime-status "${OUTPUT_DIR}/runtime-status.json" "$runtime_ctl" runtime status --json || true
  capture webui-root "${OUTPUT_DIR}/webui-root.html" curl --fail --silent --show-error "${CONSOLE_URL}/" || true
  capture webui-snapshot "${OUTPUT_DIR}/webui-snapshot.json" curl --fail --silent --show-error "${CONSOLE_URL}/api/console/snapshot" || true
  capture library-list "${OUTPUT_DIR}/library-list.json" "$runtime_ctl" library list --json || true
  capture scene-apply "${OUTPUT_DIR}/scene-apply.json" "$runtime_ctl" scene apply --file "$SCENE_FILE" --request-id "$(new_request_id)" --json || true
  capture scene-explain "${OUTPUT_DIR}/scene-explain.json" "$runtime_ctl" scene explain --json || true
  capture scene-stop "${OUTPUT_DIR}/scene-stop.json" "$runtime_ctl" scene stop --reason phase4_proof_complete --json || true
  capture toolkit-files "${OUTPUT_DIR}/toolkit-files.txt" find "$SKILLS_DIR" -maxdepth 2 -type f -name SKILL.md -print || true
  capture toolkit-contract "${OUTPUT_DIR}/toolkit-contract.txt" grep -R -E 'SoundClaw|soundclawctl|preview|confirm' "${SKILLS_DIR}/soundclaw-toolkit" || true
  capture config-fingerprint "${OUTPUT_DIR}/config-fingerprint.txt" sha256sum "$(root_path "${SC_CONFIG_DIR%/}/runtime.toml")" || true
  capture library-fingerprint "${OUTPUT_DIR}/library-fingerprint.txt" find "$(root_path "$SC_LIBRARY_DIR")" -type f -exec sha256sum '{}' + || true
  info "Phase 4a evidence captured in ${OUTPUT_DIR}"
}

main "$@"
