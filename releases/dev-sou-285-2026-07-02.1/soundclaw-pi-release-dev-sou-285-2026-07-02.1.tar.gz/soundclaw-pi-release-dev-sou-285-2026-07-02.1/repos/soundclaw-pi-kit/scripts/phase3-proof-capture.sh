#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=../lib/pi-kit.sh disable=SC1091
source "${SCRIPT_DIR}/../lib/pi-kit.sh"

OUTPUT_DIR=""
CANDIDATE_LABEL="installed-deployment"
SCENE_FILE=""
REPLACEMENT_FILE=""
STALE_CONTEXT_FILE=""
PARTIAL_FAILURE_FILE=""
EXERCISE_SECONDS=1800
SKIP_RESTART=0
RUNTIME_CTL=""
RESTART_READINESS_TIMEOUT_MS=15000
RESTART_READINESS_POLL_MS=1000

usage() {
  cat <<'EOF'
Usage: phase3-proof-capture.sh --scene PATH [options]

Capture privacy-safe Phase 3 target-Pi evidence through promoted owner surfaces.

  --scene PATH                 Baseline valid Scene JSON.
  --replacement-scene PATH     Higher-revision replacement Scene JSON.
  --stale-context-scene PATH   Scene expected to exercise stale-context rejection.
  --partial-failure-scene PATH Scene expected to exercise bounded partial failure.
  --output-dir PATH            Evidence directory (default under SoundClaw state).
  --candidate-label TEXT       Exact release or tuple label.
  --exercise-seconds N         Resource/journal window (default 1800).
  --skip-restart               Do not restart the live runtime service.
  --dry-run                    Record commands without executing them.
EOF
}

capture() {
  local label="$1" output="$2"; shift 2
  local status=0 command_text
  command_text="$(quote_cmd "$@")"
  printf '%s\t%s\n' "$label" "$command_text" >>"${OUTPUT_DIR}/commands.tsv"
  if [[ "$DRY_RUN" == "1" ]]; then
    printf 'dry-run command: %s\n' "$command_text" >"$output"
  else
    set +e
    "$@" >"$output" 2>"${output}.stderr"
    status=$?
    set -e
  fi
  printf '%s\t%s\t%s\t%s\n' "$(timestamp_utc)" "$label" "$status" "$output" >>"${OUTPUT_DIR}/command-status.tsv"
  return "$status"
}

timed_capture() {
  local label="$1" output="$2"; shift 2
  local start end status=0
  start="$(date +%s%3N)"
  capture "$label" "$output" "$@" || status=$?
  end="$(date +%s%3N)"
  printf '%s\t%s\t%s\t%s\n' "$label" "$status" "$((end - start))" "$output" >>"${OUTPUT_DIR}/timing-results.tsv"
  return 0
}

wait_for_runtime_readiness() {
  local attempt=0 command_timeout duration_ms end_ms final_output="" now_ms remaining_ms sleep_ms start_ms status="timeout"

  start_ms="$(date +%s%3N)"
  while :; do
    now_ms="$(date +%s%3N)"
    remaining_ms=$((RESTART_READINESS_TIMEOUT_MS - (now_ms - start_ms)))
    (( remaining_ms > 0 )) || break

    attempt=$((attempt + 1))
    final_output="${OUTPUT_DIR}/restart-readiness-status-${attempt}.json"
    command_timeout="$(awk -v milliseconds="$remaining_ms" 'BEGIN { printf "%.3fs", milliseconds / 1000 }')"
    if capture "restart-readiness-status-${attempt}" "$final_output" \
      timeout "$command_timeout" "$RUNTIME_CTL" runtime status --json; then
      status="ready"
      break
    fi

    now_ms="$(date +%s%3N)"
    remaining_ms=$((RESTART_READINESS_TIMEOUT_MS - (now_ms - start_ms)))
    (( remaining_ms > 0 )) || break
    sleep_ms="$RESTART_READINESS_POLL_MS"
    (( sleep_ms <= remaining_ms )) || sleep_ms="$remaining_ms"
    sleep "$(awk -v milliseconds="$sleep_ms" 'BEGIN { printf "%.3f", milliseconds / 1000 }')"
  done

  end_ms="$(date +%s%3N)"
  duration_ms=$((end_ms - start_ms))
  if [[ "$DRY_RUN" == "1" ]]; then
    status="dry_run"
  fi
  cat >"${OUTPUT_DIR}/restart-readiness.env" <<EOF
PHASE3_RESTART_READINESS_STATUS=${status@Q}
PHASE3_RESTART_READINESS_TIMEOUT_MS=${RESTART_READINESS_TIMEOUT_MS@Q}
PHASE3_RESTART_READINESS_DURATION_MS=${duration_ms@Q}
PHASE3_RESTART_READINESS_ATTEMPTS=${attempt@Q}
PHASE3_RESTART_READINESS_FINAL_OUTPUT=${final_output@Q}
EOF

  [[ "$status" == "ready" || "$status" == "dry_run" ]]
}

new_request_id() {
  if [[ "$DRY_RUN" == "1" ]]; then
    printf '00000000-0000-4000-8000-%012d\n' "$1"
  elif command_exists uuidgen; then
    uuidgen | tr '[:upper:]' '[:lower:]'
  else
    cat /proc/sys/kernel/random/uuid
  fi
}

apply_scene() {
  local label="$1" scene_file="$2" request_index="$3"
  [[ -n "$scene_file" ]] || {
    printf '%s not exercised; no fixture supplied\n' "$label" >"${OUTPUT_DIR}/${label}-not-exercised.txt"
    return 0
  }
  [[ "$DRY_RUN" == "1" || -f "$scene_file" ]] || die "Scene fixture is missing: ${scene_file}"
  timed_capture "$label" "${OUTPUT_DIR}/${label}.json" \
    "$RUNTIME_CTL" scene apply --file "$scene_file" --request-id "$(new_request_id "$request_index")" --json
  timed_capture "${label}-explain" "${OUTPUT_DIR}/${label}-explain.json" \
    "$RUNTIME_CTL" scene explain --json
}

capture_resources() {
  local deadline now pid
  printf 'timestamp_utc\tpid\tcpu_percent\trss_kib\n' >"${OUTPUT_DIR}/resource-samples.tsv"
  [[ "$DRY_RUN" != "1" ]] || return 0
  deadline=$(( $(date +%s) + EXERCISE_SECONDS ))
  while :; do
    pid="$(systemctl show -p MainPID --value "$SC_RUNTIME_SERVICE_UNIT_NAME" 2>/dev/null || true)"
    if [[ "$pid" =~ ^[1-9][0-9]*$ ]]; then
      ps -o pid=,%cpu=,rss= -p "$pid" | awk -v stamp="$(timestamp_utc)" '{print stamp "\t" $1 "\t" $2 "\t" $3}' >>"${OUTPUT_DIR}/resource-samples.tsv"
    fi
    now="$(date +%s)"
    (( now >= deadline )) && break
    sleep 10
  done
}

main() {
  local created_at default_output
  while [[ $# -gt 0 ]]; do
    case "$1" in
      --scene) SCENE_FILE="$2"; shift 2 ;;
      --replacement-scene) REPLACEMENT_FILE="$2"; shift 2 ;;
      --stale-context-scene) STALE_CONTEXT_FILE="$2"; shift 2 ;;
      --partial-failure-scene) PARTIAL_FAILURE_FILE="$2"; shift 2 ;;
      --output-dir) OUTPUT_DIR="$2"; shift 2 ;;
      --candidate-label) CANDIDATE_LABEL="$2"; shift 2 ;;
      --exercise-seconds) [[ "$2" =~ ^[0-9]+$ ]] || die "--exercise-seconds must be non-negative"; EXERCISE_SECONDS="$2"; shift 2 ;;
      --skip-restart) SKIP_RESTART=1; shift ;;
      --dry-run) DRY_RUN=1; shift ;;
      --help|-h) usage; exit 0 ;;
      *) die "unknown argument: $1" ;;
    esac
  done
  [[ -n "$SCENE_FILE" ]] || die "--scene is required"
  load_installed_layout || warn "no installed layout; using environment defaults"
  RUNTIME_CTL="$(root_path "$(runtime_current_dir)")/bin/soundclawctl"
  default_output="$(root_path "${SC_STATE_DIR%/}/phase3-proof/$(date -u +%Y%m%dT%H%M%SZ)")"
  OUTPUT_DIR="${OUTPUT_DIR:-$default_output}"
  [[ "$OUTPUT_DIR" == /* ]] || die "--output-dir must be absolute"
  mkdir -p "$OUTPUT_DIR"
  printf 'label\tcommand\n' >"${OUTPUT_DIR}/commands.tsv"
  printf 'timestamp_utc\tlabel\tstatus\toutput_file\n' >"${OUTPUT_DIR}/command-status.tsv"
  printf 'label\tstatus\tduration_ms\toutput_file\n' >"${OUTPUT_DIR}/timing-results.tsv"
  created_at="$(timestamp_utc)"
  cat >"${OUTPUT_DIR}/summary.env" <<EOF
PHASE3_PROOF_SCHEMA='phase3-scene-pi-proof-v1'
PHASE3_PROOF_CREATED_AT=${created_at@Q}
PHASE3_PROOF_CANDIDATE_LABEL=${CANDIDATE_LABEL@Q}
PHASE3_PROOF_HOSTNAME=$(hostname | sed "s/.*/'&'/")
PHASE3_PROOF_EXERCISE_SECONDS=${EXERCISE_SECONDS@Q}
PHASE3_PROOF_BOUNDARY='pi-kit captures identity, raw promoted outputs, timing, resources, logs, and disk evidence; runtime owns Scene semantics'
EOF
  capture deployment-status "${OUTPUT_DIR}/deployment-status.json" "${SCRIPT_DIR}/deployment-status.sh" --json || true
  capture runtime-status "${OUTPUT_DIR}/runtime-status-before.json" "$RUNTIME_CTL" runtime status --json || true
  capture scene-show-before "${OUTPUT_DIR}/scene-show-before.json" "$RUNTIME_CTL" scene show --json || true
  apply_scene scene-apply "$SCENE_FILE" 1
  apply_scene scene-replace "$REPLACEMENT_FILE" 2
  capture policy-hold "${OUTPUT_DIR}/policy-hold.json" "$RUNTIME_CTL" policy hold --reason phase3_proof --json || true
  apply_scene policy-block "$SCENE_FILE" 3
  capture policy-clear "${OUTPUT_DIR}/policy-clear.json" "$RUNTIME_CTL" policy clear --json || true
  capture policy-resume "${OUTPUT_DIR}/policy-resume.json" "$RUNTIME_CTL" policy resume --json || true
  apply_scene stale-context "$STALE_CONTEXT_FILE" 4
  apply_scene partial-failure "$PARTIAL_FAILURE_FILE" 5
  if [[ "$SKIP_RESTART" == "0" ]] && { [[ "$DRY_RUN" == "1" ]] || is_live_root; }; then
    timed_capture runtime-restart "${OUTPUT_DIR}/runtime-restart.txt" systemctl restart "$SC_RUNTIME_SERVICE_UNIT_NAME"
    if wait_for_runtime_readiness; then
      timed_capture restart-reconcile "${OUTPUT_DIR}/restart-reconcile.json" "$RUNTIME_CTL" scene explain --json
    else
      printf '{"kind":"phase3_restart_readiness","status":"timeout","timeout_ms":%s}\n' \
        "$RESTART_READINESS_TIMEOUT_MS" >"${OUTPUT_DIR}/restart-reconcile.json"
      warn "runtime did not become ready within ${RESTART_READINESS_TIMEOUT_MS} ms; restart reconciliation proof failed"
      return 1
    fi
  else
    printf 'restart not exercised outside live root or explicitly skipped\n' >"${OUTPUT_DIR}/restart-not-exercised.txt"
  fi
  capture_resources
  timed_capture scene-stop "${OUTPUT_DIR}/scene-stop.json" "$RUNTIME_CTL" scene stop --reason phase3_proof_complete --json
  capture scene-explain-final "${OUTPUT_DIR}/scene-explain-final.json" "$RUNTIME_CTL" scene explain --json || true
  capture runtime-status-after "${OUTPUT_DIR}/runtime-status-after.json" "$RUNTIME_CTL" runtime status --json || true
  capture timeline-disk "${OUTPUT_DIR}/timeline-disk.txt" du -sh "$(root_path "$SC_RUNTIME_STATE_DIR")" || true
  if [[ "$DRY_RUN" != "1" ]] && is_live_root && command_exists journalctl; then
    capture runtime-journal "${OUTPUT_DIR}/runtime-journal.txt" journalctl -u "$SC_RUNTIME_SERVICE_UNIT_NAME" --since "$created_at" --no-pager || true
  fi
  info "Phase 3 evidence captured in ${OUTPUT_DIR}"
}

main "$@"
