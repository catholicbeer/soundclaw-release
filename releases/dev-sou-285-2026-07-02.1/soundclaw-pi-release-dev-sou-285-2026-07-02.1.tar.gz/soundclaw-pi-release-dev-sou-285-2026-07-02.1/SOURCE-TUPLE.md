# Source tuple

Promotion gate: `main -> dev + dev release surface`

- soundclaw: `85a6f0cbcfecfb95b7829b8fe42609e727af24aa`; issue SOU-289
- soundclaw-runtime: `d5ac94369ebf358a4e7af7ceeb35ee07f7651aab`; issue SOU-288
- soundclaw-skills: `d329c25d31796128608fd1d57af7c63d16d2a480`; issue SOU-286
- soundclaw-pi-kit: `140029b8ddb7a8057d2a34ab438934ed8b284c3a`; issues SOU-287, SOU-290, SOU-291
- soundclaw-asset-library: `72400d11ff889191b48f3b71f241dafae28c0b37`; unchanged

This is a dev/RC candidate and is not RTW or final.
