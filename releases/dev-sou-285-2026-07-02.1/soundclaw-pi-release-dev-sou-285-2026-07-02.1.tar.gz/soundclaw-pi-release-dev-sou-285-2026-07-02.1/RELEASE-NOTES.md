# SoundClaw Phase 4a dev candidate

Release id: `dev-sou-285-2026-07-02.1`

This prerelease carries the exact pushed `dev` tuple approved by SOU-285.
It adds the OpenClaw-first SoundClaw toolkit and the focused Web UI 2.0 for
library browsing, Scene v1 control, output and zone administration, activity,
health, and recovery. It is a dev/RC surface for later RTW testing; it is not a
stable or final release.

Source tuple:

- soundclaw: `85a6f0cbcfecfb95b7829b8fe42609e727af24aa` (SOU-289)
- soundclaw-runtime: `d5ac94369ebf358a4e7af7ceeb35ee07f7651aab` (SOU-288)
- soundclaw-skills: `d329c25d31796128608fd1d57af7c63d16d2a480` (SOU-286)
- soundclaw-pi-kit: `140029b8ddb7a8057d2a34ab438934ed8b284c3a` (SOU-287, SOU-290, SOU-291)
- soundclaw-asset-library: `72400d11ff889191b48f3b71f241dafae28c0b37` (unchanged)

The target-Pi WDR proved install, Scene apply/stop, output and zone mutation,
restart, source-preserving ingest, stable rollback, candidate reinstall, and
configuration/library preservation on the exact tuple.
