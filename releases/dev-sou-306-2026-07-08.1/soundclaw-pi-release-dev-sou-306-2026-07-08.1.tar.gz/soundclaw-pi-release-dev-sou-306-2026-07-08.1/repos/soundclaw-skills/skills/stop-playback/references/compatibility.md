# Compatibility

Operator job: Stop playback on a logical output.

Runtime dependency:

- Status: Pending current runtime release-line declaration for this promoted command shape.
- Contract reference: `soundclaw/docs/runtime-spec.md`
- Command(s): `soundclawctl playback stop --output <id> [--fade-out-ms <n>] [--json]`

Minimum compatible runtime release line: Pending definition in `soundclaw-runtime`.

Tested runtime release line: Not yet validated against a promoted runtime release line.

Packaging target: Plain skill

ClawHub publication status: Not published
