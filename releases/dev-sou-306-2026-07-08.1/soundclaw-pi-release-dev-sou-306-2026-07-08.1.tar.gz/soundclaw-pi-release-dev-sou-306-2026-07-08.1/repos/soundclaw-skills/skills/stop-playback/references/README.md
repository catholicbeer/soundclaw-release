# Stop Playback

Purpose: Stop SoundClaw playback on a logical output through the documented `soundclawctl` CLI boundary.

Runtime dependency: `soundclawctl playback stop --output <id> [--fade-out-ms <n>] [--json]`

## Operator Job

This skill handles requests to stop playback on a named logical output.

It should keep the workflow simple for the operator while staying explicit about which output will be affected and whether a fade-out was requested.

In MVP, logical outputs should be treated as named presentation layouts such as `main`, `perimeter-wide-4`, or `all-speakers-10`, not assumed to be guest-facing geographic zones.
That presentation language still refers to one runtime-owned layout that may span many destination channels; it does not imply multiple independent playbacks are active at once.

## Guardrails

- Ask which logical output to stop if the request is ambiguous.
- Accept optional fade-out input only when requested.
- Do not retry a mutating stop command silently.
- Do not translate a runtime failure into a fake host repair story.
