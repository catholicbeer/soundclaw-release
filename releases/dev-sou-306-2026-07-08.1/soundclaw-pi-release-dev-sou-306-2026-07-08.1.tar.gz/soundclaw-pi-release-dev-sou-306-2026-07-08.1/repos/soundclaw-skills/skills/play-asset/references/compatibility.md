# Compatibility

Operator job: Play a named asset on a logical output.

Runtime dependency:

- Status: Pending current runtime release-line declaration for this promoted command shape.
- Contract reference: `soundclaw/docs/runtime-spec.md`
- Command(s): `soundclawctl playback play --asset <id> --output <id> [--fade-in-ms <n>] [--json]`
- Command(s): `soundclawctl outputs list [--json]`
- Command(s): `soundclawctl outputs show --output <id> [--json]`
- Command(s): `soundclawctl config defaults [--json]`

Minimum compatible runtime release line: Pending definition in `soundclaw-runtime`.

Tested runtime release line: Not yet validated against a promoted runtime release line.

Packaging target: Plain skill

ClawHub publication status: Not published
