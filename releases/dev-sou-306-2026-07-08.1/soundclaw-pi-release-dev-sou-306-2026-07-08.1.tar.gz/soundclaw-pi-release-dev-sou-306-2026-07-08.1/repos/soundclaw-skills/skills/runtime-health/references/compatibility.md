# Compatibility

Operator job: Check runtime health and summarize diagnostics for the operator.

Runtime dependency:

- Status: Pending current runtime release-line declaration for these promoted command shapes.
- Contract reference: `soundclaw/docs/runtime-spec.md`
- Command(s): `soundclawctl runtime status [--json]`
- Command(s): `soundclawctl runtime doctor [--json]`

Minimum compatible runtime release line: Pending definition in `soundclaw-runtime`.

Tested runtime release line: Not yet validated against a promoted runtime release line.

Packaging target: Plain skill

ClawHub publication status: Not published
