# Runtime Health

Purpose: Summarize whether the SoundClaw runtime appears healthy and give operators the next useful diagnostic step.

Runtime dependency: `soundclawctl runtime status [--json]` and `soundclawctl runtime doctor [--json]`

## Operator Job

This skill handles operator requests such as "is SoundClaw okay?" or "check the runtime health."

It should translate the runtime's health and diagnostics output into short, operator-friendly wording without pretending to repair anything on the host.

## Guardrails

- Prefer `runtime status` as the first check.
- Use `runtime doctor` when a deeper diagnostic summary is needed.
- Keep retries narrow and bounded because these are read-only commands.
- Do not suggest host-changing actions as if the skill can perform them.
