# Runtime Health Examples

## Example Requests

- "Is SoundClaw healthy?"
- "Check the runtime status."
- "Give me the SoundClaw doctor output in plain English."

## Expected Skill Behavior

- Use the promoted runtime health commands only.
- Summarize whether the runtime looks healthy, degraded, or unavailable.
- Keep any retry behavior bounded and limited to the read-only diagnostic workflow.
