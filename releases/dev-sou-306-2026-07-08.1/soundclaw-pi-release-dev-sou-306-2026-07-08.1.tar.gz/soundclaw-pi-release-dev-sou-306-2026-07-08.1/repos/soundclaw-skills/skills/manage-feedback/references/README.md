# Manage Feedback

Purpose: Capture and manage explicit operator feedback through the optional
private `soundclaw-feedback` capability without storing feedback in this public
skill package, Runtime, Timeline, or public release evidence.

The private capability owns consent records, storage, retention, correction,
export, revocation, deletion, and Garden Spirit reuse. This skill owns only
operator-facing discovery, confirmation, command mapping, and honest
unavailable guidance.

## Operator Job

- create one narrowly scoped preference after explicit confirmation
- list or inspect private feedback
- correct, renew, export, revoke, or delete selected feedback
- understand when private personalization is unavailable

## Guardrails

- Never infer feedback from play, stop, volume, replacement, replay, dwell,
  console activity, or failure to reject a suggestion.
- Before create, show the normalized preference, subject, scope, source,
  retention period, and available management actions, then obtain explicit
  confirmation.
- Resolve only `soundclaw-feedback` from `PATH`; do not search for private
  checkouts, databases, configuration, or state paths.
- Never add a store-path argument or copy feedback into a public file, prompt,
  log, Scene request, Timeline item, or retained test artifact.
- If the capability is absent or unavailable, say so and continue without
  personalization. Do not install it or mutate the host.
- Garden Spirit may reuse eligible feedback privately, but Runtime receives
  only self-contained Scene version 1 intent with no feedback reference.
