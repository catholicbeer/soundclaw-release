# Manage Feedback Examples

All examples are synthetic and describe expected interaction shape only.

## Explicit capture

Operator: "Remember that the synthetic evening scene should use quieter rain."

Expected behavior:

- present the normalized synthetic preference and `context` scope
- show the selected retention period and management actions
- obtain explicit confirmation
- invoke the private create command once with `--confirm`

## Ordinary action is not feedback

Operator stops a Scene and later asks why no preference was saved.

Expected behavior:

- explain that stop is an operational action, not feedback consent
- confirm that no feedback record was created
- offer the explicit capture flow without assuming the intended preference

## Capability unavailable

The optional private command is not present.

Expected behavior:

- say that private personalization is unavailable
- do not install, create storage, or inspect private paths
- continue to support normal self-contained Scene requests

## Delete

Operator asks to delete one selected synthetic record.

Expected behavior:

- identify the selected record privately
- explain that reuse stops and deletion is irreversible
- obtain explicit confirmation immediately before the private delete command
- do not retain the deleted content in the response or evidence
