# Ingest Library Examples

## Example Requests

- "Ingest the library intake folder."
- "Import the staged SoundClaw media without deleting the source files."
- "Refresh the library from `/var/lib/soundclaw/library-intake`."
- "Why did the library ingest fail?"

## Expected Skill Behavior

- Explain that source-preserving ingest mutates the SoundClaw host library and
  requires explicit operator approval.
- Prefer `soundclawctl library ingest --json` for OpenClaw-triggered ingest.
- Do not accept arbitrary source paths through OpenClaw; rely on the runtime's
  configured intake source and pi-kit boundary.
- When giving a shell handoff, use
  `soundclaw-pi-kit/scripts/ingest-library.sh --asset-library-root <path> --source <intake-path> [--release-ref <ref>] [--asset-library-ref <ref>]`.
- Keep source guidance within `/var/lib/soundclaw/library-intake` or another
  documented allowlisted intake path from the owning deployment.
- Relay `completed`, `blocked`, and `failed` outcomes from the owning runtime
  or pi-kit command, including `source_preserving` and asset count only when
  reported.
