# Compatibility

Operator job: Guide source-preserving library ingest through promoted runtime
and pi-kit boundaries.

Runtime and pi-kit dependency:

- Status: Pending current runtime and pi-kit release-line declaration for these
  promoted Phase 2 command shapes.
- Contract reference: `soundclaw/docs/pi-kit-spec.md`
- Contract reference: `soundclaw/docs/runtime-spec.md`
- Asset-library implementation reference: `SOU-244` landed the
  source-preserving import/publish path on `soundclaw-asset-library` `main`.
- Pi-kit implementation reference: `SOU-245` landed
  `scripts/ingest-library.sh` on `soundclaw-pi-kit` `main`.
- Runtime implementation reference: `SOU-240` landed
  `soundclawctl library ingest` on `soundclaw-runtime` `main`.
- Command(s): `soundclawctl library ingest [--json]`
- Command(s): `soundclawctl library list [--json]`
- Command(s): `soundclaw-pi-kit/scripts/ingest-library.sh --asset-library-root <path> --source <intake-path> [--release-ref <ref>] [--asset-library-ref <ref>]`
- Scope note: Asset-library owns import/index/publish semantics, pi-kit owns
  host mutation and deployment proof, runtime owns operator initiation/status
  and library refresh, and skills guide only through those promoted surfaces.

Minimum compatible runtime release line: Pending definition in `soundclaw-runtime` and `soundclaw-pi-kit`.

Tested runtime release line: Not yet validated against a promoted runtime/pi-kit release line.

Packaging target: Plain skill

ClawHub publication status: Not published
