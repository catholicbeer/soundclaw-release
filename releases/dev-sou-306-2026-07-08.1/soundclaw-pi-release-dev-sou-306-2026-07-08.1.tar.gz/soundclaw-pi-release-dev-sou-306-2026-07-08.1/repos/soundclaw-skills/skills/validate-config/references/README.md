# Validate Config

Purpose: Check whether the current SoundClaw runtime config validates cleanly and explain the result to the operator.

Runtime dependency: `soundclawctl config validate [--json]`

## Operator Job

This skill handles requests to validate the runtime configuration as an operator diagnostic.

It should explain config-validation failures clearly and route follow-up work back to the right owner without drifting into runtime or host mutation.
If the replayed low-risk output-management wave later adds a deliberate runtime reload step, that reload should be documented as its own promoted runtime command rather than treated as part of config validation.

## Guardrails

- Use the promoted validation command only.
- Report validation failures as runtime or config-layer problems.
- Suggest the next owner or doc path when repair is needed.
- Do not edit config or claim that config has been repaired.
- Do not treat validation as a substitute for a future promoted runtime reload workflow.
