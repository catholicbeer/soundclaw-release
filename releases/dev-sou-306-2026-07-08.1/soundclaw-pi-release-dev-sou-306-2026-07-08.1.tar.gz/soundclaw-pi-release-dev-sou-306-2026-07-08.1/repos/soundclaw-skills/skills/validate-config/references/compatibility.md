# Compatibility

Operator job: Validate the current runtime config as an operator diagnostic.

Runtime dependency:

- Status: Pending current runtime release-line declaration for this promoted command shape.
- Contract reference: `soundclaw/docs/runtime-spec.md`
- Command(s): `soundclawctl config validate [--json]`
- Replay-direction note: A future deliberate runtime reload workflow should cite its own promoted `soundclawctl` reload contract instead of being folded into `config validate`.

Minimum compatible runtime release line: Pending definition in `soundclaw-runtime`.

Tested runtime release line: Not yet validated against a promoted runtime release line.

Packaging target: Plain skill

ClawHub publication status: Not published
