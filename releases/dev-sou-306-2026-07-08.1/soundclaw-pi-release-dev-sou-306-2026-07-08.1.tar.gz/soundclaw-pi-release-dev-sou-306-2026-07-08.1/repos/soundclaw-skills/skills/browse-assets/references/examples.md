# Browse Assets Examples

## Example Requests

- "Browse choir or bells assets."
- "What rain beds do we have?"
- "Help me find the right bells loop before I play it."
- "Show assets in the Garden folder."
- "Which assets already have notes?"
- "Tag this rain loop as calm after the classifier run."

## Expected Skill Behavior

- Use `soundclawctl library list [--json]` first.
- Use `soundclawctl library list --metadata-eq /folder='"Garden"' --json`
  when the operator asks for a folder.
- Use `soundclawctl library list --metadata-exists /notes --json` when the
  operator asks for assets with notes.
- Use exact JSON values in metadata filters; strings must be quoted, booleans
  stay booleans, and numbers stay numbers.
- Use `soundclawctl library show --asset <id> [--json]` when a candidate needs
  deeper inspection.
- Narrow ambiguity without reading library internals directly.
- End with a clear next step or a chosen asset id.

## Metadata Authoring Examples

Use the asset-library authoring boundary, not runtime JSON, when public metadata
needs to change:

```bash
python3 scripts/metadata.py --root . list rain_loop
python3 scripts/metadata.py --root . set rain_loop /notes '"Good dawn ambience"'
python3 scripts/metadata.py --root . set rain_loop /folder '"Garden"'
python3 scripts/metadata.py --root . set rain_loop /analysis/spectral_classifier '{"mood": "calm", "confidence": 0.82}'
python3 scripts/metadata.py --root . remove rain_loop /analysis/spectral_classifier
```

Expected guidance:

- Use `analysis.<tool_or_domain>` for tool-authored classifier metadata.
- Keep private feedback lifecycle records out of public asset metadata.
- Do not edit `/var/lib/soundclaw/library` or runtime `index.json` directly.
- Tell the operator that metadata changes need the asset-library validate and
  publish workflow before `soundclawctl library list` reflects them.
