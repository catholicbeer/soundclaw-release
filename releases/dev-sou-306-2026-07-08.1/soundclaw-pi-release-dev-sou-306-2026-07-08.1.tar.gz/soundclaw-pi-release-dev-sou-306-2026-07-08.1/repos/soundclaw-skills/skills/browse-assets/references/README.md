# Browse Assets

Purpose: Discover and disambiguate SoundClaw assets through the documented runtime CLI.

Runtime dependency:

- `soundclawctl library list [--json]`
- `soundclawctl library list --metadata-eq <json-pointer>=<json-value> [--json]`
- `soundclawctl library list --metadata-exists <json-pointer> [--json]`
- when needed for candidate inspection, `soundclawctl library show --asset <id> [--json]`

## Operator Job

This skill helps an operator browse the current SoundClaw asset library before
they know one exact asset id.

It should narrow vague requests such as "show me the choir beds" or "what rain
loops do we have?" into a short set of plausible assets, then hand the operator
to a known asset id for `show-asset` or `play-asset`.

Metadata browsing should stay on the runtime boundary. Use
`soundclawctl library list` metadata predicates for folder, notes, and
classifier discovery instead of reading `index.json` directly.

Metadata authoring belongs to the asset-library authoring boundary, not the
runtime boundary. When an operator-approved OpenClaw tool needs to update
public asset metadata, guide it to run `soundclaw-asset-library` commands from
that repo, such as:

```bash
python3 scripts/metadata.py --root . list rain_loop
python3 scripts/metadata.py --root . set rain_loop /notes '"Good dawn ambience"'
python3 scripts/metadata.py --root . set rain_loop /folder '"Garden"'
python3 scripts/metadata.py --root . set rain_loop /analysis/spectral_classifier '{"mood": "calm", "confidence": 0.82}'
python3 scripts/metadata.py --root . remove rain_loop /analysis/spectral_classifier
```

Use `analysis.<tool_or_domain>` for tool-authored classifier fields unless a
more specific public contract exists. Metadata changes must be validated and
published through the asset-library workflow before runtime discovery can
reflect them.

## Guardrails

- Use `library list` as the primary discovery surface.
- Use runtime metadata filters for folder, notes, and classifier browsing.
- Use `library show` only when one or a few candidates need deeper inspection.
- Keep the response focused on asset ids, known metadata, and the next useful step.
- Ask a short clarification question when multiple candidates still fit.
- Treat library lookup failures as runtime or data issues, not host repair work.
- Do not browse raw library files or expose file paths as the normal operator-facing surface.
- Do not mutate runtime JSON or edit `/var/lib/soundclaw/library` directly.
- Do not treat raw media paths as proof that an asset is playable or indexed.
- Do not store private feedback lifecycle records in public asset metadata.
- Do not start playback from this skill.
