# Compatibility

Operator job: Browse and disambiguate SoundClaw assets before an exact asset id is known.

Runtime dependency:

- Status: Pending current runtime release-line declaration for these promoted command shapes.
- Contract reference: `soundclaw/docs/runtime-spec.md`
- Command(s): `soundclawctl library list [--json]`
- Command(s): `soundclawctl library list --metadata-eq <json-pointer>=<json-value> [--json]`
- Command(s): `soundclawctl library list --metadata-exists <json-pointer> [--json]`
- Command(s): `soundclawctl library show --asset <id> [--json]`
- Asset-library authoring reference: `python3 scripts/metadata.py --root . <list|set|remove> ...` in `soundclaw-asset-library`
- Scope note: This skill owns browse-first discovery and disambiguation. Use `show-asset` when the operator already knows the exact asset id.
- Boundary note: Metadata mutation is guidance through the asset-library authoring boundary. Skills must not edit runtime JSON, mutate `/var/lib/soundclaw/library`, infer library membership from raw paths, or store private feedback lifecycle records in public asset metadata.

Minimum compatible runtime release line: Pending definition in `soundclaw-runtime`.

Tested runtime release line: Not yet validated against a promoted runtime release line.

Packaging target: Plain skill

ClawHub publication status: Not published
