# Show Asset Examples

## Example Requests

- "Show me the asset `forest-rain`."
- "Look up `storm-bed`."
- "What do we know about the rain loop?"

## Expected Skill Behavior

- Resolve the asset id or ask for clarification.
- Use the promoted library lookup command only.
- Keep the response focused on asset metadata and next steps.
