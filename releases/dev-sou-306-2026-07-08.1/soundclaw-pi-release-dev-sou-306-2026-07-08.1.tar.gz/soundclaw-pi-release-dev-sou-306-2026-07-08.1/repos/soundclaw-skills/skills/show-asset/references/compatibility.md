# Compatibility

Operator job: Inspect library information for a SoundClaw asset.

Runtime dependency:

- Status: Pending current runtime release-line declaration for this promoted command shape.
- Contract reference: `soundclaw/docs/runtime-spec.md`
- Command(s): `soundclawctl library show --asset <id> [--json]`
- Scope note: `browse-assets` owns browse-first discovery and disambiguation through `soundclawctl library list [--json]`; `show-asset` stays focused on one known asset id.

Minimum compatible runtime release line: Pending definition in `soundclaw-runtime`.

Tested runtime release line: Not yet validated against a promoted runtime release line.

Packaging target: Plain skill

ClawHub publication status: Not published
