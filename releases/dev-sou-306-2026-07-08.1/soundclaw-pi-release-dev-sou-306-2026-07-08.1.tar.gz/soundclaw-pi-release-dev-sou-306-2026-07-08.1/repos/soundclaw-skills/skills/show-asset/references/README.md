# Show Asset

Purpose: Inspect library information for a SoundClaw asset through the documented runtime CLI.

Runtime dependency: `soundclawctl library show --asset <id> [--json]`

## Operator Job

This skill helps an operator confirm the right asset id, inspect known asset metadata, or explain why a requested asset cannot be found.

It should keep the discussion in terms of assets rather than raw file paths or runtime-internal library details.
Browse-first discovery and disambiguation now belong to `browse-assets`, which
can use `soundclawctl library list [--json]` before handing a chosen id back to
`show-asset` or `play-asset`.

## Guardrails

- Ask for a clearer asset reference when needed.
- Keep the output focused on operator-relevant metadata.
- Treat library lookup failures as runtime or data issues, not host repair opportunities.
- Avoid inventing asset aliases that are not documented.
- Do not treat this skill as a library browser. Use `browse-assets` when the operator needs discovery or disambiguation before a known id exists.
