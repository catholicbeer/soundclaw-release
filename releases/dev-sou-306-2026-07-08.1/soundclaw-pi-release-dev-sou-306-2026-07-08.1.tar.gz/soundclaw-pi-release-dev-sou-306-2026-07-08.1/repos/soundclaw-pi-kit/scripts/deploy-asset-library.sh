#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# shellcheck source=../lib/pi-kit.sh
source "${SCRIPT_DIR}/../lib/pi-kit.sh"

SOURCE_DIR=""
RELEASE_REF=""

usage() {
  cat <<'EOF'
Usage: deploy-asset-library.sh --source /path/to/library-snapshot [--release-ref value] [--dry-run]

Copy a prepared asset-library snapshot into the host's library directory. The
source must contain index.json and an assets/ directory.
EOF
}

validate_library_source() {
  [[ -n "$SOURCE_DIR" ]] || die "--source is required"
  [[ -d "$SOURCE_DIR" ]] || die "library source directory does not exist: $SOURCE_DIR"
  [[ -f "${SOURCE_DIR%/}/index.json" ]] || die "library source must include index.json: $SOURCE_DIR"
  [[ -d "${SOURCE_DIR%/}/assets" ]] || die "library source must include assets/: $SOURCE_DIR"
}

write_library_state() {
  local state_file
  local deployed_at
  local library_index
  local library_assets

  state_file="$(root_path "$(library_deploy_state_path)")"
  deployed_at="$(timestamp_utc)"
  library_index="$(library_index_path)"
  library_assets="$(library_assets_dir)"

  write_text_file "$state_file" <<EOF
LIBRARY_SOURCE=${SOURCE_DIR@Q}
LIBRARY_RELEASE_REF=${RELEASE_REF@Q}
LIBRARY_DEPLOYED_AT=${deployed_at@Q}
LIBRARY_TARGET=${SC_LIBRARY_DIR@Q}
LIBRARY_INDEX_PATH=${library_index@Q}
LIBRARY_ASSETS_DIR=${library_assets@Q}
EOF
}

main() {
  local target_dir
  local candidate_dir
  local previous_dir
  while [[ $# -gt 0 ]]; do
    case "$1" in
      --source)
        [[ $# -ge 2 ]] || die "--source requires a value"
        SOURCE_DIR="$2"
        shift 2
        ;;
      --release-ref)
        [[ $# -ge 2 ]] || die "--release-ref requires a value"
        RELEASE_REF="$2"
        shift 2
        ;;
      --dry-run)
        DRY_RUN=1
        shift
        ;;
      --help|-h)
        usage
        exit 0
        ;;
      *)
        die "unknown argument: $1"
        ;;
    esac
  done

  validate_library_source

  if [[ -z "$RELEASE_REF" ]]; then
    RELEASE_REF="$(basename "$SOURCE_DIR")"
  fi

  require_root

  ensure_library_dir_access

  target_dir="$(root_path "${SC_LIBRARY_DIR}")"
  candidate_dir="${target_dir}.candidate.$$"
  previous_dir="${target_dir}.previous"
  info "staging validated asset-library snapshot from ${SOURCE_DIR}"
  run_cmd rm -rf "$candidate_dir" "$previous_dir"
  run_cmd mkdir -p "$candidate_dir"
  run_cmd rsync -a --delete "${SOURCE_DIR}/" "${candidate_dir}/"
  if [[ "$DRY_RUN" == "1" ]]; then
    run_cmd mv "$target_dir" "$previous_dir"
    run_cmd mv "$candidate_dir" "$target_dir"
    run_cmd rm -rf "$previous_dir"
  else
    if [[ -e "$target_dir" ]]; then
      mv "$target_dir" "$previous_dir"
    fi
    if ! mv "$candidate_dir" "$target_dir"; then
      [[ ! -e "$previous_dir" ]] || mv "$previous_dir" "$target_dir"
      die "asset library atomic promotion failed; previous snapshot restored"
    fi
    rm -rf "$previous_dir"
  fi
  normalize_library_permissions

  write_library_state

  info "asset library deploy complete"
}

main "$@"
