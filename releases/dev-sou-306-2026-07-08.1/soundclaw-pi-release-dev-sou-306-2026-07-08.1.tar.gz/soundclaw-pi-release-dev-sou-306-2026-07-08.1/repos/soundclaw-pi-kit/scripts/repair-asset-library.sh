#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=../lib/pi-kit.sh
source "${SCRIPT_DIR}/../lib/pi-kit.sh"

ASSET_LIBRARY_ROOT=""
ASSET_LIBRARY_REF=""
APPLY=0

while [[ $# -gt 0 ]]; do
  case "$1" in
    --asset-library-root) ASSET_LIBRARY_ROOT="$2"; shift 2 ;;
    --asset-library-ref) ASSET_LIBRARY_REF="$2"; shift 2 ;;
    --apply) APPLY=1; shift ;;
    --help|-h)
      echo "Usage: repair-asset-library.sh --asset-library-root PATH [--asset-library-ref REF] [--apply]"
      exit 0
      ;;
    *) die "unknown argument: $1" ;;
  esac
done

[[ -n "$ASSET_LIBRARY_ROOT" ]] || die "--asset-library-root is required"
[[ -f "${ASSET_LIBRARY_ROOT}/scripts/repair-index.py" ]] || die "asset-library repair tool is missing"
[[ -f "${ASSET_LIBRARY_ROOT}/scripts/validate-library.py" ]] || die "asset-library validator is missing"
require_root

library_root="$(root_path "$SC_LIBRARY_DIR")"
state_file="$(root_path "$(library_deploy_state_path)")"
backup_index="${library_root}/index.json.pre-utf8-repair"
repair_output="$(mktemp)"
TEMP_FILES=("$repair_output")
trap 'rm -f "${TEMP_FILES[@]}"' EXIT

repair_cmd=(env LC_ALL=C.UTF-8 LANG=C.UTF-8 python3 "${ASSET_LIBRARY_ROOT}/scripts/repair-index.py" --root "$library_root")
[[ "$APPLY" == "1" ]] && repair_cmd+=(--apply)

if [[ "$APPLY" == "1" ]]; then
  cp "${library_root}/index.json" "$backup_index"
fi
if ! "${repair_cmd[@]}" | tee "$repair_output"; then
  [[ "$APPLY" != "1" || ! -f "$backup_index" ]] || mv "$backup_index" "${library_root}/index.json"
  die "asset library repair failed"
fi
if [[ "$APPLY" == "1" ]]; then
  if ! env LC_ALL=C.UTF-8 LANG=C.UTF-8 python3 \
    "${ASSET_LIBRARY_ROOT}/scripts/validate-library.py" --root "$library_root"; then
    mv "$backup_index" "${library_root}/index.json"
    die "repaired library failed validation; previous index restored"
  fi
  rm -f "$backup_index"
  cat >>"$state_file" <<EOF
LIBRARY_REPAIR_ASSET_LIBRARY_REF=${ASSET_LIBRARY_REF@Q}
LIBRARY_REPAIR_COMPLETED_AT=$(timestamp_utc)
LIBRARY_REPAIR_RESULT='OK'
EOF
fi

grep -q '^result: OK$' "$repair_output" || die "repair tool did not report success"
echo "repair_mode: $([[ "$APPLY" == "1" ]] && echo apply || echo dry-run)"
echo "result: OK"
