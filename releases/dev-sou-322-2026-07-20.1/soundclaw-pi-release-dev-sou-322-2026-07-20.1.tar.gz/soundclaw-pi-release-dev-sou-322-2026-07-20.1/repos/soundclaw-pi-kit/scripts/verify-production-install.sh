#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# shellcheck source=../lib/pi-kit.sh
source "${SCRIPT_DIR}/../lib/pi-kit.sh"

MODE=""
WORKSPACE=""
EXPECTED_VERSION=""
SNAPSHOT_OUTPUT=""
BEFORE_SNAPSHOT=""
RELEASE_ID=""
BUNDLE_URL=""
BUNDLE_ASSET=""
BUNDLE_SHA256=""
LOGICAL_TARGET="honcho@SoundClaw"
EXPECTED_PHYSICAL_HOST=""
ASSET_ID=""
OUTPUT_ID=""
EVIDENCE_OUTPUT=""
RUNTIME_CTL=""
POLL_ATTEMPTS=10
declare -a TEMP_DIRS=()

cleanup_temp_dirs() {
  local status=$?
  local dir
  for dir in "${TEMP_DIRS[@]}"; do
    [[ -n "$dir" && -e "$dir" ]] || continue
    rm -rf "$dir" || status=$?
  done
  return "$status"
}

trap cleanup_temp_dirs EXIT

usage() {
  cat <<'EOF'
Usage:
  verify-production-install.sh snapshot --workspace PATH --expected-version VERSION --output FILE
  verify-production-install.sh verify --workspace PATH --before FILE --expected-version VERSION \
    --release-id ID --bundle-url URL --bundle-asset FILE --bundle-sha256 SHA256 \
    --asset ID --output-id ID --evidence-output FILE [options]

Snapshot and then verify the corrected production contract. The verifier fails
closed unless @catholicbeer/soundclaw ClawHub provenance is unchanged, the
backend is healthy, an approved real library asset exists, playback is observed
on the named logical output, and the same playback stops cleanly.

Options:
  --logical-target VALUE          Must be honcho@SoundClaw (default)
  --expected-physical-host NAME   Optional reported-host assertion (currently Suzu)
  --runtime-ctl PATH              Override the promoted soundclawctl executable
  --poll-attempts N               Playback/stop observation attempts (default 10)
EOF
}

snapshot_provenance() {
  local output_path="$1"

  python3 - "$WORKSPACE" "$EXPECTED_VERSION" "$output_path" <<'PY'
import datetime
import hashlib
import json
import pathlib
import sys

workspace = pathlib.Path(sys.argv[1]).resolve()
expected_version = sys.argv[2]
output = pathlib.Path(sys.argv[3])
product = "@catholicbeer/soundclaw"

lock = workspace / ".clawhub" / "lock.json"
product_dir = workspace / "skills" / "@catholicbeer" / "soundclaw"
origin = product_dir / ".clawhub" / "origin.json"
skill = product_dir / "SKILL.md"

for label, path in (("origin", origin), ("lock", lock), ("SKILL.md", skill)):
    if not path.is_file():
        raise SystemExit(f"missing ClawHub {label} evidence: {path}")

origin_bytes = origin.read_bytes()
lock_bytes = lock.read_bytes()
skill_bytes = skill.read_bytes()
try:
    origin_json = json.loads(origin_bytes)
    lock_json = json.loads(lock_bytes)
except json.JSONDecodeError as exc:
    raise SystemExit(f"invalid ClawHub JSON evidence: {exc}") from exc

skill_text = skill_bytes.decode("utf-8")

skills = lock_json.get("skills") if isinstance(lock_json, dict) else None
if not isinstance(skills, dict):
    raise SystemExit("ClawHub lock does not contain a skills mapping")
lock_entry = skills.get(product)
if not isinstance(lock_entry, dict):
    raise SystemExit(f"ClawHub lock is missing the exact product key {product}")
if str(lock_entry.get("version", "")) != expected_version:
    raise SystemExit(f"ClawHub lock does not identify {product} version {expected_version}")
if str(lock_entry.get("ownerHandle", "")).lower() != "catholicbeer":
    raise SystemExit("ClawHub lock owner does not match catholicbeer")

alternate_keys = []
for key in skills:
    lowered = str(key).lower()
    if lowered == product:
        continue
    if lowered == "soundclaw" or lowered.startswith("soundclaw-") or lowered.startswith("@catholicbeer/soundclaw-"):
        alternate_keys.append(str(key))
if alternate_keys:
    raise SystemExit(f"competing SoundClaw ClawHub identities are installed: {', '.join(sorted(alternate_keys))}")

alternate_paths = []
skills_dir = workspace / "skills"
for candidate in skills_dir.glob("soundclaw*"):
    if candidate.exists():
        alternate_paths.append(str(candidate))
owner_dir = skills_dir / "@catholicbeer"
if owner_dir.is_dir():
    for candidate in owner_dir.glob("soundclaw-*"):
        if candidate.exists():
            alternate_paths.append(str(candidate))
if alternate_paths:
    raise SystemExit(f"competing or shadowing SoundClaw skill paths are installed: {', '.join(sorted(alternate_paths))}")

if not isinstance(origin_json, dict):
    raise SystemExit("ClawHub origin metadata must be a JSON object")
origin_registry = str(origin_json.get("registry", "")).rstrip("/").lower()
origin_owner = str(origin_json.get("ownerHandle", origin_json.get("owner", ""))).lower()
origin_version = str(origin_json.get("installedVersion", origin_json.get("version", "")))
if origin_registry != "https://clawhub.ai":
    raise SystemExit("origin registry does not match https://clawhub.ai")
if origin_owner != "catholicbeer" or str(origin_json.get("slug", "")).lower() != "soundclaw":
    raise SystemExit(f"origin does not identify the exact product {product}")
if origin_version != expected_version:
    raise SystemExit(f"origin does not identify {product} version {expected_version}")
if "name: soundclaw" not in skill_text or f"version: {expected_version}" not in skill_text:
    raise SystemExit("installed SKILL.md identity/version does not match the expected product")

def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

snapshot = {
    "schema_version": 1,
    "kind": "soundclaw_clawhub_provenance",
    "product": product,
    "version": expected_version,
    "workspace": str(workspace),
    "lock_key": product,
    "install_dir": str(product_dir),
    "captured_at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "origin": {"path": str(origin), "sha256": sha(origin_bytes)},
    "lock": {"path": str(lock), "sha256": sha(lock_bytes)},
    "skill": {"path": str(skill), "sha256": sha(skill_bytes)},
}
output.parent.mkdir(parents=True, exist_ok=True)
output.write_text(json.dumps(snapshot, indent=2, sort_keys=True) + "\n", encoding="utf-8")
PY
}

resolve_runtime_ctl() {
  if [[ -n "$RUNTIME_CTL" ]]; then
    [[ -x "$RUNTIME_CTL" ]] || die "runtime control executable is not executable: $RUNTIME_CTL"
    return 0
  fi

  if command_exists soundclawctl; then
    RUNTIME_CTL="$(command -v soundclawctl)"
    return 0
  fi

  RUNTIME_CTL="$(root_path /opt/soundclaw/runtime/current/bin/soundclawctl)"
  [[ -x "$RUNTIME_CTL" ]] || die "soundclawctl is unavailable on PATH and at the stable runtime path"
}

json_has_active_playback() {
  python3 - "$1" "$ASSET_ID" "$OUTPUT_ID" <<'PY'
import json
import sys

data = json.load(open(sys.argv[1], encoding="utf-8"))
asset, output = sys.argv[2:4]
status = data.get("status", data) if isinstance(data, dict) else {}
playback = status.get("playback") if isinstance(status, dict) else None
if not isinstance(playback, dict):
    raise SystemExit(1)
text = json.dumps(playback, sort_keys=True)
if asset not in text or output not in text:
    raise SystemExit(1)
PY
}

json_has_stopped_playback() {
  python3 - "$1" <<'PY'
import json
import sys

data = json.load(open(sys.argv[1], encoding="utf-8"))
status = data.get("status", data) if isinstance(data, dict) else {}
playback = status.get("playback") if isinstance(status, dict) else None
if playback is None:
    raise SystemExit(0)
if isinstance(playback, dict) and str(playback.get("state", "")).lower() in {"idle", "stopped", "complete", "completed"}:
    raise SystemExit(0)
raise SystemExit(1)
PY
}

validate_args() {
  [[ "$MODE" == snapshot || "$MODE" == verify ]] || die "first argument must be snapshot or verify"
  [[ -d "$WORKSPACE" ]] || die "OpenClaw workspace does not exist: $WORKSPACE"
  [[ -n "$EXPECTED_VERSION" ]] || die "--expected-version is required"

  if [[ "$MODE" == snapshot ]]; then
    [[ -n "$SNAPSHOT_OUTPUT" ]] || die "--output is required for snapshot"
    [[ "$SNAPSHOT_OUTPUT" == /* ]] || die "--output must be an absolute path"
    return 0
  fi

  [[ -f "$BEFORE_SNAPSHOT" ]] || die "before-provenance snapshot is missing: $BEFORE_SNAPSHOT"
  [[ -n "$RELEASE_ID" ]] || die "--release-id is required"
  [[ -n "$BUNDLE_URL" ]] || die "--bundle-url is required"
  [[ -n "$BUNDLE_ASSET" ]] || die "--bundle-asset is required"
  [[ "$BUNDLE_SHA256" =~ ^[[:xdigit:]]{64}$ ]] || die "--bundle-sha256 must be 64 hexadecimal characters"
  [[ "$LOGICAL_TARGET" == "honcho@SoundClaw" ]] || die "logical production target must be honcho@SoundClaw"
  [[ -n "$ASSET_ID" ]] || die "--asset is required"
  [[ -n "$OUTPUT_ID" ]] || die "--output-id is required"
  [[ -n "$EVIDENCE_OUTPUT" ]] || die "--evidence-output is required"
  [[ "$EVIDENCE_OUTPUT" == /* ]] || die "--evidence-output must be an absolute path"
  [[ "$POLL_ATTEMPTS" =~ ^[1-9][0-9]*$ ]] || die "--poll-attempts must be a positive integer"
  if is_live_root && [[ -n "$RUNTIME_CTL" ]]; then
    die "--runtime-ctl is test-only and forbidden on the live production root"
  fi

  local expected_url="https://github.com/catholicbeer/soundclaw-release/releases/download/release-bundle-${RELEASE_ID}/soundclaw-pi-release-${RELEASE_ID}.tar.gz"
  [[ "$BUNDLE_URL" == "$expected_url" ]] || die "bundle URL is not the exact canonical public GitHub release asset"
  [[ "$BUNDLE_ASSET" == "soundclaw-pi-release-${RELEASE_ID}.tar.gz" ]] || die "bundle asset does not match the release id"
}

verify_install() {
  local temp_dir
  local after_snapshot
  local status_before
  local library_json
  local play_json
  local active_status
  local stop_json
  local stopped_status
  local physical_host
  local setup_state
  local attempt
  local observed_active=0
  local observed_stopped=0

  temp_dir="$(mktemp -d)"
  TEMP_DIRS+=("$temp_dir")
  after_snapshot="${temp_dir}/after.json"
  status_before="${temp_dir}/status-before.json"
  library_json="${temp_dir}/library.json"
  play_json="${temp_dir}/play.json"
  active_status="${temp_dir}/status-active.json"
  stop_json="${temp_dir}/stop.json"
  stopped_status="${temp_dir}/status-stopped.json"

  snapshot_provenance "$after_snapshot"
  python3 - "$BEFORE_SNAPSHOT" "$after_snapshot" <<'PY'
import json
import sys

before = json.load(open(sys.argv[1], encoding="utf-8"))
after = json.load(open(sys.argv[2], encoding="utf-8"))
for key in ("product", "version"):
    if before.get(key) != after.get(key):
        raise SystemExit(f"ClawHub provenance changed: {key}")
for key in ("origin", "lock", "skill"):
    if before.get(key, {}).get("sha256") != after.get(key, {}).get("sha256"):
        raise SystemExit(f"ClawHub provenance changed: {key} sha256")
PY

  physical_host="$(hostname 2>/dev/null || uname -n)"
  [[ -z "$EXPECTED_PHYSICAL_HOST" || "${physical_host,,}" == "${EXPECTED_PHYSICAL_HOST,,}" ]] || die \
    "physical host mismatch: expected ${EXPECTED_PHYSICAL_HOST}, found ${physical_host}"

  setup_state="$(root_path "$(setup_run_state_path)")"
  [[ -f "$setup_state" ]] || die "backend setup evidence is missing: $setup_state"
  if grep -q '^SETUP_SKILLS_' "$setup_state"; then
    die "backend setup evidence contains forbidden skills metadata"
  fi

  resolve_runtime_ctl
  "$RUNTIME_CTL" runtime status --json >"$status_before"
  "$RUNTIME_CTL" library list --json >"$library_json"

  python3 - "$status_before" "$library_json" "$ASSET_ID" <<'PY'
import json
import sys

status = json.load(open(sys.argv[1], encoding="utf-8"))
library = json.load(open(sys.argv[2], encoding="utf-8"))
asset = sys.argv[3]

def values_for_key(value, key):
    if isinstance(value, dict):
        for k, item in value.items():
            if k == key:
                yield item
            yield from values_for_key(item, key)
    elif isinstance(value, list):
        for item in value:
            yield from values_for_key(item, key)

if "running" not in {str(v).lower() for v in values_for_key(status, "kind")}:
    raise SystemExit("runtime is not running")
for key in ("device_available", "asset_library_ready", "backend_ready"):
    if True not in list(values_for_key(status, key)):
        raise SystemExit(f"runtime health is not ready: {key}")
assets = next((v for v in values_for_key(library, "assets") if isinstance(v, list) and v), None)
if not assets:
    raise SystemExit("approved real library is empty")
if not any(isinstance(item, dict) and str(item.get("id")) == asset for item in assets):
    raise SystemExit(f"named real asset is absent from the library: {asset}")
PY

  "$RUNTIME_CTL" playback play --asset "$ASSET_ID" --output "$OUTPUT_ID" --json >"$play_json"
  for ((attempt = 1; attempt <= POLL_ATTEMPTS; attempt += 1)); do
    "$RUNTIME_CTL" runtime status --json >"$active_status"
    if json_has_active_playback "$active_status"; then
      observed_active=1
      break
    fi
    sleep 1
  done

  "$RUNTIME_CTL" playback stop --output "$OUTPUT_ID" --json >"$stop_json" || true
  [[ "$observed_active" == "1" ]] || die "playback was not observed for the named asset/output"

  for ((attempt = 1; attempt <= POLL_ATTEMPTS; attempt += 1)); do
    "$RUNTIME_CTL" runtime status --json >"$stopped_status"
    if json_has_stopped_playback "$stopped_status"; then
      observed_stopped=1
      break
    fi
    sleep 1
  done
  [[ "$observed_stopped" == "1" ]] || die "playback did not stop cleanly"

  python3 - \
    "$BEFORE_SNAPSHOT" "$after_snapshot" "$setup_state" "$status_before" \
    "$library_json" "$play_json" "$active_status" "$stop_json" "$stopped_status" \
    "$EXPECTED_VERSION" "$RELEASE_ID" "$BUNDLE_URL" "$BUNDLE_ASSET" "$BUNDLE_SHA256" \
    "$LOGICAL_TARGET" "$physical_host" "$ASSET_ID" "$OUTPUT_ID" "$EVIDENCE_OUTPUT" <<'PY'
import datetime
import json
import pathlib
import shlex
import sys

(
    before_path, after_path, setup_path, status_path, library_path,
    play_path, active_path, stop_path, stopped_path, version, release_id,
    bundle_url, bundle_asset, bundle_sha, logical_target, physical_host,
    asset_id, output_id, evidence_path,
) = sys.argv[1:]

def load_json(path):
    return json.load(open(path, encoding="utf-8"))

def parse_env(path):
    values = {}
    for raw in pathlib.Path(path).read_text(encoding="utf-8").splitlines():
        if not raw or raw.lstrip().startswith("#") or "=" not in raw:
            continue
        key, value = raw.split("=", 1)
        parsed = shlex.split(value, posix=True)
        values[key] = parsed[0] if parsed else ""
    return values

setup = parse_env(setup_path)
expected_setup = {
    "SETUP_PUBLIC_RELEASE_ID": release_id,
    "SETUP_PUBLIC_BUNDLE_SOURCE": bundle_url,
    "SETUP_PUBLIC_BUNDLE_ASSET": bundle_asset,
}
for key, expected in expected_setup.items():
    if setup.get(key) != expected:
        raise SystemExit(f"backend setup evidence mismatch: {key}")

library = load_json(library_path)

def values_for_key(value, key):
    if isinstance(value, dict):
        for item_key, item in value.items():
            if item_key == key:
                yield item
            yield from values_for_key(item, key)
    elif isinstance(value, list):
        for item in value:
            yield from values_for_key(item, key)

assets = next((value for value in values_for_key(library, "assets") if isinstance(value, list) and value), [])
evidence = {
    "schema_version": 1,
    "kind": "soundclaw_production_install_verification",
    "result": "PASS",
    "verified_at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "product": {
        "identity": "@catholicbeer/soundclaw",
        "version": version,
        "before": load_json(before_path),
        "after": load_json(after_path),
        "unchanged": True,
    },
    "backend": {
        "release_id": release_id,
        "bundle_url": bundle_url,
        "bundle_asset": bundle_asset,
        "bundle_sha256": bundle_sha.lower(),
        "manifest_sha256": setup.get("SETUP_PUBLIC_MANIFEST_SHA256", ""),
        "checksums_sha256": setup.get("SETUP_PUBLIC_CHECKSUMS_SHA256", ""),
        "source_tuple": setup.get("SETUP_PUBLIC_SOURCE_TUPLE", ""),
    },
    "target": {"logical": logical_target, "physical_hostname": physical_host},
    "health": load_json(status_path),
    "library": {"asset_count": len(assets), "verified_asset_id": asset_id},
    "playback": {
        "output_id": output_id,
        "play_ack": load_json(play_path),
        "observed_active": load_json(active_path),
        "stop_ack": load_json(stop_path),
        "observed_stopped": load_json(stopped_path),
    },
}
output = pathlib.Path(evidence_path)
output.parent.mkdir(parents=True, exist_ok=True)
output.write_text(json.dumps(evidence, indent=2, sort_keys=True) + "\n", encoding="utf-8")
print(json.dumps(evidence, sort_keys=True))
PY
  [[ -s "$EVIDENCE_OUTPUT" ]] || die "production verification evidence was not retained"
}

main() {
  MODE="${1:-}"
  [[ $# -gt 0 ]] && shift

  while [[ $# -gt 0 ]]; do
    case "$1" in
      --workspace) WORKSPACE="${2:?--workspace requires a value}"; shift 2 ;;
      --expected-version) EXPECTED_VERSION="${2:?--expected-version requires a value}"; shift 2 ;;
      --output) SNAPSHOT_OUTPUT="${2:?--output requires a value}"; shift 2 ;;
      --before) BEFORE_SNAPSHOT="${2:?--before requires a value}"; shift 2 ;;
      --release-id) RELEASE_ID="${2:?--release-id requires a value}"; shift 2 ;;
      --bundle-url) BUNDLE_URL="${2:?--bundle-url requires a value}"; shift 2 ;;
      --bundle-asset) BUNDLE_ASSET="${2:?--bundle-asset requires a value}"; shift 2 ;;
      --bundle-sha256) BUNDLE_SHA256="${2:?--bundle-sha256 requires a value}"; shift 2 ;;
      --logical-target) LOGICAL_TARGET="${2:?--logical-target requires a value}"; shift 2 ;;
      --expected-physical-host) EXPECTED_PHYSICAL_HOST="${2:?--expected-physical-host requires a value}"; shift 2 ;;
      --asset) ASSET_ID="${2:?--asset requires a value}"; shift 2 ;;
      --output-id) OUTPUT_ID="${2:?--output-id requires a value}"; shift 2 ;;
      --evidence-output) EVIDENCE_OUTPUT="${2:?--evidence-output requires a value}"; shift 2 ;;
      --runtime-ctl) RUNTIME_CTL="${2:?--runtime-ctl requires a value}"; shift 2 ;;
      --poll-attempts) POLL_ATTEMPTS="${2:?--poll-attempts requires a value}"; shift 2 ;;
      --help|-h) usage; exit 0 ;;
      *) die "unknown argument: $1" ;;
    esac
  done

  validate_args
  if [[ "$MODE" == snapshot ]]; then
    snapshot_provenance "$SNAPSHOT_OUTPUT"
    cat "$SNAPSHOT_OUTPUT"
    return 0
  fi
  verify_install
}

main "$@"
