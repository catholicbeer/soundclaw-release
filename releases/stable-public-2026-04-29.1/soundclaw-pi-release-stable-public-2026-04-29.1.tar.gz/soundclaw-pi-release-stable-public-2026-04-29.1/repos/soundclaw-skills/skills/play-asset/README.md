# Play Asset

Purpose: Resolve a SoundClaw asset and logical output, then request playback through the documented `soundclawctl` surface.

Runtime dependency:

- `soundclawctl playback play --asset <id> --output <id> [--fade-in-ms <n>] [--json]`
- when needed for resolution, `soundclawctl outputs list [--json]`
- when needed for resolution, `soundclawctl outputs show --output <id> [--json]`
- when needed for runtime-owned deployment defaults such as `default_output`, `soundclawctl config defaults [--json]`

## Operator Job

This skill handles the operator workflow for starting playback of a known asset on a named logical output.

It should help the operator get from an understandable request such as "play forest-rain on main" to a safe runtime call without exposing runtime-internal details such as file paths or raw hardware channels.

In MVP, logical outputs should be treated as named presentation layouts such as `main`, `perimeter-wide-4`, or `all-speakers-10`, not assumed to be guest-facing geographic zones.
Selecting one logical output may still mean one asset is presented across many destination channels in sync; it does not imply multiple independent playback instances are already supported.

## Guardrails

- Ask for clarification when the asset or output is ambiguous.
- Use runtime-owned discovery commands when the operator omitted output selection and the deployment defines defaults.
- Treat the selected logical output's ordered destination-channel layout and runtime-owned route plan as authoritative rather than inventing channel remaps locally.
- Use `soundclawctl outputs show --output <id> [--json]` when you need to explain or inspect an output's declared layout, but do not make correctness depend on that preflight.
- If the runtime reports a shape mismatch or output-selection problem, surface that failure clearly and say the runtime contract for the chosen output was not satisfied.
- Accept optional fade-in input, but do not invent values the operator did not request.
- Treat runtime unavailability as a runtime-layer issue rather than pretending the host was repaired.
- Do not bypass `soundclawctl`.
