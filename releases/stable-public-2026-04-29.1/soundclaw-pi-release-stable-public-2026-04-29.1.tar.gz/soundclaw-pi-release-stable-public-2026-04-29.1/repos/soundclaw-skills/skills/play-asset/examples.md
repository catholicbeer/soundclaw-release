# Play Asset Examples

## Example Requests

- "Play `forest-rain` on `main`."
- "Start `garden-bed-10ch` on `all-speakers-10` with a 2 second fade in."
- "Play `soft-music` on `perimeter-wide-4`."
- "Play `forest-rain`."

## Expected Skill Behavior

- Resolve the requested asset and output without exposing file paths.
- Consult runtime-owned defaults when output selection was omitted and a default exists.
- Ask for clarification if a requested output layout is ambiguous or missing.
- Treat the selected logical output's ordered destination-channel layout and runtime-owned route plan as authoritative rather than inventing channel remaps locally.
- If the runtime rejects the requested output shape or route plan, explain that failure clearly instead of hiding it.
- On success, confirm what is playing and where.
- On failure, name the runtime problem clearly instead of implying host repair.
