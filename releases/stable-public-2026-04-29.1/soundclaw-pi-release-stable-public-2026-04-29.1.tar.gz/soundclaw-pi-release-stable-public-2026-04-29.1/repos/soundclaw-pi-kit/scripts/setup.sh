#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# shellcheck source=../lib/pi-kit.sh
source "${SCRIPT_DIR}/../lib/pi-kit.sh"

PROFILE="$DEFAULT_PROFILE"
SKIP_PACKAGES=0
ALLOW_NO_AUDIO=0
RUNTIME_SOURCE=""
RUNTIME_RELEASE_REF=""
RUNTIME_CONFIG_SOURCE=""
RUNTIME_CONFIG_REF=""
RUNTIME_SELECTOR_OVERRIDE=""
RESOLVED_RUNTIME_SELECTOR=""
RESOLVED_RUNTIME_SELECTOR_SOURCE=""
LIBRARY_MODE=""
LIBRARY_SOURCE=""
LIBRARY_RELEASE_REF=""
LIBRARY_PROMOTION_SOURCE=""
ASSET_LIBRARY_ROOT=""
ASSET_LIBRARY_REF_OVERRIDE=""
LIBRARY_IMPORT_SOURCE=""
LIBRARY_IMPORT_COPY=0
SKILLS_SOURCE=""
SKILLS_REF=""
SKILLS_TARGET="$SC_SKILLS_DIR"
PI_KIT_REF_OVERRIDE=""
PUBLIC_RELEASE_ID=""
PUBLIC_BUNDLE_SOURCE=""
PUBLIC_BUNDLE_ASSET=""
PUBLIC_MANIFEST_SHA256=""
PUBLIC_CHECKSUMS_SHA256=""
PUBLIC_SOURCE_TUPLE=""
declare -a REQUESTED_SKILLS=()
declare -a SELECTED_SKILLS=()
declare -a TEMP_DIRS=()

cleanup_temp_dirs() {
  local dir

  for dir in "${TEMP_DIRS[@]}"; do
    [[ -n "$dir" ]] || continue
    [[ -e "$dir" ]] || continue
    rm -rf "$dir"
  done
}

trap cleanup_temp_dirs EXIT

usage() {
  cat <<'EOF'
Usage: setup.sh --runtime-source /path/to/staged-runtime --runtime-config /path/to/runtime.toml (--library-source /path/to/library-state | --asset-library-root /path/to/soundclaw-asset-library --library-import-source /path/to/local-library) --skills-source /path/to/soundclaw-skills --skills-ref value [options]

Run the first supported end-to-end SoundClaw setup flow on a Pi by:
- installing or repairing the host baseline
- installing the chosen runtime config
- deploying a staged runtime artifact
- either promoting an already-prepared runtime-facing library state or importing
  local media through a soundclaw-asset-library checkout before promotion
- syncing selected SoundClaw skills into a target skills directory

Options:
  --profile shared|exclusive          Host profile to install first
  --skip-packages                     Skip apt installation during install.sh
  --allow-no-audio                    Allow the install smoke test to pass without an ALSA device
  --runtime-source PATH               Staged soundclaw-runtime directory to deploy
  --runtime-release-ref VALUE         Recorded runtime ref; defaults to the runtime source basename
  --runtime-config PATH               Runtime config file to install as /etc/soundclaw/runtime.toml
  --runtime-config-ref VALUE          Recorded runtime config variant; defaults to the config filename
  --runtime-selector VALUE            Override the runtime ALSA selector written into /etc/soundclaw/runtime.toml
  --library-source PATH               Runtime-facing library directory to promote
  --library-release-ref VALUE         Recorded promoted library ref/name; defaults to the library source basename or import-<source-dir>
  --asset-library-root PATH           Local soundclaw-asset-library checkout used for import/publish orchestration
  --asset-library-ref VALUE           Override the recorded soundclaw-asset-library ref when Git metadata is unavailable
  --library-import-source PATH        Local media folder to import through soundclaw-asset-library before promotion
  --library-import-copy               Preserve imported source files instead of moving them into the managed library root
  --skills-source PATH                Staged soundclaw-skills checkout or clean synced tree
  --skills-ref VALUE                  Exact Git ref being installed from the staged skills source
  --skills-target PATH                Absolute target path for installed skills; defaults to /opt/soundclaw/skills
  --skill NAME                        Install one skill directory from skills/; repeat to limit the synced set
  --pi-kit-ref VALUE                  Override the recorded soundclaw-pi-kit ref when Git metadata is unavailable
  --public-release-id VALUE           Record the public release id that supplied this setup
  --public-bundle-source VALUE        Record the public bundle URL or local archive path used
  --public-bundle-asset VALUE         Record the public bundle asset filename
  --public-manifest-sha256 VALUE      Record the verified manifest.env sha256
  --public-checksums-sha256 VALUE     Record the verified checksums.txt sha256
  --public-source-tuple VALUE         Record the source tuple carried by the public bundle
  --dry-run                           Print the actions without mutating the host; supported only with --library-source
EOF
}

join_by() {
  local delimiter="$1"
  local item
  shift

  if [[ $# -eq 0 ]]; then
    return 0
  fi

  printf '%s' "$1"
  shift

  for item in "$@"; do
    printf '%s%s' "$delimiter" "$item"
  done
}

resolve_repo_ref() {
  local repo_path="$1"
  local ref_override="$2"
  local repo_label="$3"
  local detected_ref=""

  if [[ -n "$ref_override" ]]; then
    printf '%s\n' "$ref_override"
    return 0
  fi

  if command_exists git; then
    detected_ref="$(git -C "$repo_path" rev-parse HEAD 2>/dev/null || true)"

    if [[ -n "$detected_ref" ]]; then
      printf '%s\n' "$detected_ref"
      return 0
    fi
  fi

  if [[ -d "${repo_path%/}/.git" ]]; then
    warn "could not resolve a Git ref for ${repo_label} at ${repo_path}; recording 'unknown' in setup evidence"
  fi

  printf 'unknown\n'
}

resolve_pi_kit_ref() {
  resolve_repo_ref "$(repo_root)" "$PI_KIT_REF_OVERRIDE" "soundclaw-pi-kit"
}

asset_library_script_path() {
  printf '%s\n' "${ASSET_LIBRARY_ROOT%/}/scripts/$1"
}

default_library_release_ref() {
  local source_basename

  if [[ "$LIBRARY_MODE" == "promotion" ]]; then
    printf '%s\n' "$(basename "$LIBRARY_SOURCE")"
    return 0
  fi

  source_basename="$(basename "$LIBRARY_IMPORT_SOURCE")"
  [[ -n "$source_basename" ]] || source_basename="library-import"
  printf 'import-%s\n' "$source_basename"
}

validate_inputs() {
  [[ -n "$RUNTIME_SOURCE" ]] || die "--runtime-source is required"
  [[ -d "$RUNTIME_SOURCE" ]] || die "runtime source directory does not exist: $RUNTIME_SOURCE"

  [[ -n "$RUNTIME_CONFIG_SOURCE" ]] || die "--runtime-config is required"
  [[ -f "$RUNTIME_CONFIG_SOURCE" ]] || die "runtime config file does not exist: $RUNTIME_CONFIG_SOURCE"

  if [[ -n "$LIBRARY_SOURCE" ]]; then
    [[ -z "$ASSET_LIBRARY_ROOT" ]] || die \
      "choose either --library-source or --asset-library-root/--library-import-source"
    [[ -z "$LIBRARY_IMPORT_SOURCE" ]] || die \
      "choose either --library-source or --asset-library-root/--library-import-source"
    [[ "$LIBRARY_IMPORT_COPY" == "0" ]] || die \
      "--library-import-copy requires --asset-library-root and --library-import-source"
    [[ -z "$ASSET_LIBRARY_REF_OVERRIDE" ]] || die \
      "--asset-library-ref requires --asset-library-root and --library-import-source"
    [[ -d "$LIBRARY_SOURCE" ]] || die "library source directory does not exist: $LIBRARY_SOURCE"
    LIBRARY_MODE="promotion"
  else
    [[ -n "$ASSET_LIBRARY_ROOT" || -n "$LIBRARY_IMPORT_SOURCE" ]] || die \
      "either --library-source or --asset-library-root plus --library-import-source is required"
    [[ -n "$ASSET_LIBRARY_ROOT" ]] || die \
      "--asset-library-root is required with --library-import-source"
    [[ -n "$LIBRARY_IMPORT_SOURCE" ]] || die \
      "--library-import-source is required with --asset-library-root"
    [[ -d "$ASSET_LIBRARY_ROOT" ]] || die \
      "asset-library root directory does not exist: $ASSET_LIBRARY_ROOT"
    [[ -d "$LIBRARY_IMPORT_SOURCE" ]] || die \
      "library import source directory does not exist: $LIBRARY_IMPORT_SOURCE"
    [[ -f "$(asset_library_script_path import-assets.py)" ]] || die \
      "asset-library root is missing scripts/import-assets.py: $ASSET_LIBRARY_ROOT"
    [[ -f "$(asset_library_script_path publish-library.py)" ]] || die \
      "asset-library root is missing scripts/publish-library.py: $ASSET_LIBRARY_ROOT"
    [[ -f "$(asset_library_script_path validate-library.py)" ]] || die \
      "asset-library root is missing scripts/validate-library.py: $ASSET_LIBRARY_ROOT"
    command_exists python3 || die \
      "python3 is required when using --asset-library-root and --library-import-source"
    [[ "$DRY_RUN" == "0" ]] || die \
      "--dry-run is not supported with --asset-library-root and --library-import-source"
    LIBRARY_MODE="import"
  fi

  [[ -n "$SKILLS_SOURCE" ]] || die "--skills-source is required"
  [[ -d "$SKILLS_SOURCE" ]] || die "skills source directory does not exist: $SKILLS_SOURCE"
  [[ -d "${SKILLS_SOURCE%/}/skills" ]] || die \
    "skills source must contain a skills/ directory: $SKILLS_SOURCE"

  [[ -n "$SKILLS_REF" ]] || die "--skills-ref is required"
  [[ "$SKILLS_TARGET" == /* ]] || die "--skills-target must be an absolute path: $SKILLS_TARGET"
}

discover_installable_skills() {
  local skills_root="${SKILLS_SOURCE%/}/skills"
  local skill_dir
  local skill_name
  local -a discovered=()

  while IFS= read -r skill_dir; do
    skill_name="$(basename "$skill_dir")"
    [[ "$skill_name" == _* ]] && continue
    [[ -f "${skill_dir}/skill.toml" ]] || continue
    discovered+=("$skill_name")
  done < <(find "$skills_root" -mindepth 1 -maxdepth 1 -type d | sort)

  [[ ${#discovered[@]} -gt 0 ]] || return 0
  printf '%s\n' "${discovered[@]}"
}

resolve_selected_skills() {
  local skill_name
  local skill_dir
  local -a discovered=()

  mapfile -t discovered < <(discover_installable_skills)

  if [[ ${#REQUESTED_SKILLS[@]} -eq 0 ]]; then
    [[ ${#discovered[@]} -gt 0 ]] || die \
      "no installable skills were found under ${SKILLS_SOURCE%/}/skills"
    SELECTED_SKILLS=("${discovered[@]}")
    return 0
  fi

  for skill_name in "${REQUESTED_SKILLS[@]}"; do
    [[ "$skill_name" == _* ]] && die \
      "refusing to install hidden or template skill directory: $skill_name"
    skill_dir="${SKILLS_SOURCE%/}/skills/${skill_name}"
    [[ -d "$skill_dir" ]] || die "requested skill directory does not exist: $skill_dir"
    [[ -f "${skill_dir}/skill.toml" ]] || die \
      "requested skill does not look installable (missing skill.toml): $skill_dir"
    SELECTED_SKILLS+=("$skill_name")
  done
}

install_runtime_config() {
  local runtime_config_target

  runtime_config_target="$(root_path "$(runtime_config_path)")"

  resolve_runtime_selector

  info "installing runtime config from ${RUNTIME_CONFIG_SOURCE} to ${runtime_config_target}"
  info "using runtime selector ${RESOLVED_RUNTIME_SELECTOR} (${RESOLVED_RUNTIME_SELECTOR_SOURCE})"

  ensure_dir "$SC_CONFIG_DIR"
  write_runtime_config_with_selector \
    "$RUNTIME_CONFIG_SOURCE" \
    "$runtime_config_target" \
    "$RESOLVED_RUNTIME_SELECTOR"

  normalize_runtime_config_permissions
}

extract_runtime_selector_from_config() {
  local config_path="$1"
  local selector=""

  selector="$(awk '
    /^[[:space:]]*selector[[:space:]]*=/ {
      line = $0
      sub(/^[[:space:]]*selector[[:space:]]*=[[:space:]]*"/, "", line)
      sub(/".*$/, "", line)
      print line
      exit
    }
  ' "$config_path")"

  [[ -n "$selector" ]] || die \
    "runtime config is missing a selector entry and setup could not derive one: ${config_path}"

  printf '%s\n' "$selector"
}

list_alsa_playback_card_ids() {
  local audio_output

  command_exists aplay || return 1

  audio_output="$(aplay -l 2>&1 || true)"

  awk '
    /^card [0-9]+:/ {
      card_id = $3
      sub(/:$/, "", card_id)
      if (!(card_id in seen)) {
        seen[card_id] = 1
        print card_id
      }
    }
  ' <<<"$audio_output"
}

resolve_runtime_selector() {
  local config_selector=""
  local preferred_card_id="${PREFERRED_ALSA_CARD_ID:-}"
  local selector_scheme="${PREFERRED_ALSA_SELECTOR_SCHEME:-plughw}"
  local card_id=""
  local -a detected_cards=()

  [[ -n "$RESOLVED_RUNTIME_SELECTOR" ]] && return 0

  if [[ -n "$RUNTIME_SELECTOR_OVERRIDE" ]]; then
    RESOLVED_RUNTIME_SELECTOR="$RUNTIME_SELECTOR_OVERRIDE"
    RESOLVED_RUNTIME_SELECTOR_SOURCE="operator override"
    return 0
  fi

  config_selector="$(extract_runtime_selector_from_config "$RUNTIME_CONFIG_SOURCE")"

  if mapfile -t detected_cards < <(list_alsa_playback_card_ids); then
    if [[ ${#detected_cards[@]} -eq 0 ]]; then
      die "aplay -l did not report any ALSA playback devices; rerun setup with audio hardware attached or pass --runtime-selector"
    fi

    if [[ -n "$preferred_card_id" ]]; then
      for card_id in "${detected_cards[@]}"; do
        if [[ "$card_id" == "$preferred_card_id" ]]; then
          RESOLVED_RUNTIME_SELECTOR="${selector_scheme}:${card_id}"
          RESOLVED_RUNTIME_SELECTOR_SOURCE="ALSA probe matched preferred card ${card_id}"
          return 0
        fi
      done
    fi

    if [[ ${#detected_cards[@]} -eq 1 ]]; then
      RESOLVED_RUNTIME_SELECTOR="${selector_scheme}:${detected_cards[0]}"
      RESOLVED_RUNTIME_SELECTOR_SOURCE="ALSA probe matched the only visible playback card ${detected_cards[0]}"
      return 0
    fi

    die "multiple ALSA playback cards were detected (${detected_cards[*]}); rerun setup with --runtime-selector to choose the intended device explicitly"
  fi

  if ! is_live_root; then
    RESOLVED_RUNTIME_SELECTOR="$config_selector"
    RESOLVED_RUNTIME_SELECTOR_SOURCE="existing runtime config selector in non-live verification mode"
    return 0
  fi

  die "aplay is required to choose a runtime selector on a live host; install alsa-utils or pass --runtime-selector"
}

write_runtime_config_with_selector() {
  local source_path="$1"
  local target_path="$2"
  local selector="$3"
  local temp_path

  if [[ "$DRY_RUN" == "1" ]]; then
    info "[dry-run] render ${target_path} with selector ${selector}"
    return 0
  fi

  temp_path="$(mktemp)"

  awk -v selector="$selector" '
    BEGIN {
      replaced = 0
    }
    /^[[:space:]]*selector[[:space:]]*=/ {
      print "selector = \"" selector "\""
      replaced = 1
      next
    }
    {
      print
    }
    END {
      if (!replaced) {
        print "selector = \"" selector "\""
      }
    }
  ' "$source_path" >"$temp_path"

  mkdir -p "$(dirname "$target_path")"
  mv "$temp_path" "$target_path"
}

skills_target_owner() {
  local target_path
  local owner_path

  target_path="$(root_path "$SKILLS_TARGET")"

  if [[ -e "$target_path" ]] && [[ ! -d "$target_path" ]]; then
    die "skills target is not a directory: ${SKILLS_TARGET}"
  fi

  if [[ -e "$target_path" ]]; then
    owner_path="$target_path"
  else
    owner_path="$(dirname "$target_path")"
    [[ -d "$owner_path" ]] || die \
      "skills target parent directory does not exist: $(dirname "$SKILLS_TARGET")"
  fi

  stat -c '%u:%g' "$owner_path"
}

sync_skills() {
  local target_path
  local target_owner=""
  local target_parent
  local skill_name
  local source_path
  local skill_target

  target_path="$(root_path "$SKILLS_TARGET")"

  if is_live_root; then
    target_parent="$(dirname "$target_path")"

    if [[ "$DRY_RUN" == "1" ]] && [[ ! -d "$target_parent" ]]; then
      target_owner="root:root"
    else
      target_owner="$(skills_target_owner)"
    fi
  fi

  info "syncing ${#SELECTED_SKILLS[@]} skill(s) into ${target_path}"
  run_cmd mkdir -p "$target_path"

  if [[ -n "$target_owner" ]]; then
    run_cmd chown "$target_owner" "$target_path"
  fi

  for skill_name in "${SELECTED_SKILLS[@]}"; do
    source_path="${SKILLS_SOURCE%/}/skills/${skill_name}/"
    skill_target="${target_path%/}/${skill_name}"

    info "syncing skill ${skill_name}"
    run_cmd mkdir -p "$skill_target"
    run_cmd rsync -a --delete "$source_path" "${skill_target}/"

    if [[ -n "$target_owner" ]]; then
      run_cmd chown -R "$target_owner" "$skill_target"
    fi
  done
}

prepare_library_promotion_source() {
  local publish_dir
  local -a import_cmd=()

  if [[ "$LIBRARY_MODE" == "promotion" ]]; then
    LIBRARY_PROMOTION_SOURCE="$LIBRARY_SOURCE"
    return 0
  fi

  publish_dir="$(mktemp -d)"
  TEMP_DIRS+=("$publish_dir")

  info "importing library from ${LIBRARY_IMPORT_SOURCE} through ${ASSET_LIBRARY_ROOT}"
  import_cmd=(
    python3
    "$(asset_library_script_path import-assets.py)"
    --root "$ASSET_LIBRARY_ROOT"
    --source "$LIBRARY_IMPORT_SOURCE"
  )

  if [[ "$LIBRARY_IMPORT_COPY" == "1" ]]; then
    import_cmd+=(--copy)
  fi

  "${import_cmd[@]}"

  info "publishing runtime-facing library state into ${publish_dir}"
  python3 \
    "$(asset_library_script_path publish-library.py)" \
    --root "$ASSET_LIBRARY_ROOT" \
    --target "$publish_dir"

  info "validating published library state in ${publish_dir}"
  python3 \
    "$(asset_library_script_path validate-library.py)" \
    --root "$publish_dir"

  LIBRARY_PROMOTION_SOURCE="$publish_dir"
}

write_setup_state() {
  local state_file
  local completed_at
  local hostname_value
  local pi_kit_ref
  local installed_skills
  local runtime_config_target_value
  local library_source_value
  local library_import_source_value=""
  local library_import_mode_value=""
  local asset_library_root_value=""
  local asset_library_ref_value=""

  state_file="$(root_path "$(setup_run_state_path)")"
  completed_at="$(timestamp_utc)"
  hostname_value="$(hostname 2>/dev/null || uname -n)"
  pi_kit_ref="$(resolve_pi_kit_ref)"
  installed_skills="$(join_by ' ' "${SELECTED_SKILLS[@]}")"
  runtime_config_target_value="$(runtime_config_path)"

  if [[ "$LIBRARY_MODE" == "import" ]]; then
    library_source_value="generated-from-asset-library-import"
    library_import_source_value="$LIBRARY_IMPORT_SOURCE"
    asset_library_root_value="$ASSET_LIBRARY_ROOT"
    asset_library_ref_value="$(
      resolve_repo_ref \
        "$ASSET_LIBRARY_ROOT" \
        "$ASSET_LIBRARY_REF_OVERRIDE" \
        "soundclaw-asset-library"
    )"

    if [[ "$LIBRARY_IMPORT_COPY" == "1" ]]; then
      library_import_mode_value="copy"
    else
      library_import_mode_value="move"
    fi
  else
    library_source_value="$LIBRARY_SOURCE"
  fi

  write_text_file "$state_file" <<EOF
SETUP_COMPLETED_AT=${completed_at@Q}
SETUP_HOSTNAME=${hostname_value@Q}
SETUP_PROFILE=${PROFILE@Q}
SETUP_ALLOW_NO_AUDIO=${ALLOW_NO_AUDIO}
SETUP_PI_KIT_REF=${pi_kit_ref@Q}
SETUP_RUNTIME_SOURCE=${RUNTIME_SOURCE@Q}
SETUP_RUNTIME_RELEASE_REF=${RUNTIME_RELEASE_REF@Q}
SETUP_RUNTIME_CONFIG_SOURCE=${RUNTIME_CONFIG_SOURCE@Q}
SETUP_RUNTIME_CONFIG_VARIANT=${RUNTIME_CONFIG_REF@Q}
SETUP_RUNTIME_CONFIG_TARGET=${runtime_config_target_value@Q}
SETUP_RUNTIME_SELECTOR=${RESOLVED_RUNTIME_SELECTOR@Q}
SETUP_RUNTIME_SELECTOR_SOURCE=${RESOLVED_RUNTIME_SELECTOR_SOURCE@Q}
SETUP_LIBRARY_MODE=${LIBRARY_MODE@Q}
SETUP_LIBRARY_SOURCE=${library_source_value@Q}
SETUP_LIBRARY_RELEASE_REF=${LIBRARY_RELEASE_REF@Q}
SETUP_LIBRARY_IMPORT_SOURCE=${library_import_source_value@Q}
SETUP_LIBRARY_IMPORT_MODE=${library_import_mode_value@Q}
SETUP_ASSET_LIBRARY_ROOT=${asset_library_root_value@Q}
SETUP_ASSET_LIBRARY_REF=${asset_library_ref_value@Q}
SETUP_SKILLS_SOURCE=${SKILLS_SOURCE@Q}
SETUP_SKILLS_REF=${SKILLS_REF@Q}
SETUP_SKILLS_TARGET=${SKILLS_TARGET@Q}
SETUP_SKILLS_INSTALL_METHOD='rsync'
SETUP_SKILLS_INSTALLED=${installed_skills@Q}
SETUP_PUBLIC_RELEASE_ID=${PUBLIC_RELEASE_ID@Q}
SETUP_PUBLIC_BUNDLE_SOURCE=${PUBLIC_BUNDLE_SOURCE@Q}
SETUP_PUBLIC_BUNDLE_ASSET=${PUBLIC_BUNDLE_ASSET@Q}
SETUP_PUBLIC_MANIFEST_SHA256=${PUBLIC_MANIFEST_SHA256@Q}
SETUP_PUBLIC_CHECKSUMS_SHA256=${PUBLIC_CHECKSUMS_SHA256@Q}
SETUP_PUBLIC_SOURCE_TUPLE=${PUBLIC_SOURCE_TUPLE@Q}
EOF

  if is_live_root; then
    run_cmd chown root:root "$state_file"
  fi

  run_cmd chmod 0644 "$state_file"
}

print_setup_summary() {
  local state_path
  local installed_skills
  local library_summary

  state_path="$(setup_run_state_path)"
  installed_skills="$(join_by ', ' "${SELECTED_SKILLS[@]}")"

  if [[ "$LIBRARY_MODE" == "import" ]]; then
    library_summary="imported local media from ${LIBRARY_IMPORT_SOURCE}"
  else
    library_summary="promoted library state from ${LIBRARY_SOURCE}"
  fi

  cat <<EOF
info: setup complete
info: recorded setup evidence in ${state_path}
info: library handoff: ${library_summary}
info: installed skills: ${installed_skills}
EOF
}

main() {
  local -a install_args=()
  local -a runtime_args=()
  local -a library_args=()

  while [[ $# -gt 0 ]]; do
    case "$1" in
      --profile)
        [[ $# -ge 2 ]] || die "--profile requires a value"
        PROFILE="$2"
        shift 2
        ;;
      --skip-packages)
        SKIP_PACKAGES=1
        shift
        ;;
      --allow-no-audio)
        ALLOW_NO_AUDIO=1
        shift
        ;;
      --runtime-source)
        [[ $# -ge 2 ]] || die "--runtime-source requires a value"
        RUNTIME_SOURCE="$2"
        shift 2
        ;;
      --runtime-release-ref)
        [[ $# -ge 2 ]] || die "--runtime-release-ref requires a value"
        RUNTIME_RELEASE_REF="$2"
        shift 2
        ;;
      --runtime-config)
        [[ $# -ge 2 ]] || die "--runtime-config requires a value"
        RUNTIME_CONFIG_SOURCE="$2"
        shift 2
        ;;
      --runtime-config-ref)
        [[ $# -ge 2 ]] || die "--runtime-config-ref requires a value"
        RUNTIME_CONFIG_REF="$2"
        shift 2
        ;;
      --runtime-selector)
        [[ $# -ge 2 ]] || die "--runtime-selector requires a value"
        RUNTIME_SELECTOR_OVERRIDE="$2"
        shift 2
        ;;
      --library-source)
        [[ $# -ge 2 ]] || die "--library-source requires a value"
        LIBRARY_SOURCE="$2"
        shift 2
        ;;
      --library-release-ref)
        [[ $# -ge 2 ]] || die "--library-release-ref requires a value"
        LIBRARY_RELEASE_REF="$2"
        shift 2
        ;;
      --asset-library-root)
        [[ $# -ge 2 ]] || die "--asset-library-root requires a value"
        ASSET_LIBRARY_ROOT="$2"
        shift 2
        ;;
      --asset-library-ref)
        [[ $# -ge 2 ]] || die "--asset-library-ref requires a value"
        ASSET_LIBRARY_REF_OVERRIDE="$2"
        shift 2
        ;;
      --library-import-source)
        [[ $# -ge 2 ]] || die "--library-import-source requires a value"
        LIBRARY_IMPORT_SOURCE="$2"
        shift 2
        ;;
      --library-import-copy)
        LIBRARY_IMPORT_COPY=1
        shift
        ;;
      --skills-source)
        [[ $# -ge 2 ]] || die "--skills-source requires a value"
        SKILLS_SOURCE="$2"
        shift 2
        ;;
      --skills-ref)
        [[ $# -ge 2 ]] || die "--skills-ref requires a value"
        SKILLS_REF="$2"
        shift 2
        ;;
      --skills-target)
        [[ $# -ge 2 ]] || die "--skills-target requires a value"
        SKILLS_TARGET="$2"
        shift 2
        ;;
      --skill)
        [[ $# -ge 2 ]] || die "--skill requires a value"
        REQUESTED_SKILLS+=("$2")
        shift 2
        ;;
      --pi-kit-ref)
        [[ $# -ge 2 ]] || die "--pi-kit-ref requires a value"
        PI_KIT_REF_OVERRIDE="$2"
        shift 2
        ;;
      --public-release-id)
        [[ $# -ge 2 ]] || die "--public-release-id requires a value"
        PUBLIC_RELEASE_ID="$2"
        shift 2
        ;;
      --public-bundle-source)
        [[ $# -ge 2 ]] || die "--public-bundle-source requires a value"
        PUBLIC_BUNDLE_SOURCE="$2"
        shift 2
        ;;
      --public-bundle-asset)
        [[ $# -ge 2 ]] || die "--public-bundle-asset requires a value"
        PUBLIC_BUNDLE_ASSET="$2"
        shift 2
        ;;
      --public-manifest-sha256)
        [[ $# -ge 2 ]] || die "--public-manifest-sha256 requires a value"
        PUBLIC_MANIFEST_SHA256="$2"
        shift 2
        ;;
      --public-checksums-sha256)
        [[ $# -ge 2 ]] || die "--public-checksums-sha256 requires a value"
        PUBLIC_CHECKSUMS_SHA256="$2"
        shift 2
        ;;
      --public-source-tuple)
        [[ $# -ge 2 ]] || die "--public-source-tuple requires a value"
        PUBLIC_SOURCE_TUPLE="$2"
        shift 2
        ;;
      --dry-run)
        DRY_RUN=1
        shift
        ;;
      --help|-h)
        usage
        exit 0
        ;;
      *)
        die "unknown argument: $1"
        ;;
    esac
  done

  load_profile "$PROFILE"
  validate_inputs
  resolve_selected_skills

  if [[ -z "$RUNTIME_RELEASE_REF" ]]; then
    RUNTIME_RELEASE_REF="$(basename "$RUNTIME_SOURCE")"
  fi

  if [[ -z "$RUNTIME_CONFIG_REF" ]]; then
    RUNTIME_CONFIG_REF="$(basename "$RUNTIME_CONFIG_SOURCE")"
  fi

  if [[ -z "$LIBRARY_RELEASE_REF" ]]; then
    LIBRARY_RELEASE_REF="$(default_library_release_ref)"
  fi

  require_root

  install_args=(--profile "$PROFILE")
  runtime_args=(--source "$RUNTIME_SOURCE" --release-ref "$RUNTIME_RELEASE_REF")

  if [[ "$SKIP_PACKAGES" == "1" ]]; then
    install_args+=(--skip-packages)
  fi

  if [[ "$ALLOW_NO_AUDIO" == "1" ]]; then
    install_args+=(--allow-no-audio)
  fi

  if [[ "$DRY_RUN" == "1" ]]; then
    install_args+=(--dry-run)
    runtime_args+=(--dry-run)
  fi

  info "running install flow"
  "${SCRIPT_DIR}/install.sh" "${install_args[@]}"

  install_runtime_config

  info "deploying staged runtime"
  "${SCRIPT_DIR}/deploy-runtime.sh" "${runtime_args[@]}"

  prepare_library_promotion_source
  library_args=(--source "$LIBRARY_PROMOTION_SOURCE" --release-ref "$LIBRARY_RELEASE_REF")

  if [[ "$DRY_RUN" == "1" ]]; then
    library_args+=(--dry-run)
  fi

  if [[ "$LIBRARY_MODE" == "import" ]]; then
    info "promoting library state generated from local import"
  else
    info "promoting provided library state"
  fi
  "${SCRIPT_DIR}/deploy-asset-library.sh" "${library_args[@]}"

  sync_skills
  write_setup_state
  print_setup_summary
}

main "$@"
