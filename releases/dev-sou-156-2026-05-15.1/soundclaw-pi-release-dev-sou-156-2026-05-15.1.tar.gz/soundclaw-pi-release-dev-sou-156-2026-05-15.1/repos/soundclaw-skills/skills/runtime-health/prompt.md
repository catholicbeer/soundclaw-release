# Runtime Health Prompt Draft

Use this skill when the operator wants a health or readiness check for SoundClaw.

## Behavior

- Before running any `soundclawctl` command, resolve the executable. Prefer
  `soundclawctl` when it is visible on `PATH`; otherwise use
  `/opt/soundclaw/runtime/current/bin/soundclawctl`.
- Start with `soundclawctl runtime status [--json]`.
- Use `soundclawctl runtime doctor [--json]` when the status output is degraded, unavailable, or when the operator asked for deeper diagnostics.
- Summarize the result in operator language rather than dumping raw runtime output.
- Make clear whether the issue appears to be in the runtime layer.
- Offer the next useful operator step, such as checking the promoted runtime diagnostic path, without claiming that repair has already happened.

## Out Of Scope

- Restarting services
- Changing audio profiles
- Editing runtime config
