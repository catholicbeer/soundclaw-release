# SoundClaw Version And Updates Prompt Draft

Use this skill when the operator asks what SoundClaw version, release, or
deployment is installed, whether an update is available, or how to install a
selected SoundClaw update.

## Behavior

- Before running any `soundclawctl` command, resolve the executable. Prefer
  `soundclawctl` when it is visible on `PATH`; otherwise use
  `/opt/soundclaw/runtime/current/bin/soundclawctl`.
- For installed-version or deployment questions, run
  `soundclawctl deployment status --json`.
- Treat `deployment status` as the only skill-facing installed identity source.
  Do not read `/var/lib/soundclaw/setup-run.env` directly.
- When deployment status is `installed`, summarize the public release id first,
  then include the key refs the operator needs: runtime ref, pi-kit ref, skills
  ref, and library ref when present.
- When deployment status is `local`, say this host appears to be a local or
  non-public-release install, so public GitHub update comparison may not be
  meaningful.
- When deployment status is `missing`, `malformed`, or `incomplete`, explain
  that SoundClaw could not prove an installed public deployment identity through
  the promoted command. Include the command result's reason when available, and
  point to the pi-kit-owned install or repair path instead of inventing a
  version.
- If no `soundclawctl` executable can be found, explain that the SoundClaw
  backend does not appear installed or visible to this OpenClaw environment.
  Point the operator to the SoundClaw onboarding skill or to the public
  `https://github.com/<owner>/soundclaw-release/releases` install surface,
  where the extracted bundle provides `install.sh` and bundled pi-kit scripts.
  Do not try to install the backend from this skill.
- For normal update-availability questions, use the pi-kit-owned read-only
  production check `./scripts/check-release-update.sh --json` from a valid
  `soundclaw-pi-kit` checkout, or from an extracted release bundle path under
  `repos/soundclaw-pi-kit/scripts/`. Treat this default as the stable/final
  public release channel.
- If the operator explicitly asks to test a dev, prerelease, RC, WDR, or RTW
  candidate, use the explicit pi-kit RC check
  `./scripts/check-release-update.sh --channel rc --json`.
- If the operator names an exact candidate release id, use
  `./scripts/check-release-update.sh --release-id <release-id> --json` for the
  read-only check rather than the moving RC channel.
- For WDR or RTW candidate setup, tell the operator to record the exact
  release id returned by the RC or exact check before approving any Pi
  mutation. The install step should target that named release id.
- If the pi-kit update-check command is unavailable, say that the update
  backend command is missing from this environment and provide the exact
  command the operator can run from either a valid `soundclaw-pi-kit` checkout
  or an extracted release bundle path:
  `./scripts/check-release-update.sh --json`.
  Point the operator to the public release surface at
  `https://github.com/<owner>/soundclaw-release/releases`
  so they can obtain the bundle that carries the pi-kit scripts.
- If the update check reports `no-update`, say the installed public release
  already matches the selected production, RC, or exact release check.
- If the update check reports `update-available`, name the installed release id,
  selected release id, release channel when present, and bundle URL when
  present. Present the next step as a pi-kit-owned command, not as a
  skill-owned install.
- If the update check reports `unavailable` or fails because GitHub is offline,
  unreachable, rate-limited, or returning unusable metadata, say the update
  check is unavailable and include the safe retry or operator handoff.
- For install or update requests, require explicit operator confirmation before
  any mutating command. Confirm the selected release id or bundle URL in the
  confirmation request.
- If the operator confirms and the pi-kit update command is available, run only
  the approved pi-kit-owned update path, such as
  `sudo ./scripts/update-install.sh --release-id <release-id> --yes [setup options]`.
- If the operator has not confirmed, or if sudo/operator permission is missing,
  do not run the install. Explain that update installation mutates the host and
  requires explicit approval plus the needed permission.
- Report update installation as complete only when the pi-kit command returns
  success. If it fails, say the install did not complete and summarize the
  command's failure reason.
- After a successful pi-kit install or update, tell the operator to return to
  the same OpenClaw workspace and rerun the readiness or version check. If the
  pi-kit runbook called for an OpenClaw Gateway restart or user-session refresh,
  mention that this must happen before trusting the OpenClaw result.
- Keep default responses operator-friendly. Avoid dumping raw JSON unless the
  operator asks for raw details.

## Out Of Scope

- Direct parsing of pi-kit setup state files
- Direct GitHub release lookup from the skill
- Bundle download or verification inside the skill
- Silent update installation
- Runtime service restart, repair, rollback, or systemd manipulation
- Changing pi-kit update mechanics or runtime CLI implementation
