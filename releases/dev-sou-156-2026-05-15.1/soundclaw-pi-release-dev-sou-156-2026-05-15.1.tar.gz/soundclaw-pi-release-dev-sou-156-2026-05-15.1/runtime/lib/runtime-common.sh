#!/usr/bin/env bash

# Shared helpers for the minimal soundclaw-runtime scaffold.

if [[ -n "${SOUNDCLAW_RUNTIME_LIB_LOADED:-}" ]]; then
  return 0
fi
SOUNDCLAW_RUNTIME_LIB_LOADED=1

RUNTIME_REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

readonly RUNTIME_VERSION="0.1.0"
readonly SUPPORTED_RUNTIME_PROFILE="shared"

info() {
  printf 'info: %s\n' "$*"
}

warn() {
  printf 'warn: %s\n' "$*" >&2
}

die() {
  printf 'error: %s\n' "$*" >&2
  exit 1
}

timestamp_utc() {
  date -u +"%Y-%m-%dT%H:%M:%SZ"
}

set_runtime_defaults() {
  SC_RUNTIME_HOME="${SC_RUNTIME_HOME:-${RUNTIME_REPO_ROOT}}"
  SC_CONFIG_DIR="${SC_CONFIG_DIR:-/etc/soundclaw}"
  SC_STATE_DIR="${SC_STATE_DIR:-/var/lib/soundclaw}"
  SC_LOG_DIR="${SC_LOG_DIR:-/var/log/soundclaw}"
  SC_RUNTIME_CONFIG_FILE="${SC_RUNTIME_CONFIG_FILE:-${SC_CONFIG_DIR}/runtime.env}"
  SC_RUNTIME_PROFILE="${SC_RUNTIME_PROFILE:-${SUPPORTED_RUNTIME_PROFILE}}"
  SC_HEARTBEAT_INTERVAL_SECONDS="${SC_HEARTBEAT_INTERVAL_SECONDS:-5}"
  SC_RUNTIME_LOG_LEVEL="${SC_RUNTIME_LOG_LEVEL:-info}"
}

load_runtime_config() {
  SC_RUNTIME_CONFIG_PRESENT=0

  if [[ -f "${SC_RUNTIME_CONFIG_FILE}" ]]; then
    SC_RUNTIME_CONFIG_PRESENT=1

    # shellcheck disable=SC1090
    source "${SC_RUNTIME_CONFIG_FILE}"
  fi
}

derive_runtime_paths() {
  SC_RUNTIME_STATE_DIR="${SC_RUNTIME_STATE_DIR:-${SC_STATE_DIR}/runtime}"
  SC_RUNTIME_LOG_DIR="${SC_RUNTIME_LOG_DIR:-${SC_LOG_DIR}/runtime}"
  SC_RUNTIME_STATUS_FILE="${SC_RUNTIME_STATUS_FILE:-${SC_RUNTIME_STATE_DIR}/status.env}"
  SC_RUNTIME_PID_FILE="${SC_RUNTIME_PID_FILE:-${SC_RUNTIME_STATE_DIR}/runtime.pid}"
  SC_RUNTIME_MAIN_LOG="${SC_RUNTIME_MAIN_LOG:-${SC_RUNTIME_LOG_DIR}/runtime.log}"
}

require_absolute_path() {
  local value="$1"
  local name="$2"

  [[ "${value}" == /* ]] || die "${name} must be an absolute path: ${value}"
}

validate_runtime_settings() {
  [[ "${SC_RUNTIME_PROFILE}" == "${SUPPORTED_RUNTIME_PROFILE}" ]] || die \
    "unsupported runtime profile: ${SC_RUNTIME_PROFILE} (supported: ${SUPPORTED_RUNTIME_PROFILE})"

  [[ "${SC_HEARTBEAT_INTERVAL_SECONDS}" =~ ^[1-9][0-9]*$ ]] || die \
    "SC_HEARTBEAT_INTERVAL_SECONDS must be a positive integer: ${SC_HEARTBEAT_INTERVAL_SECONDS}"

  require_absolute_path "${SC_RUNTIME_HOME}" "SC_RUNTIME_HOME"
  require_absolute_path "${SC_CONFIG_DIR}" "SC_CONFIG_DIR"
  require_absolute_path "${SC_STATE_DIR}" "SC_STATE_DIR"
  require_absolute_path "${SC_LOG_DIR}" "SC_LOG_DIR"
  require_absolute_path "${SC_RUNTIME_CONFIG_FILE}" "SC_RUNTIME_CONFIG_FILE"
  require_absolute_path "${SC_RUNTIME_STATE_DIR}" "SC_RUNTIME_STATE_DIR"
  require_absolute_path "${SC_RUNTIME_LOG_DIR}" "SC_RUNTIME_LOG_DIR"
  require_absolute_path "${SC_RUNTIME_STATUS_FILE}" "SC_RUNTIME_STATUS_FILE"
  require_absolute_path "${SC_RUNTIME_PID_FILE}" "SC_RUNTIME_PID_FILE"
  require_absolute_path "${SC_RUNTIME_MAIN_LOG}" "SC_RUNTIME_MAIN_LOG"
}

load_runtime_env() {
  set_runtime_defaults
  load_runtime_config
  derive_runtime_paths
  validate_runtime_settings
}

ensure_dir() {
  mkdir -p "$1"
}

write_text_file() {
  local target="$1"
  local target_dir
  local temp_file

  target_dir="$(dirname "${target}")"
  mkdir -p "${target_dir}"
  temp_file="$(mktemp "${target_dir}/.$(basename "${target}").tmp.XXXXXX")"

  if ! cat >"${temp_file}"; then
    rm -f "${temp_file}"
    return 1
  fi

  mv -f "${temp_file}" "${target}"
}

append_runtime_log() {
  local level="$1"
  shift

  ensure_dir "${SC_RUNTIME_LOG_DIR}"
  printf '%s [%s] %s\n' "$(timestamp_utc)" "${level}" "$*" >>"${SC_RUNTIME_MAIN_LOG}"
}

runtime_home_entrypoint() {
  printf '%s\n' "${SC_RUNTIME_HOME}/bin/soundclaw-runtime"
}

runtime_home_control_cli() {
  printf '%s\n' "${SC_RUNTIME_HOME}/bin/soundclawctl"
}

runtime_home_internal_daemon() {
  printf '%s\n' "${SC_RUNTIME_HOME}/libexec/soundclaw-runtime-daemon"
}

runtime_home_internal_control_cli() {
  printf '%s\n' "${SC_RUNTIME_HOME}/libexec/soundclawctl-rust"
}

runtime_stage_info_file() {
  printf '%s\n' "${SC_RUNTIME_HOME}/STAGE-INFO.env"
}

require_runtime_home() {
  [[ -d "${SC_RUNTIME_HOME}" ]] || die "runtime home is missing: ${SC_RUNTIME_HOME}"
  [[ -x "$(runtime_home_entrypoint)" ]] || die \
    "runtime entrypoint is missing or not executable: $(runtime_home_entrypoint)"
  [[ -x "$(runtime_home_control_cli)" ]] || die \
    "runtime control CLI is missing or not executable: $(runtime_home_control_cli)"
}

require_internal_runtime_daemon() {
  local daemon_path

  daemon_path="$(runtime_home_internal_daemon)"
  [[ -x "${daemon_path}" ]] || die \
    "internal Rust runtime daemon is missing or not executable: ${daemon_path} (stage a runtime directory with scripts/stage-runtime.sh before testing the Rust cutover path)"
  require_runtime_stage_target_matches_host
}

require_internal_runtime_control_cli() {
  local control_cli_path

  control_cli_path="$(runtime_home_internal_control_cli)"
  [[ -x "${control_cli_path}" ]] || die \
    "internal Rust control CLI is missing or not executable: ${control_cli_path} (stage a runtime directory with scripts/stage-runtime.sh before testing the Rust cutover path)"
  require_runtime_stage_target_matches_host
}

clear_runtime_stage_vars() {
  unset SC_RUNTIME_STAGE_ROOT SC_RUNTIME_STAGE_PROFILE SC_RUNTIME_STAGE_TARGET \
    SC_RUNTIME_STAGE_DAEMON_BINARY SC_RUNTIME_STAGE_CONTROL_CLI_BINARY \
    SC_RUNTIME_STAGE_CREATED_AT
}

load_runtime_stage_info() {
  local stage_info_file

  stage_info_file="$(runtime_stage_info_file)"
  [[ -f "${stage_info_file}" ]] || return 1

  clear_runtime_stage_vars

  # shellcheck disable=SC1090
  if ! source "${stage_info_file}" 2>/dev/null; then
    clear_runtime_stage_vars
    return 1
  fi
}

host_rust_target_candidates() {
  case "$(uname -m)" in
    x86_64)
      printf '%s\n' "x86_64-unknown-linux-gnu"
      ;;
    aarch64|arm64)
      printf '%s\n' "aarch64-unknown-linux-gnu"
      ;;
    armv7l)
      printf '%s\n' "armv7-unknown-linux-gnueabihf"
      ;;
  esac
}

require_runtime_stage_target_matches_host() {
  local host_target

  if ! load_runtime_stage_info; then
    return 0
  fi

  [[ -n "${SC_RUNTIME_STAGE_TARGET:-}" ]] || return 0

  while IFS= read -r host_target; do
    [[ -n "${host_target}" ]] || continue
    if [[ "${SC_RUNTIME_STAGE_TARGET}" == "${host_target}" ]]; then
      return 0
    fi
  done < <(host_rust_target_candidates)

  die "staged Rust binaries target '${SC_RUNTIME_STAGE_TARGET}', but this host reports '$(uname -m)'; rebuild with scripts/stage-runtime.sh --target $(host_rust_target_candidates | head -n 1)"
}

require_host_contract_dirs() {
  [[ -d "${SC_CONFIG_DIR}" ]] || die "missing host config directory: ${SC_CONFIG_DIR}"
  [[ -d "${SC_STATE_DIR}" ]] || die "missing host state directory: ${SC_STATE_DIR}"
  [[ -d "${SC_LOG_DIR}" ]] || die "missing host log directory: ${SC_LOG_DIR}"
}

ensure_runtime_layout() {
  require_runtime_home
  require_host_contract_dirs
  ensure_dir "${SC_RUNTIME_STATE_DIR}"
  ensure_dir "${SC_RUNTIME_LOG_DIR}"
  : >>"${SC_RUNTIME_MAIN_LOG}"
}

write_pid_file() {
  write_text_file "${SC_RUNTIME_PID_FILE}" <<<"$1"
}

clear_pid_file() {
  rm -f "${SC_RUNTIME_PID_FILE}"
}

read_pid_file() {
  [[ -f "${SC_RUNTIME_PID_FILE}" ]] || return 1

  local pid
  IFS= read -r pid <"${SC_RUNTIME_PID_FILE}"
  printf '%s\n' "${pid}"
}

is_pid_running() {
  local pid="${1:-}"

  [[ "${pid}" =~ ^[0-9]+$ ]] || return 1
  kill -0 "${pid}" 2>/dev/null
}

is_runtime_pid_running() {
  local pid="${1:-}"
  local expected_entrypoint
  local -a cmdline=()

  is_pid_running "${pid}" || return 1
  [[ -r "/proc/${pid}/cmdline" ]] || return 1

  mapfile -d '' -t cmdline <"/proc/${pid}/cmdline" || true
  (( ${#cmdline[@]} >= 3 )) || return 1

  expected_entrypoint="$(runtime_home_entrypoint)"
  [[ "${cmdline[1]}" == "${expected_entrypoint}" ]] || return 1
  [[ "${cmdline[2]}" == "run" ]]
}

write_runtime_status() {
  local status_value="$1"
  local detail="$2"
  local pid_value="${3:-}"
  local updated_at

  updated_at="$(timestamp_utc)"

  if [[ -z "${pid_value}" ]] && [[ -f "${SC_RUNTIME_PID_FILE}" ]]; then
    pid_value="$(read_pid_file || true)"
  fi

  write_text_file "${SC_RUNTIME_STATUS_FILE}" <<EOF
SC_STATUS_VALUE=${status_value@Q}
SC_STATUS_DETAIL=${detail@Q}
SC_STATUS_UPDATED_AT=${updated_at@Q}
SC_STATUS_PID=${pid_value@Q}
SC_STATUS_PROFILE=${SC_RUNTIME_PROFILE@Q}
SC_STATUS_CONFIG_FILE=${SC_RUNTIME_CONFIG_FILE@Q}
SC_STATUS_CONFIG_PRESENT=${SC_RUNTIME_CONFIG_PRESENT@Q}
SC_STATUS_RUNTIME_HOME=${SC_RUNTIME_HOME@Q}
SC_STATUS_STATE_DIR=${SC_RUNTIME_STATE_DIR@Q}
SC_STATUS_LOG_FILE=${SC_RUNTIME_MAIN_LOG@Q}
EOF
}

clear_runtime_status_vars() {
  unset SC_STATUS_VALUE SC_STATUS_DETAIL SC_STATUS_UPDATED_AT SC_STATUS_PID \
    SC_STATUS_PROFILE SC_STATUS_CONFIG_FILE SC_STATUS_CONFIG_PRESENT \
    SC_STATUS_RUNTIME_HOME SC_STATUS_STATE_DIR SC_STATUS_LOG_FILE
}

load_runtime_status_file() {
  [[ -f "${SC_RUNTIME_STATUS_FILE}" ]] || return 1

  clear_runtime_status_vars

  # shellcheck disable=SC1090
  if ! source "${SC_RUNTIME_STATUS_FILE}" 2>/dev/null; then
    clear_runtime_status_vars
    return 1
  fi
}

json_escape() {
  local value="${1:-}"

  value="${value//\\/\\\\}"
  value="${value//\"/\\\"}"
  value="${value//$'\n'/\\n}"
  value="${value//$'\r'/\\r}"
  value="${value//$'\t'/\\t}"

  printf '%s' "${value}"
}
