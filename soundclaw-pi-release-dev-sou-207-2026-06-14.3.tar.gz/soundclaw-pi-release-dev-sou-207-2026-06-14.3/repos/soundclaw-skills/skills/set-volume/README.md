# Set Volume

Purpose: Show or set SoundClaw global volume through promoted runtime commands,
and make runtime-reload requirements explicit for running daemons.

Runtime dependency:

- `soundclawctl volume show [--json]`
- `soundclawctl volume set-global --global-volume-percent <0-200> [--json]`
- `soundclawctl runtime reload [--json]` after `set-global` when a running daemon
  needs to observe the config-backed change immediately

## Operator Job

This skill owns the global-volume workflow for OpenClaw operators: inspect the
current global volume, set a new global volume in the documented bounds, and
explain whether runtime reload is still pending or already complete.

It keeps volume changes on the promoted `soundclawctl` boundary. It should not
attempt host mixer/device controls, direct config editing, or runtime-internal
workarounds.

## Guardrails

- Resolve the current value with `volume show` when the operator asks to inspect
  or when a set request is ambiguous.
- Accept only documented bounds (`0` through `200`) for
  `--global-volume-percent`; clarify if the operator asks for an out-of-range
  value.
- Make it explicit that `volume set-global` updates config and a running daemon
  observes the change only after `soundclawctl runtime reload [--json]`.
- If route-level gain is requested, hand the workflow to `manage-output` and
  preserve the documented `--route <source:dest[:gain_percent]>` syntax.
- Do not edit `runtime.toml`, control ALSA/PipeWire directly, or perform service
  repair.
