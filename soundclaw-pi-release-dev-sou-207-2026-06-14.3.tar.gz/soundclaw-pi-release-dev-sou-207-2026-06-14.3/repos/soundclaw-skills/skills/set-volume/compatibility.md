# Compatibility

Operator job: Set Volume

Runtime dependency:

- Status: Pending current runtime release-line declaration and deployed
  host-contract support for this global-volume workflow.
- Contract reference: `soundclaw/docs/runtime-spec.md`
- Runtime implementation reference: `SOU-151` landed `soundclaw-runtime` durable
  pushed ref `origin/codex/sou-162-runtime-wave-integration` at
  `3e620dd4ddd606985199e866bde82cc3513d40f4`, including promoted
  `volume show`, `volume set-global`, and route-gain command-shape support.
- Command(s): `soundclawctl volume show [--json]`
- Command(s): `soundclawctl volume set-global --global-volume-percent <0-200> [--json]`
- Command(s): `soundclawctl runtime reload [--json]`
- Scope note: This skill owns global volume inspection and set guidance only.
  Per-route gain remains in `manage-output` with
  `--route <source:dest[:gain_percent]>`.

Minimum compatible runtime release line: Pending definition in
`soundclaw-runtime`.

Tested runtime release line: Not yet validated against a promoted runtime
release line.

Packaging target: Plain skill

ClawHub publication status: Not published
