# Manage Output Prompt Draft

Use this skill when the operator wants to add, update, remove, or deliberately
reload one low-risk logical output workflow.

## Behavior

- Before running any `soundclawctl` command, resolve the executable. Prefer
  `soundclawctl` when it is visible on `PATH`; otherwise use
  `/opt/soundclaw/runtime/current/bin/soundclawctl`.
- Resolve whether the operator wants to add, update, remove, or reload.
- If the request refers to an existing output but the id or current route is unclear, use `soundclawctl outputs list [--json]` or `soundclawctl outputs show --output <id> [--json]` instead of reading config files directly.
- For add or update, collect the final `--output`, `--zone`, `--source-channels`, and one or more `--route <source:dest[:gain_percent]>` entries before mutating.
- When the operator asks whether a zone owns the needed destination channels, or a runtime validation error says a requested route is outside zone ownership, use `soundclawctl zones list [--json]` or `soundclawctl zones show --zone <id> [--json]` to explain the runtime-owned zone shape. Use the returned `owned_dest_channels`, `zone_required_output_channels`, `zone_current_backend_supported_output_channels`, `current_backend_supported`, and `current_backend_detail` fields when shaping the operator-facing answer.
- Treat existing output routes as discovery examples only. Do not turn the destination channels used by another output in the same zone into a local allow-list for a new add or update.
- Preserve explicit operator-provided `--route <source:dest[:gain_percent]>` entries and pass them to `soundclawctl outputs add` or `soundclawctl outputs update`; let the runtime own validation for zone ownership, duplicate routes, source/destination rules, and current-backend capability.
- If a requested output needs destination channels that the selected/default zone does not own, explain that the zone must be created or updated before the output can be added or updated. Do not synthesize a route workaround or edit config files directly.
- When the deployed runtime line declares zone management support and the operator explicitly confirms admin topology work, collect the target zone id, device id, and complete owned destination-channel list before calling `soundclawctl zones add --zone <id> --device <id> --owned-dest-channel <n>... [--json]` or `soundclawctl zones update --zone <id> --device <id> --owned-dest-channel <n>... [--json]`.
- For zone removal, use `soundclawctl zones show --zone <id> [--json]` or output discovery when needed, state that removal is safe only when runtime validation accepts the config without outputs depending on that zone, and call `soundclawctl zones remove --zone <id> [--json]` only after explicit operator confirmation.
- For update, use `outputs show` when needed to inspect the current declaration, but confirm the final changed shape before calling `soundclawctl outputs update ...`.
- For remove, resolve the exact output id before calling `soundclawctl outputs remove --output <id> [--json]`.
- After a successful topology-changing output or zone add, update, or remove operation, make the deliberate reinitialization step explicit with `soundclawctl runtime reload [--json]`.
- When the operator asked for the full workflow and the deployed host contract allows it, treat reload as part of the same bounded admin workflow rather than a separate host-repair action.
- If the current runtime line or deployed host contract does not yet support this low-risk admin path, explain that clearly and stop instead of guessing, editing `runtime.toml`, or escalating into service control.
- Summarize success or failure in operator language, including which output changed and whether the deliberate reload step succeeded.

## Out Of Scope

- Direct `runtime.toml` editing
- Service restarts or host repair
- Zone edits when the deployed runtime line does not declare the promoted `soundclawctl zones` surface
- Bulk topology redesign
- Guessing route plans from vague place names or speaker-role intent
- Rejecting requested routes because another output in the zone uses a different sparse destination-channel layout
